# channels
QQ/Mail 渠道 skill：收发、媒体、提醒、渠道接入
## 内容
- 4 个 skill / 5 个文件 / 0.0M
- `openclaw/agents/main/agent/workshop-skills/` — 1 个 skill（原 workshop-skills/）
- `openclaw/extensions/qqbot/` — 3 个 skill（原 ~/.openclaw/extensions/qqbot/skills/）

## 跨仓依赖

依赖 quote-core 与 rfq-customer

## 部署

```bash
# 与本仓同系列的其他仓库一起部署到同一框架目录
# skill 名即目录名，直接按 framework 拷回原路径
```
