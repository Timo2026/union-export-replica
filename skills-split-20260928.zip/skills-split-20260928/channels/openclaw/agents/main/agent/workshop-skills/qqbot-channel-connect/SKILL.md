---
name: qqbot-channel-connect
description: |
  QQ Bot channel setup or repair: plugin collision, stale CLI help, silent credential drops, restart, prove — plus replies that fail on a model or quota error while the channel itself stays connected. Use when qqbot does not connect on this host, or when every QQ reply errors while the channel probe still passes.
---

# QQ Bot Channel Connect

## When to use
- Adding or reconfiguring the QQ Bot channel (`channels.qqbot`) on this host
- `channels add` printed success but qqbot stays "not configured", or a credential was rejected
- `channels list --all` shows two qqbot entries, or the guided wizard offers to enable a qqbot plugin

## Steps

1. **Establish which qqbot plugin is enabled.**
   `openclaw plugins list --json | jq '[.plugins[] | select(.id|test("qqbot")) | {id,enabled,version,status}]'`
   Exactly one plugin may own `channelIds: ["qqbot"]`. Supported: `openclaw-qqbot`
   (npm source, `trustedOfficialInstall`, 2.0.3 seen). Legacy: `qqbot` = `@openclaw/qqbot`
   2026.7.1 (clawhub source, `provenance-invalid`). The official migration path
   (`openclaw plugins update qqbot`) rewrites that entry under id `openclaw-qqbot`.
   Keep exactly one enabled; the legacy entry stays disabled unless the operator asks
   otherwise. Uninstall only on explicit request. Enabling both logs
   `[plugins] channel already registered: qqbot (openclaw-qqbot)` and
   `plugin tool name conflict (qqbot): qqbot_remind` in `/tmp/openclaw/openclaw-<date>.log`.
   **Check:** exactly one enabled qqbot entry.

2. **Add the channel by channel id; treat the `--channel` help list as stale.**
   `openclaw channels add --help` prints a `--channel` enum that omits qqbot, but that
   list is stale — the field itself is accepted. Both forms work:
   `openclaw channels add --channel qqbot --token-file <0600-secret-file>`
   `openclaw channels add qqbot --token-file <0600-secret-file>`
   (observed exit 0 with `Added QQ Bot account "default".`). Either writes `enabled`,
   `allowFrom`, and `dmPolicy` in one validated write. `--token-file` sets the
   AppSecret only; set the AppID separately:
   `openclaw config set channels.qqbot.appId "<appId>"`

   A credential containing `…` (an ellipsis in the middle of the value) is **silently
   dropped**: the command still prints success and exits 0 while writing nothing.
   Never treat the exit code as proof. Verify the write:
   `openclaw config get channels.qqbot --json` plus a plaintext scan of
   `~/.openclaw/openclaw.json` for the pasted fragment.
   **Check:** `openclaw channels list --all` shows `QQ Bot default: installed, configured, enabled`.

3. **Respect the plugin schema when writing `channels.qqbot` directly.**
   `openclaw config set channels.qqbot.enabled true` fails validation — the plugin
   requires `allowFrom`, so a bare field write is rejected. Prefer `channels add`
   (which supplies `allowFrom`), or set `allowFrom` explicitly. `channels add` writes
   `allowFrom: ["openclaw:approval-disabled"]`; replace that with a concrete openid
   once the bot answers (step 7).

4. **Keep the AppSecret out of argv, and clean up probe debris.**
   `--token "***"` puts the secret in process listings. Prefer `--token-file` with a
   `chmod 600` file, or config `clientSecretFile`. Docs claim the external package
   rejects structured SecretRefs for `clientSecret`; a store-ref `--dry-run` on this
   host passed shape validation and failed only on the absent store entry — treat a
   populated store ref as untested, not unsupported.
   Probing with a bogus `--token-file` can leave a dead `secrets.providers.<id>` entry
   (observed: `qqbot-client-secret` pointing at a nonexistent path). Clear both the
   channel reference and the provider:
   `openclaw config unset channels.qqbot.clientSecret`
   `openclaw config unset secrets.providers.qqbot-client-secret`

5. **Do not finish the job through the guided wizard.**
   `openclaw channels add` with no arguments opens a menu whose QQ Bot entry is bound
   to the legacy plugin id and asks `qqbot plugin is disabled. Enable it and continue
   setup now?`. Answering Yes recreates the two-plugin collision from step 1 — answer
   No and exit. QR-code binding is documented for QQ but is not reachable from the
   agent tool path: `openclaw channels login` is refused ("exec cannot run interactive
   OpenClaw channel login commands"), so any interactive credential flow needs an
   operator terminal.

6. **Restart, then prove the connection.**
   Channel reload is deferred while active work finishes, so restart is the reliable
   apply path: `openclaw daemon restart`. Do not use `openclaw gateway stop --force`
   (misses an unmanaged foreground gateway — see `openclaw-process-scoped-kill`), and
   do not expect the `openclaw` setup delegate to work here (known failures: `Plugin
   inventory has retired`; after your own plugin mutation it also fails with
   `prepared model runtime plugin generation was superseded` — first-class CLI only).
   **Check:** `openclaw channels status --probe` lists qqbot as connected and
   `openclaw gateway health` stops reporting `QQ Bot: not configured`. A missing
   credential surfaces as `QQBot not configured (missing appId or clientSecret)`;
   API `401` means appId/secret mismatch.

7. **Tighten access once the bot answers.**
   DM the bot and run `/bot-me` (documented: returns the sender's openid), then:
   `openclaw config set channels.qqbot.allowFrom '["<openid>"]' --strict-json`
   A concrete `allowFrom` entry also switches `dmPolicy` to `allowlist` enforcement;
   add group policy separately when needed.

## Pitfalls
- **A channel can be fully connected while every reply fails on a model error.** The
  QQ API keeps logging `Status: 200 OK` (the send itself succeeds) and
  `openclaw gateway health` still reports `QQ Bot: configured`, while the session that
  carries the conversation pins a model that cannot resolve. Verified 2026-09-24:
  session `agent:main:main` held `modelOverride: "step-5-preview"` +
  `providerOverride: "stepfun"`, and `stepfun` has no `models.providers` entry — so the
  agent's fallback chain never engaged (`fallbackConfigured: false`,
  `chain_exhausted` in `/tmp/openclaw/openclaw-<date>.log`) and StepFun's `402 You
  exceeded your current quota` was forwarded verbatim to the user
  (`sentBeforeError: true`). Diagnose with `openclaw sessions list --json`
  (`modelOverride` / `providerOverride` / `modelProvider`), and treat a reference as
  dangling when `config set` refuses the same id (`Unknown model … no matching
  models.providers["…"].models[] entry`). **A successful `openclaw infer model run`
  probe does not clear this** — it does not resolve the session's override, and it
  passed at 05:41 while the live session failed at 05:37 and 05:43 on the same model.
  Fix by clearing the override (`session_status(sessionKey=<key>, model="default")`),
  then confirm `modelOverride` and `providerOverride` are both `null` before blaming
  the channel; add a *registered* model as the agent's fallback so a provider outage
  degrades instead of dead-ending (`openclaw-model-config` step 6).
- Keep credentials out of chat, argv, and config plaintext; a `0600` secret file
  referenced by `clientSecretFile` is the default route on this host.
- `channels status --probe` can report "no configured chat channels" while the config
  is already written — the reload is deferred. Restart before concluding breakage.
- Never drive long-lived interactive OpenClaw channel commands through background
  exec: they strand as `[input-wait]` PTY sessions. Record the PID from the exec
  result and `kill -TERM` that PID — `pkill -f 'openclaw channels add'` also matches
  your own shell's command line (see `openclaw-process-scoped-kill`).
- The plugin also exposes `qqbot_remind` for scheduled QQ reminders; reminder tasks
  belong to that tool, not to this connect procedure.
- **A `message` send carrying an attachment can fail with `outLog.debug is not a function`.**
  This is a bug in the plugin's send path, not a broken channel: inbound stays healthy
  and the QQ API keeps logging `Status: 200 OK`. Deliver the file as a plain final reply
  with `MEDIA:<path>` on its own line instead of calling `message(action=send)` with
  `media` — that path is unaffected. Do not restart the gateway for it.
