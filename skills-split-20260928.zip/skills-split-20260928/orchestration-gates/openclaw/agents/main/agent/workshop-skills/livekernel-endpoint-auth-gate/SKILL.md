---
name: livekernel-endpoint-auth-gate
description: |
  Hardening a livekernel API port that binds 0.0.0.0 and is reachable through a public
  NAT address, and proving the gate holds without breaking loopback consumers. Use when
  an endpoint exposes /v1/* to the internet without auth, when a bearer/cookie gate must
  be added, or when a gate's own protection has to be verified.
---

# livekernel Endpoint Auth Gate

Access control for a livekernel HTTP port. Not the price-stop gates in
`livekernel-gate-and-verify` (those stop an outbound *quote*; this one stops an inbound
*request*). Different trigger, different code, same discipline of landing the check and
proving it.

## When to use
- A livekernel port binds `0.0.0.0` and a public address answers `/v1/*` with no credential
- An access gate (Bearer + session cookie) must be added, re-tuned, or verified after a change
- A hardening claim has to be proven rather than asserted

## Steps

1. **Confirm the public address is the local process before hardening it.** Compare a
   data response byte-for-byte (`curl http://127.0.0.1:8888/v1/rag/docs` against the
   identical request to the public address), and make the public request leave a trace in
   the service's own log by requesting a unique nonexistent path — the request row proves
   arrival. Titles and version strings are hints, not proof.

2. **Gate the API surface only. Exempt loopback, static assets, and the SPA shell.**
   Gate: `/v1/*`, `/health`, `/docs`, `/redoc`, `/openapi.json`. Exempt everything else.
   Exempting the SPA shell and static mounts is not laziness: a login wall on them turns
   the workbench white (the shell's own `fetch` sites number in the hundreds across
   `index.html`, `js/*.js`, and the built `webui-dist/assets/*.js`, and a cookie-based
   gate is what keeps that fan-out unchanged). **Loopback clients are the load-bearing
   exemption** — watchdog relaunch decisions are TCP `ss` probes, internal scripts and
   OpenClaw skills call `http://127.0.0.1:8888`, and the existing `TestClient(app)` suite
   reports host `testclient`. Treat `127.*`, `::1`, `::ffff:127.*`, `localhost`,
   `testclient`, and an empty host as loopback; anything else is gated.

3. **Put the primitives next to the security helpers that already exist, and land the
   middleware after CORS.** `services/security.py` already owned `RateLimiter` and PII
   redaction with no auth at all; `gate_*` belongs there rather than in a new module.
   In `api_server.py`, add the middleware after `CORSMiddleware` so the 401 body survives
   CORS handling, and start the service once with a missing token to confirm it degrades
   to gate-off with a WARNING instead of locking every caller out.

4. **Register `/__auth` before the SPA catch-all.** A route added after
   `@app.get("/{_spa:path}")` is swallowed and never reached. Cookie:
   `HttpOnly`, `SameSite=Lax`, `path=/`, `max_age` from env (default 30 days, clamped
   1 h – 8760 h). Ticket = `"<issued_at>.<hmac_sha256(token, issued_at)>"`, compared with
   `hmac.compare_digest`, rejected when issued in the future. Issuing from the token means
   rotating the token kills every outstanding ticket — that is the intended property.

5. **Prove the gate in two layers.** Unit-level: `TestClient(app, client=(host, port))`
   puts a chosen peer address into `scope["client"]`, which is what makes the whole matrix
   — external 401, loopback 200, Bearer accept/reject, cookie issue-and-unlock, ticket
   tampered/expired/future, token rotation — testable without a network. Integration-level:
   start a throwaway `uvicorn` on a spare port with the token set and confirm real
   middleware/CORS/static ordering, then close it.

6. **Verify with a non-loopback source, and state the one proof you cannot make.**
   `curl --interface 192.168.110.51 http://<that-ip>:8888/v1/rag/docs` → `401` is the
   proof that matters. **Curling the public NAT address from this host arrives with source
   `127.0.0.1` and returns 200 — that is the gate correctly exempting loopback, not a
   failed fix.** The LAN path and the public path enter through different source addresses,
   so in-host verification can only show "non-loopback is refused"; whether an external
   client is refused depends on the NAT, and must be checked from outside the host.
   Report that limit rather than reporting success.

## Pitfalls
- **The loopback-exemption trap is silent in both directions.** A curl to the public
  address that returns 200 proves nothing (it was exempt), and a curl that returns 401
  proves the gate fires but says nothing about the real internet. Always identify which
  source address the service logged — the journal's request rows name the peer.
- A shell `[ -x ]` test against another OS's binary path makes a step "skip" without an
  error; `exit 1` on a missing optional sibling kills a whole advertised pipeline. Both
  shapes are covered in `external-skill-pack-install`.
- Generate the token with `secrets.token_urlsafe`, write it into the service env file
  idempotently at mode `0600`, and print only length and prefix — never the value, and
  never in argv.
- Prove the reload before claiming it: the journal row for the new port owner, the token
  present in `/proc/<pid>/environ`, and a non-loopback 401. A service that answers
  `/health` proves only that it is up.

## Completion check
- `/v1/rag/docs` from a non-loopback source → `401` with a JSON body naming the gate
- the same path from `127.0.0.1` → `200`, and the internal consumers that use it still run
- a correct `Authorization: Bearer <token>` → `200`; a wrong one → `401`
- `/__auth?token=***` → `303` plus a cookie, and the cookie unlocks `/v1/*`
- the SPA shell and static routes → `200` (no white screen)
- a tampered, expired, future-issued, and pre-rotation ticket are all rejected
- unit + spare-port integration suites pass, and the public-entry limit is stated

## Related
- `livekernel-mail-intake` — the endpoint this gate protects, plus the host topology and
  the `7862` upload-step entry that must stay reachable.
- `livekernel-gate-and-verify` — the outbound price-stop gates (oversize, conflict), a
  different gate with the same land-it-and-prove-it discipline.
- `openclaw-process-scoped-kill` — scoped process control when a restart is the apply path.
- `external-skill-pack-install` — proving the produced artifact rather than the exit code.
