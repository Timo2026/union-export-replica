---
name: livekernel-gate-and-verify
description: |
  Adding, verifying, or lowering a livekernel gate on an outbound quote — oversize parts, geometry/text size conflict, any "cannot quote reliably" verdict — where the reply names no price and the reason reaches the customer in their language; plus the auto-clarify letter for a request that cannot be quoted yet. Use when a new HITL trigger is requested, a draft carries a price it should not, a quoteable request hangs in HITL on fields the engines default anyway, or an internal Chinese reason leaks into a localized email.
---

# livekernel Price-Stop Gates and HITL Reply Verification

## When to use
- A new "cannot quote this reliably" rule is requested (oversize, conflict, missing evidence)
- A draft or reply went out carrying a price it should not have
- A quoteable request sits in HITL on fields the quote engines default anyway, and the operator asks for that gate to be lowered
- A customer-facing email contains an internal Chinese reason or an English body for a German inquiry
- Proving a gate holds in the real mail pipeline (probe email → loop → context → draft)

## Steps

1. **Derive the threshold from the engine, never from intuition.** Read the deterministic
   engine's own banding first (`timo_engine/app/main.py:961` scores `max_d > 500` as
   "large travel"; `main_lite.py:247` brackets 7075 only for `200 < max_dim <= 500`).
   Then prove the new gate changes nothing already persisted.
   **Oversize baseline (602 contexts, 2026-09-23):** 403 carry `dimensions_mm`,
   0 exceed 500 mm, the largest is 260 mm.
   **Size-conflict baseline cannot be read from the context file.** `cat_controller`
   overwrites `dimensions_mm` with the drawing bbox (`cat_controller.py:285`), so a
   geometry-driven context stores the bbox as its text dimensions and every
   dual-dimension sample reads ratio 1.000 (measured: 27 of 27), which understates the
   real spread and would make any threshold look safe. Compare the text dimensions
   captured **before** the overwrite — the `_text_dims` snapshot the gate itself takes,
   or the raw `.eml` body — never the persisted `rfq.dimensions_mm`.

2. **Land the gate in four places, and only four.**
   - `config/policy.yaml` — the threshold, with the evidence in a comment above it. Edit the block **in place**, never a whole-file write: an overwrite here once destroyed every other section of the file (see `livekernel-rfq-filter` Pitfalls).
   - `services/verification.py` — a check in the 辟牟援推止 chain that calls `escalate("HITL")`
     and writes a marker on `rfq` (`_oversize`, `_geo_text_size_conflict`) holding the
     measured values, not just a boolean.
   - `services/lang.py` — one reason string, **in all four languages**.
   - `services/reply.py` — the HITL branch: strip the internal Chinese reason, insert the
     localized string, and suppress prices.

3. **Suppress prices across every source, not just the quote block.** The HITL branch has
   no price line, but `memory_phrase()` still emits prices from
   `own_quote_history`, `pending_followups`, and the RAG `quote_anchor.hits` shared scope.
   A RAG shared anchor from small parts leaked into a large-part reply as
   "vergleichbare Teile liegen aktuell bei 222.8". Pass
   `memory_phrase(suppress_prices=True)` whenever a price-stop marker is set; only
   price-free follow-up notes may survive.

4. **Keep the engine computing whatever it wants; the guard belongs to the reply.**
   A conflict does not zero `quote.unit_price` — that number is a deterministic output,
   not a promise. Never assert `unit_price is None` in a test; assert the *draft* carries
   no price. A gate that mutes the engine also destroys the audit trail.

5. **Localize every new reason string in all four languages.** `lang.py` renders every
   draft through `L(key, lang)`, so a reason left in Chinese ships a mixed-language email;
   that happened twice in one session (oversize, then conflict). Add the key under **all
   four** of `de/en/es/zh`, then generate one draft per language and assert the localized
   prefix appears. The internal reason stays in `verification.reasons` for the operator —
   strip it from the template, never from the audit.

6. **Return the full reply, not a summary.** `cat_controller.run()`'s `reply` dict must
   carry `body`, `lang`, and `kind`, because the API hands that dict straight to the
   caller for a fresh context and only falls back to disk (`_rehydrate_from_disk`) after
   a restart. A summary with only `subject`/`auto_send` makes every consumer — HITL
   panel, API, draft view — show an email with no body, while the freshly run context
   looks fine in its API response. Verify **both** paths: the disk file always holds the
   full draft, and the API must match it.

7. **Prove the gate in the real pipeline before reporting it.** Inject a probe `.eml`,
   let the background loop claim and process it, then read the persisted context.
   Read `data/contexts/<cid>.json`: the marker on `rfq`, `risk.multimodal_conflicts`,
   and `decision.reply`. Four traps that each produced a false negative here:
   - The STEP must be a **MIME part** of the `.eml`. The `_att/` directory is where the
     orchestrator *writes* extracted attachments; dropping a file there parses nothing,
     so no geometry and no conflict ever fire.
   - **Never read the consumer side through `TestClient(app)`.** It triggers the app
     lifespan, which starts a second puller and orchestrator and rewrites
     `data/mail_puller/state.json`'s `running`/`pid` over the production ones. Read the
     context file on disk — same source, no side effects.
   - Assert zero prices only on HITL/conflict drafts. A normal DONE/PASS quote is supposed
     to contain its price; a blanket assertion fails the healthy case.
   - `PRAGMA table_info` returns 6 columns, so `for (col,) in …` raises; set
     `crm.row_factory = sqlite3.Row` before `dict(row)`.

   **An edited file is not a live change, and an in-process check cannot tell you the
   difference.** livekernel is one long-running uvicorn; the puller and the orchestrator
   execute the modules loaded at process start, so code written after that timestamp
   changes nothing the live chain does — while running the same file yourself returns the
   right answer. Verified 2026-09-25: `mail_orchestrator.py` and `verification.py` were
   rewritten at 23:46 and the API server (`ss -ltnp | grep ':8888'` → pid 2664751) started
   at 22:27, so a context verified through `build_controller().run()` returned
   `CLARIFY` / `AUTO_CLARIFY` while the same body, pulled by the live loop into
   `RFQ-20260926-E42FFD`, was still judged `HITL` on `关键信息缺失` — the old code. Compare
   before reporting anything as live:
   ```bash
   ps -o lstart= -p $(ss -ltnp | grep ':8888' | grep -oE 'pid=[0-9]+' | cut -d= -f2)
   stat -c %y services/<edited>.py
   ```
   A file mtime after the process start means the change is not deployed, whatever an
   in-process run says. Restart (`livekernel-mail-intake` step 6), then re-derive the
   verdict from a mail the **loop** processed — not from your own `build_controller()` call.

8. **Read conflicts in both shapes.** `cat.run()`'s API result reports
   `multimodal_conflicts` as a list of type **strings**; the persisted context stores
   **dicts**. `"GEO_TEXT_SIZE_CONFLICT" in list_of_dicts` is False and looks like a
   missed detection. Write `any((c.get("type") if isinstance(c, dict) else c) == T
   for c in conflicts)` and re-check before concluding a gate failed.

   **Before that, print the shape you are about to assert on.** A wrong key name does
   not error — it returns empty, and empty looks exactly like a real negative finding.
   Four probes in one 2026-09-25 session were answered "nothing" for that reason: a
   reply read at the wrong nesting (`subject: None` while the draft existed), a RAG
   response read for `layers`/`evidence` when the endpoint returned
   `degraded`/`matches`/`source`, a module imported as `services.vector_store` when it
   lives at `services.flywheel.vector_store`, and an inbox row read for a top-level
   `state` that is nested at `pending.state`. Each empty answer was about to become a
   conclusion. Dump `sorted(keys())` (or `find` the module) once, then assert only
   against a key you have seen. Guard on any count: when an unrelated probe of the
   same source returns non-zero and yours returns zero, suspect the key.

9. **Lower a completeness gate by classifying fields, not by deleting the check.**
   When a quoteable RFQ hangs on HITL for "关键信息缺失", measure what the engines really
   require before loosening anything: `opc-fusion-quote` prices from `-m/-l/-w/-h` alone
   (7075 100×50×20 → ¥118.94, `--surface`/`--tolerance` default to 无/IT8, non-blocking) and
   the 7862 kernel answers to `{material,length,width,height}` with 三轴CNC/IT8/Ra1.6
   defaults. Measured 2026-09-25 on `RFQ-20260925-F7665D`: a computed price (unit 281.25)
   sat in HITL on missing `material, quantity, surface_finish, tolerance` — the gate was
   stricter than the engine, so the operator's "门禁太高" was a real defect, not a preference.
   Land it in the same four places as step 2 (`config/policy.yaml` →
   `services/verification.py` → `services/reply.py` → `agents/cat_controller.py`), with the
   fields split:
   - **Blocking** — `material`, `quantity`, `dimensions` (`policy.yaml` `quote_gate.blocking_fields`).
     Never default these: a material or size chosen by the system is a fabricated price.
   - **Defaultable** — `surface_finish`, `tolerance` (`quote_gate.defaultable`). Fill them,
     record every fill in `rfq._assumed_defaults`, and make sure the **customer-visible**
     quote names them — `verification.reasons` is operator-facing, while the PASS branch's
     body prints the rfq values and nothing there says "assumed".

   The blocking case becomes a new verification status **`CLARIFY`**
   (`order = {PASS, CLARIFY, HITL, BLOCKED}`, highest wins — a human factor outranks a
   clarification). Its draft is deterministic and obeys the same discipline from the other
   side:
   - **price-free and attachment-free**, even when the engine priced on defaults. Suppressing
     the attachment is the load-bearing part: a priced PDF/XLSX on a letter that asks which
     material is wanted is a quote nobody requested, and it defeats the gate.
   - `reply.mode = "auto_clarify"` plus `_clarify` on the verification result, routed through
     the state machine's `HITL` (no `CLARIFY` state exists, and only the state machine may
     move state) so the audit chain keeps its shape.
   - The **LLM draft rewrite is excluded** for `CLARIFY`: the missing-element list is the
     product, and a rewrite turns "which material, how many" into "under review" — the
     customer then answers no question and the mail needs a human anyway.
   - `_apply_quote_gate` runs **after** geometry enrichment. A STEP attachment fills
     `dimensions_mm`, so gating before that block misreads every drawing customer as missing
     dimensions and sends them a clarification letter for a part they already sent.

   **The orchestrator is the part that is easy to miss — it fell through here, and landed
   2026-09-25.** Its verdict map had no `CLARIFY` arm (`PASS/DONE → DONE`, `HITL → HITL`,
   `BLOCKED → BLOCKED`, `else → FAILED`), so `CLARIFY` was matched by `else` and became
   **`STATE_FAILED`** — terminal, marking the mail read, so no clarification was ever sent
   and the failure read as a pipeline fault. What landed, all in `mail_orchestrator.py`:
   - verdict arm `elif verdict_raw in ("HITL", "CLARIFY")` → `STATE_HITL`. `CLARIFY` keeps
     the HITL state on purpose: a clarification sent is not an approval, so the ledger
     still shows the mail as waiting.
   - `_try_auto_clarify(mail_id, context_id, result, email_data)`, called in a
     `try/except` after the state write — a clarification failure must never break the
     chain. Returns `False` on every gate and the mail stays in HITL for a human.
   - the draft is read **from disk** (`data/contexts/<cid>.json` → `decision.reply`),
     because `cat_controller.run()`'s return dict carries only a reply *summary*
     (`subject`/`auto_send`/`mode`); its `body` is in the persisted decision only.
   - four gates, in order, each verified by monkeypatching the sender (no real mail):
     `quote_gate.auto_clarify_enabled`; the disk draft must be `mode == "auto_clarify"`
     **and** `auto_send` truthy; a per-recipient cooldown (`auto_clarify_cooldown_hours`,
     default 24 h, state in `data/auto_clarify_cooldown.json`) that suppresses a repeat
     inside the window; and a **price-leak regex** on the body that rejects the send and
     leaves the mail to a human.
   - the send itself passes `quote=None, attachments=[]`, so `reply_sender`'s render
     branch takes `no_price` and **no priced PDF/XLSX is ever attached** to a letter that
     asks which material is wanted.
   - audit rows: `auto_clarify_sent` (with `to`, `context_id`, `from`),
     `auto_clarify_rejected` (carrying the regex hit), `auto_clarify_skipped`
     (`cooldown`/`empty_body`/policy or context read failure), `auto_clarify_failed`
     (SMTP or sender exception). Success then runs `_maybe_mark_read`.
   - **The four gates have no self-address arm, so a verification send to the sending
     account runs a real pipeline cycle.** Measured 2026-09-25 with an authorized
     real send: `_try_auto_clarify` → `True`, IMAP delivery confirmed (UID 146, 294-char
     body, 0 attachments, no price), `data/auto_clarify_cooldown.json` written — and the
     live loop then pulled that very mail back from the sender's own mailbox
     (`.eml` 121 → 122, `qq_9faa9222dfb5a0d1`), priced it into
     `RFQ-20260926-E42FFD`, and left a `HITL` row (`关键信息缺失: surface_finish,
     tolerance`). Four gates cleared because none of them asks who the recipient is:
     `reply_sender:106` only rejects an empty string or one without `@`, and the cooldown
     is keyed on `to_addr`, which suppresses the *next* send without preventing this
     cycle. The loop is therefore bounded at roughly
     `auto_clarify_cooldown_hours` rather than excluded outright. Decide the target before
     sending: **never point a verification at the sending account** (use a real
     recipient, or a policy-named test address); if a self-loop cycle has already run,
     recover by marking the pulled-back mail terminal
     (`mark_state(..., STATE_SKIPPED, consumer='selftest-cleanup')`) — the HITL count
     returned 12 → 11 and no 2 h escalation fired. A cooldown row is not evidence the
     loop cannot recur.
   Send mechanics stay in `livekernel-mail-intake` step 9. Re-verify the four gates after
   any change to the verdict map, the disk-draft shape, or the cooldown file.

10. **A priced auto-send now exists, and flipping `auto_send` in `reply.py` is still the
    wrong way to have built it.** Landed 2026-09-26 as `MailOrchestrator._try_auto_quote()`
    in `services/mail_orchestrator.py`, switched by `policy.quote_gate.auto_quote_send_enabled`
    (`false` is the escape hatch back to all-human). How the absence was recognized is the
    reusable part: the flag had **no reader in any `.py`** (`grep -rn auto_quote_send_enabled
    --include=*.py` returned 0) — it existed only as a comment in `config/policy.yaml`, so
    "the policy key is honoured" was never proven. Its sibling `auto_quote_threshold` has
    exactly one literal reader, `supplier_module/auto_threshold.py`
    (`p.get("auto_quote_threshold", {})`), that helper works at the 10/10 defaults, and
    `tests/test_policy_auto_threshold.py` pins the helper while naming the YAML key **zero**
    times. **A flag with no reader is a policy that does not exist** — grep for the reader
    before trusting any `*_enabled` key in `config/policy.yaml`.

    The split is the one step 9 proved: **the PASS branch of `reply.py` stays `draft_only`,
    and the send decision sits in the orchestrator** beside the audit trail. Two frozen
    tests make that non-negotiable — `test_golden_regression.py` asserts
    `reply["auto_send"] is False` on every scenario, and `test_openshell_policies.py` flips
    `auto_send` to `True` on a golden-chain payload and asserts the iron rule rejects it.

    Eight gates, each reusing a check that already exists rather than restating it (a second
    implementation of the margin rule is how two gates drift apart):
    1. `auto_quote_send_enabled` — the switch itself.
    2. `decision.status == "PASS"` — already the conjunction of every
       `hitl.auto_send_allowed_only_when` condition (no DFM hard conflict, no multimodal
       conflict, margin above floor, tolerance not precision, amount below gate, evidence
       sufficient); `guardrails`'s `never_auto = {"BLOCKED", "HITL"}` leaves PASS sendable.
    3. Commercial completeness: `unit_price > 0` and a `final_price`/`total_price`.
    4. The persisted `reply.guardrail_output.pass`, read from disk.
    5. **Price equality**: the body must carry the engine's `unit_price` and `final_price`.
       This is the one gate a price-free letter does not need, because a priced letter is the
       artifact where a wrong number is a commitment. Accept the formatting variants an LLM
       draft or a currency conversion legitimately produces (`41,798.57` vs `41798.57`) by
       testing `{str(v), f"{v:g}", f"{v:.2f}", f"{v:,.2f}"}` — otherwise the gate kills every
       good draft. A body whose figure was rewritten is rejected to `auto_quote_rejected`,
       never sent and never scrubbed.
    6. `auto_quote_threshold` — `features_count` and `process_route_count` both under
       threshold (v2.3.0, additive, not a substitute).
    7. **Self-send guard**: the recipient must not be the mailbox's own account. Without it
       the priced letter runs the same self-loop cycle step 9 measured for the clarification
       letter — the live puller takes the mail back and prices it again, and the cooldown only
       bounds the cycle instead of excluding it. Read the account from
       `load_credentials(...)["account"]` at call time, never from an address written down
       anywhere.
    8. Idempotence: one auto-quote per `context_id` (`data/auto_quote_sent.json`), so a
       reprocessed or re-delivered mail is never quoted twice.

    Read every gate input from `data/contexts/<cid>.json`, not from `cat.run()`'s return —
    that dict carries the quote and a reply *summary*, while the body, the attachments, and
    `guardrail_output` live in the persisted decision. On any gate failure the mail stays
    `DONE` for a human `/v1/rfq/{cid}/send-reply`; audit rows separate `auto_quote_sent`
    (with the price it sent), `auto_quote_rejected`, `auto_quote_skipped` (naming the gate),
    and `auto_quote_failed` (SMTP). `OrchestratorResult.quoted` plus a `quoted` key on
    `pipeline_done` make it observable without opening the context file.

    **Two things still unproven, so do not report this as live-verified end to end.**
    (a) The full eight-gate path has not sent to a real customer address — gate 7 correctly
    refuses the sending account, so the verification run was a **direct** `send_quote_reply()`
    with a real engine context and real PDF/XLSX artifacts (`ok=True`, IMAP UID 146, both
    attachments intact, `222.8`/`9413.3` in the body). Each gate itself is covered by
    monkeypatched-sender unit tests in `tests/test_auto_quote.py` (15 cases).
    (b) Step 7's live-code rule applies unchanged: the uvicorn process serving 8888 loaded
    the old modules at start, so until it is restarted the deployed chain still takes a PASS
    mail to DONE with no reply sent — whatever a fresh `build_controller()` run reports.

## Pitfalls
- A STEP attachment whose bbox is smaller than the body text overwrites the text dimensions
  (`cat_controller` prefers the drawing). Test an oversize gate with **no attachment**, or
  with a drawing whose bbox actually matches the case under test — otherwise the gate is
  never evaluated and the run reads as PASS.
- `multimodal_conflicts` with `conflict_action: HITL` and `tolerance_delta_mm: 0.005` are a
  separate, precision-tolerance lane. A geometry/text size conflict is reported through the
  same list but measured by ratio; do not reuse the mm tolerance for it.
- The gate is advisory for the operator: `auto_send` stays false and the verdict stays
  `HITL`. Approval is a human decision, never a chain side effect. The two exceptions are
  the price-free clarification letter of step 9 (per `quote_gate.auto_clarify_enabled`) and
  the eight-gated priced auto-quote of step 10 (per `auto_quote_send_enabled`); neither is
  approval for anything else, and each has its own gate list and audit rows.
- Existing contexts are the ground truth for "did I break anything": record the pre-change
  pass/fail counts and compare after, rather than assuming a green run means unchanged.
  (Baseline on 2026-09-23: 801 passed / 26 failed; after the gates and their tests, 802/26.)
  **When no baseline was recorded, restore the backups instead of investigating per failure.**
  A full-suite run on 2026-09-25 reported `38 failed, 1019 passed` after six files were edited;
  copying the pre-change files back over them and re-running reproduced the *identical*
  numbers (`38 failed, 1019 passed`, same file list), which proved all 38 pre-existed and
  the edit introduced none — a conclusion reachable in one re-run, not by walking 38
  tracebacks. Keep every original in `/tmp/ab_stash/<task>/` precisely so this is possible,
  and restore the edited versions (md5-verified) before continuing.
- **`openshell.violations` accumulates across requests in production, so its length proves
  nothing about the current request.** `/v1/agent/task` reuses one module-level dispatcher
  (`get_dispatcher()` in `skill_dispatcher.py`), so a single `OpenShell` instance collects
  `violations` for the whole process lifetime. Observed 2026-09-23: consecutive responses
  reported 4, 5, 6 … 20 violations, capping at 20 and resetting only when the service
  restarted, and every response carried a stale `local-only` violation naming a path from a
  much earlier request. A non-empty list is therefore not evidence this request broke a
  rule, and a long batch produces more violations per response with nothing new going wrong.
  Whenever a conclusion depends on violations — the iron-rule-1 lock in step 4, the
  conflict list in step 8 — establish a baseline with one known-clean request (or restart
  and compare) before claiming a gate fired or an override was attempted.

## Related
- `livekernel-mail-intake` — the three intake gates, what the fetch marks seen, and acceptance checks
  a probe email must survive; the iron rules are recorded there. Its step 9 is the send
  mechanics (egress gate, credential key, approval) that both the auto-clarify letter of
  step 9 here and the priced auto-quote of step 10 reuse, and its step 8 delivery
  verification applies to each of them.
- `livekernel-offline-engine-bridge` — env loading and absolute paths when a hand-run needs
  real geometry; `volume_source` tells a parsed shape from a default.
- `external-mail-system-audit` — the same silent-degradation checks for a vendored package.
- `livekernel-endpoint-auth-gate` — the **inbound** counterpart: access control on the API
  port (Bearer + session cookie, loopback exemption), which stops a request rather than a quote.
- `livekernel-rfq-filter` — the upstream intent tier and the `intake.py` extraction gaps.
  A missing-field HITL row is sometimes an extraction gap (a missed quantity unit) rather
  than a gate defect, so check there before re-tuning any threshold.
