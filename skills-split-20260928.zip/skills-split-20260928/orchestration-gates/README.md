# orchestration-gates
skill 编排、质检闭环、SOP 路由、交付门禁与验证
## 内容
- 16 个 skill / 122 个文件 / 0.6M
- `hermes/openclaw-imports/` — 3 个 skill（原 ~/.hermes/skills/openclaw-imports/）
- `livekernel/` — 8 个 skill（原 ~/timo_livekernel/skills/）
- `openclaw/` — 3 个 skill（原 ~/.openclaw/skills/）
- `openclaw/agents/main/agent/workshop-skills/` — 2 个 skill（原 workshop-skills/）

## 跨仓依赖

依赖全部业务 repo 的 skill 本体

## 部署

```bash
# 与本仓同系列的其他仓库一起部署到同一框架目录
# skill 名即目录名，直接按 framework 拷回原路径
```
