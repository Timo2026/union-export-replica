---
name: livekernel-drawing-pack-quote
description: |
  报价表 / batch pricing of an entire drawing pack (BOM xlsx + STEP + PDF) into an
  XLSX quote table with per-row B-rep geometry, PDF tolerance, material prices, and
  a coverage-gap list. Use when a pack arrives and a quote table, all-parts pricing,
  or coverage accounting is requested. Complements livekernel-offline-engine-bridge,
  whose geometry contract every row depends on.
---

# livekernel Drawing-Pack Batch Quote

## When to use
- A drawing pack arrives (BOM spreadsheet plus many STEP/PDF files) and a quote table, 报价, or all-parts pricing is requested
- A batch price must state its coverage honestly rather than reporting a sample's total as the pack's price

## Steps

1. **Read the BOM before quoting anything.** The pack's part list is an xlsx living beside the drawings — find it first: `find <inbound> -type f ! -iname '*.step' ! -iname '*.pdf'`, usually the only non-drawing file. It carries each row's material, surface sequence, and **quantity**, none of which any filename contains. Never quote a hand-picked sample with a guessed quantity: observed 2026-09-23, a 410-row BOM / 2,739-piece pack produced a 6-part 24-piece table and every figure had to be redone once the BOM was finally read. Bind each row to its drawing by stem `<code>-<name>-V1.0.STEP`.

2. **Bind STEP and PDF by that same stem.** In an exported pack they are 1:1 (here 234 STEP / 234 PDF, every stem paired). Tolerance and technical requirements live only in the PDF — `GB/T 1804-m` appears inside the 技术要求 block. Extract with `pypdf` plus a regex and carry the result into its own column, so the tolerance coefficient is traceable to a sheet. A row with no STEP cannot be priced; that is a gap to flag, not a row to price from defaults.

3. **Count parsed geometries against the BOM, per row.** Each row's weight is `parse_step`'s B-rep volume, called exactly as `livekernel-offline-engine-bridge` steps 2–3 require — **absolute** path for a hand-run (the bridge subprocess runs with `cwd=engine_src`, so a relative path yields `file_size: 0` and `fallback_all_failed`, which silently priced **0/230** parts on 2026-09-23 while every call still returned), and the whitelisted `data/...` relative form through `/v1/agent/task`. After the run assert `n_parsed == n_with_step`; one quiet fallback poisons the whole batch, and a table holding a handful of rows in place of hundreds reads as a data shortage rather than a parse failure.

4. **Extract in parallel, and price from one background run.** `ThreadPoolExecutor(8)` over `file_intake.parse_step` at ~1 s per drawing turned 230 drawings into 32 s on 20 cores; PDF text extraction took 9 s for 230. Hold the whole extract → price → write-XLSX pipeline in a single background script rather than driving it through many interactive turns: keep extraction and report generation as two turns, not one round trip per part. Diagnose any complaint about a slow response against the engine's own trace (a run here reads 72–81 ms per request) before attributing latency to the kernel.

5. **Price each row from its own BOM fields; never invent a missing one — and read which materials the engine actually prices.** `MAT_PRICE_PER_KG` (18元/kg entries: `6061` 200, `304` 575, `316l` 626, `7075` 502, `q235` 298, `45#`/`45钢` 160, `abs` 50, `pom` 80, `440c` 575, `yg8` 800, `h59`/`黄铜` 1915, `tc4`/`钛合金` 6267) covers brass, 440C, POM, YG8, and ABS, while `PEI` and `17-4PH` have no entry at all. The catch is that the match is an **exact** key match, so a BOM name carrying a modifier — `POM 白色`, `YG8钨合金`, `316L不锈钢` — misses and is then priced as 6061 at 200元/kg without a word. Do not hand-maintain that judgement in the batch script: `services/material_map.py` (added 2026-09-23) returns `exact` / `approx` / `unknown`, and `scripts/batch_quote.quote_bom` marks `unknown` rows `NEED_PRICE` with a reason. Read `material_recognized` back from each quote as the independent check. **An `exact` verdict is not permission to pass the BOM name through** — substitute the engine key for `exact` rows too. `quote_bom` once rewrote `material` only for `approx` rows (2026-09-23), so `304不锈钢` reached the engine's exact key lookup unrecognized and 70 of 410 rows priced at 6061's 200元/kg; read `material_recognized: false` on any priced row as the signal. The trap's scale depends on weight, not on the row count: those 70 rows moved a 410-row total by ¥0.54 because the parts weighed milligrams, while the same mapping on a 4.22 kg 304 part under-quoted by ¥3,295 each. Never read a small delta as proof the mapping is safe. **Completion check:** priced rows + missing rows equals the BOM row count, and the missing rows are enumerated with the reason each one needs.

6. **Emit the table plus two gap sheets, not one.** The priced table carries: code, name, BOM material, material actually priced, qty, surface sequence, tolerance (noting its PDF origin), B-rep volume, weight, machining hours, material/machining/surface cost, unit price, row total, status, and technical requirement. Then two companion sheets — a `待补清单` enumerating every unpriced row with the action it needs (补 STEP 文件 / 补材料价格库, aggregated by material), and an `近似计价警示` listing every row priced through an `approx` substitution with the note saying which material stood in. That third sheet is not optional: a row priced at 6061 rates because `PEEK` maps there is a number a customer could accept, and it must be visible to whoever reviews the table. **Completion check:** both gap sheets exist, their row counts match step 5's counts, and priced + missing rows still equals the BOM row count.

## Pitfalls
- BOM rows and drawings disagree in both directions: here 410 BOM rows bound to 230 STEP files while the directory held 234, so 180 BOM rows had no CAD (127 零件, 4 装配件, 49 工装) and 4 drawings bound to no BOM row. Account for both — state the bound counts ("已报价 213 项 / 410 项"), never a coverage percentage, and never the raw directory file count as the matched count.
- The uniform-quantity trap: quoting every part at the same qty misstates both sides. The BOM's own 数量 column is the only source.
- A pack total is not the pack's price until the missing rows are enumerated; otherwise the table is a quote for a subset presented as the whole.
- **`material_map.py` verdicts describe the mapping, not the pass-through.** `exact` means the engine has a key for this material — it does not mean the BOM's Chinese name is that key. Substitute the key for every verdict (`exact` and `approx` alike); only `unknown` legitimately carries no key, and those rows are `NEED_PRICE`. An `exact` row sent by BOM name is indistinguishable in the output from an unmapped material: both quote confidently at aluminum rates with `material_recognized: false`.

## Related
- `livekernel-offline-engine-bridge` — the exact geometry call contract (env loading, absolute path, `volume_source`) that every row of this batch depends on.
- `livekernel-mail-intake` — when the pack arrives as mail attachments instead of a staged directory; `services/inbound_scanner.py` (added 2026-09-23) automates that entry, scanning `data/inbound/`, extracting zips safely, and calling `quote_bom` idempotently, so read `data/inbound_scanner/state.json` before assuming a pack still needs a manual run.
