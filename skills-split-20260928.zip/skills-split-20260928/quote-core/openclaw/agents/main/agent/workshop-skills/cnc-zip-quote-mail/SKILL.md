---
name: "cnc-zip-quote-mail"
description: "CAD zip 图档自动报价并回报价邮件；产出 STEP 真几何报价单。"
---

# CNC ZIP 报价发信管线

从客户 zip 图档包一路做到报价邮件，每步都有已实证的坑。

## 步骤

1. **定位 zip**：先找 `~/.openclaw/media/qqbot/downloads/`，再看 `~/timo_livekernel/data/inbound/`。同名 zip 可能多份，用 `unzip -l` 比对文件数与总大小后再选定。
2. **解压到 `/tmp/ab_stash/<任务名>/`**（勿 `rm`，trash 优先）。`unzip -l | grep -c '\.STEP'` 与 PDF 各计一次；STEP 数 ≠ 零件数时警惕一文件多实体。
3. **几何提取用 OCP，不要正则扫 CARTESIAN_POINT**：正则会把构造/辅助几何点算进包围盒。实测底座主体真包络 1000×1200×**75.5**mm，正则算出 1089mm，单价虚高 10 倍。逐 Solid `AddOptimal` 取并集，跳过空体，多实体件单独标记。环境 `~/miniconda3/envs/lk-skills/bin/python`（cadquery 2.8 + OCP）。正则兜底数字要能吃科学计数法：`[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?`，用 `[\d.eE+]` 会在 `E-002` 上炸。
4. **解析 BOM xlsx**：`zipfile` 解 `xl/sharedStrings.xml` + `xl/worksheets/sheet1.xml`，按 `cs[0].isdigit() and cs[1].isdigit()` 筛数据行。BOM 行数与 STEP 数常不一致，只给有图档的报价，邮件里明说缺口，不脑补。
5. **调 opc-fusion-quote**：`fusion_quote(material,length,width,height,quantity,processes,tolerance,surface)`。先确认这两处 patch 还在，否则报价必错：
   - `surface_cost *= quantity` 已删：整批表面费原先进单价公式（材料/机时都是单件值），致 `unit∝qty`、`total∝qty²`，实测 50 套/1 套 = 930 倍爆炸。修法：单件值进单价，整批值单列 `batch_surface_cost`。
   - `parse_step_bbox` 已改 OCP 优先。
   校验判据仅两条：`total == unit*qty`，total 随量单调递增。单价随量下降是正确行为（阶梯折扣），不要写成断言。
6. **出报价单**：openpyxl 生成 XLSX（明细 + 数量档汇总 + 单价矩阵三表），`soffice --headless --convert-to pdf` 出 PDF。写完必须 `load_workbook` 读回校验表头、首末行、合计公式。
7. **发送**：能不能发、走哪条路、批准门槛，一律以 `livekernel-mail-intake` 步骤 9 为准（本项目不重复该政策）。本项只补执行细节：在当前这轮对话已拿到操作者明确外发授权时，可直接调 `services.reply_sender.send_quote_reply()` —— 它与 `/v1/rfq/{cid}/send-reply` 是同一个函数、同一道 egress 闸、同一份审计落盘，只是少了 endpoint 层的 `human_approved` 校验，所以**授权必须写进 `approver=` 字段**留痕。**必须 occ 环境 + 先 source livekernel.env**，否则凭据解不开：
   ```bash
   cd $HOME/timo_livekernel
   set -a && . $HOME/union-deploy/livekernel.env && set +a
   $HOME/miniconda3/envs/occ/bin/python send_quote.py
   ```
   `lk-skills`/`vidproc`/`dfam` 都没 `cryptography`，直接跑会 `password=None`（本机 `occ` 有 50.0.1）。
8. **验证投递**：读 `data/sends/<cid>.jsonl` 审计，再 IMAP 查寄件箱。**不要用 `SEARCH SUBJECT <cid>`**——主题是 MIME `=?utf-8?b?...?=`，明文 SEARCH 恒 0 命中，会误判未送达。用 `SEARCH ALL` 后 fetch 最后几封的 `BODY[HEADER.FIELDS (SUBJECT TO FROM DATE)]`。

## 易错点

- 客户指示统一换材料（如"全部 7075"）与原图 BOM 材质不一致时，先按指示出，邮件里明确说明差异与可另出版，不静默改。
- 包络 >500 mm 超大件与 fill_ratio<0.05 小填充率件单独标记，建议人工二次工艺评审。
- 报价是估算，邮件带"正式下单前确认"与有效期（默认 14 天）。
- 超大件包装运费单独核算，别混进机加费。

## Related

- `livekernel-mail-intake` — 步骤 9 是外发授权的权威口径（人工批准、egress 闸、凭据键、投递验证）；本管线步骤 7–8 只补执行细节，不重复该政策。
- `livekernel-drawing-pack-quote` — 同族但不同的任务：图档包在**本机落地**、经 livekernel 引擎按 BOM 逐行出价，并管 zip 入站扫描与覆盖缺口账。当包是 BOM 批量件而不是 QQ 附件、或价格必须来自本地 CNC 内核而不是 `opc-fusion-quote` 时读它。
- `ocp-geometry-code` — 步骤 3 包围盒背后的 OCP/CadQuery 陷阱（typed accessor、extrude 方向、写后读回）。
