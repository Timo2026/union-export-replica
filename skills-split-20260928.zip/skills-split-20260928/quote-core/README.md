# quote-core
报价引擎：CNC/铝件报价、标定与纠偏、Golden Chain 报价链、邮件报价
## 内容
- 19 个 skill / 151 个文件 / 1.8M
- `hermes/openclaw-imports/` — 5 个 skill（原 ~/.hermes/skills/openclaw-imports/）
- `livekernel/` — 7 个 skill（原 ~/timo_livekernel/skills/）
- `openclaw/` — 5 个 skill（原 ~/.openclaw/skills/）
- `openclaw/agents/main/agent/workshop-skills/` — 2 个 skill（原 workshop-skills/）

## 跨仓依赖

依赖 cad-dfm-process 的图纸解析结果作为报价输入

## 部署

```bash
# 与本仓同系列的其他仓库一起部署到同一框架目录
# skill 名即目录名，直接按 framework 拷回原路径
```
