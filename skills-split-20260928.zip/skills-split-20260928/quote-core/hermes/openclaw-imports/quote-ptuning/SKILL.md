name: quote-ptuning
description: CNC加工报价 - 基于P-Tuning学习的精准报价系统
capabilities:
- name: generate_quote
  description: CNC加工报价计算 - P-Tuning精准报价系统
  parameters:
  - name: part_name
    type: string
    required: true
    description: 零件名称
  - name: material
    type: string
    required: true
    description: 材料(如6061-T6, 304不锈钢)
  - name: surface
    type: string
    required: true
    description: 表面处理(如阳极氧化黑)
  - name: quantity
    type: int
    required: true
    description: 数量
  output: 报价JSON
  invoke:
    type: cli
    command: $HOME/miniconda3/envs/lk-skills/bin/python $HOME/.openclaw/skills/quote-ptuning/scripts/quote.py
      {{{part_name}}} {{{quantity}}} {{{material}}} {{{surface}}}
  example: '{"part_name":"法兰","material":"6061-T6","surface":"阳极氧化黑","quantity":10}'
materials:
- 材料(如6061-T6
- 304不锈钢)
invoke:
  type: python_function
  module: quote-ptuning.scripts.main
  function: run
