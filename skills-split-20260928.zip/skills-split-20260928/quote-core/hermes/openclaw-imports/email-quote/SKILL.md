---
name: email-quote
description: "邮箱报价员工 - 自动扫描QQ邮箱提取客户需求，生成专业XLSX报价单并自动回复。支持邮件扫描、STEP附件提取、信息提取、智能追问、报价单生成、自动发送。当需要邮件自动报价时使用此技能。"
metadata:
  category: communication
  source: CodeBuddy-CNC-Skills
  version: "1.1.0"
  triggers:
    - 邮件报价
    - 邮箱报价
    - 自动回复报价
    - QQ邮箱报价
    - 客户报价
---

# email-quote

**Category:** communication  
**Version:** 1.1.0

邮箱报价员工 — 自动扫描邮箱，提取客户需求，生成报价单并回复。

## 核心特性

- **邮件扫描**: 自动扫描 QQ 邮箱新邮件
- **STEP 附件提取**: 识别 CAD 图纸附件
- **信息提取**: 自动提取材料/数量/公差/表面处理
- **智能追问**: 缺失信息时自动回复客户追问
- **报价单生成**: 生成专业 XLSX 报价单
- **自动发送**: 报价完成后自动回复客户

## 工作流程

```
扫描邮件 → 提取附件+信息 → 检查完整性
  ├─ 信息完整 → 调用报价系统 → 生成XLSX → 回复客户
  └─ 信息缺失 → 生成追问邮件 → 等待客户回复
```

## 配置

配置文件位置: `~/.codebuddy/skills/email-quote/config/email_config.json`

```json
{
  "imap_server": "imap.qq.com",
  "imap_port": 993,
  "smtp_server": "smtp.qq.com",
  "smtp_port": 465,
  "email_addr": "your@qq.com",
  "auth_code": "授权码",
  "scan_interval_minutes": 5,
  "auto_reply_missing": true
}
```

## 数据存储

- 任务数据库: `~/.codebuddy/skills/email-quote/config/quote_tasks.db`
- 工作目录: `~/.codebuddy/skills/email-quote/workspace/`
