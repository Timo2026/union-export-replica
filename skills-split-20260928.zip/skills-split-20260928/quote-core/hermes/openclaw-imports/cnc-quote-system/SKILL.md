---
name: cnc-quote-system
description: "CNC智能报价系统 - 基于RAG的制造零件报价工具。支持材料检索、成本估算、风险预警。当用户需要CNC零件报价、制造成本估算或知识库检索时使用此技能。"
metadata:
  category: manufacturing
  source: OpenClaw-CNC-Skills
  triggers:
    - CNC报价
    - 零件报价
    - 制造报价
    - 材料成本
    - 加工费
---

# cnc-quote-system

**Category:** manufacturing

CNC智能报价系统 - 基于RAG的制造零件报价工具。支持材料检索、成本估算、风险预警。当用户需要CNC零件报价、制造成本估算或知识库检索时使用此技能。

## Usage

To use this CNC manufacturing skill:

1. Identify the manufacturing parameters (material, dimensions, quantity, surface treatment)
2. Execute the skill's main script or function
3. Review the generated quote/report

## Bundled Scripts

The following scripts are available in the `scripts/` directory:

- `cnc_quote_engine.py` - Executable component
- `hybrid_retriever.py` - Executable component
- `case_retriever.py` - Executable component
- `risk_control.py` - Executable component

To execute a script:
```bash
python scripts/cnc_quote_engine.py
```

## Configuration & Assets

Available configuration and asset files:

- `config.json`
- `cases.json`
- `requirements.txt`

