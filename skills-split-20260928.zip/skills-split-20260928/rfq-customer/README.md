# rfq-customer
RFQ 解析、客户健康/挽留、供应商匹配、客户沟通与回信
## 内容
- 12 个 skill / 35 个文件 / 0.1M
- `livekernel/` — 9 个 skill（原 ~/timo_livekernel/skills/）
- `openclaw/` — 1 个 skill（原 ~/.openclaw/skills/）
- `openclaw/agents/main/agent/workshop-skills/` — 2 个 skill（原 workshop-skills/）

## 跨仓依赖

依赖 quote-core 的输出格式与 cad-dfm-process 的规格抽取

## 部署

```bash
# 与本仓同系列的其他仓库一起部署到同一框架目录
# skill 名即目录名，直接按 framework 拷回原路径
```
