# Probe Residue in the RAG Vector Store

Why a cleanup pass over sqlite / mailbox / ledger / context files can leave probe mail
still reachable, and what actually removes it.

## The store's shape

`data/rag_vectors.json`, shaped as a **flat** dict per collection with no `points`
sub-key:

```json
{"conversations": {"<point_id>": {"vector": [...], "payload": {...}}}}
```

`VectorStore` is a facade with **no** `_collections` attribute of its own. The data is
at `store._backend._collections`, which is why `gw.store._collections.get(...)` raises
`AttributeError` in any ad-hoc script. `gw.store._backend._collections[COLL][id]` is
the reachable path; `_backend` also exposes `.delete()`.

Production collections observed (2026-09-23, 613 points): `quote_history` (1),
`ingest_docs` (7), `conversations` (610). A point's `payload.customer_id`,
`payload.tags`, and `payload.embed_source` are what identify a probe's residue.

## Two consequences for cleanup

**(1) The other stores are not enough.** Deleting probe mail from CRM sqlite, the
mailbox directory, the ledger, and the contexts leaves its `conversations` and
`ingest_docs` points behind — and those points are still served to later replies.

**(2) Editing the file under a running livekernel does not stick.**
`JsonFileBackend` holds the whole store in memory and `_save()` writes it back
**whole**. Every subsequent upsert rewrites the on-disk copy from memory, restoring
whatever was deleted. Delete through a **live instance** (its API or a session running
the service), or back up → edit → restart → re-read before claiming a probe is gone.

## Deleting, and proving it

1. Back up `data/rag_vectors.json` first — it is the only copy and a bad edit is not
   recoverable from the other stores.
2. Prefer the running instance: delete through the service, so memory and disk agree.
3. Verify by **counting, not parsing**:
   ```bash
   grep -c '<marker>' data/rag_vectors.json
   ```
   The file is tens of MB; `json.load` or `cat` floods the transcript.
4. Confirm the counts and the customer coverage after the delete, and again after any
   restart, since the restart is what proves the write is not memory-only.

## Pitfalls

- Two different failure modes look alike: a point missing from **all** the other stores
  while still present here is probe residue, whereas a point present everywhere except
  the contexts is a dropped-caller-argument problem (see `livekernel-mail-intake`
  step 5). Check which layers hold it before deciding what to fix.
- Deleting a point that a still-queued mail will re-ingest only removes it until that
  mail is processed. Wait for the queue to reach a terminal state, or the residue
  returns.
- A "0 matches" grep on the pre-delete file means the marker string is wrong — the
  file is readable, so a negative here is a bad pattern, not a clean store.
