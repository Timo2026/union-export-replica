# Credential Gate: Secret Mismatch

Read this when `/v1/mail/puller/status` reports `enabled: false`, or `autostart` reads
`{"state": "disabled"}`, while `data/gmail_settings.json` looks correct **and**
`data/credentials.json` still lists the service. Step 2 covers the file's shape and the
cipher-format states; this file covers the state where the file is right and the reads
still all fail.

## The key depends on the process, not the file

`_derive_key()` is `sha256(_APP_SECRET + _machine_seed())`, so **every** `fernet` entry's
password depends on the `UEA_APP_SECRET` the running process carries. Restart livekernel
without the same secret the entries were saved under and `load_credentials()` returns
`None` for **all** of them — while `status()` still lists them, still reports
`fernet_available: True`, and still shows each entry's `cipher`.

**All services failing together is the signature that separates this from one bad
entry.** A single failed key is an entry problem (step 2); every key failing at once is
the secret.

Downstream it reads as `is_enabled() → false`, `autostart: {"state": "disabled",
"attempts": 1}`, a `state.json` `pid` that no longer exists in `/proc`, and
`total_pulled` frozen at its last value. Nothing is broken: the puller was never
started. That is why a **frozen** queue and a **stalled** one look identical — the
difference is only in the process list, so read it before concluding anything.

```bash
tr '\0' '\n' < /proc/<pid>/environ | grep -c '^UEA_APP_SECRET$'   # 0 here + entries on disk
```

Observed 2026-09-25: the 09-24 instance that had pulled 74 mails was gone, the restart
came up without the secret, and `pending.jsonl` had stopped advancing eight hours earlier.

## Recovering

Exhaust route A before declaring the value gone, and say what you swept. Only the secret
is unknown — `_machine_seed()` is `sha256(MAC + hostname)[:16]` and is computable on the
host, so every candidate can be tested offline with
`Fernet(urlsafe_b64(sha256(secret + seed)))` against each entry's `encrypted` field. Sweep
every env file, every live process's `environ`, and every json/yaml/env scalar on the box.
Measured 2026-09-25: 1380 config files yielded **256,040 distinct candidates and zero
decrypted any of three entries** — that number is what turns "cannot find it" into a
finding. `grep -rl UEA_APP_SECRET` proves only that the *string* appears somewhere
(code, a log line, a skill doc), never that the value is present.

Then take route B in this order: **put the secret in the process's environment, restart,
then re-save.** Re-saving rewrites the entry under whatever secret the current process
carries, so a save made while the process holds none lands as `base64-insecure` — it reads
back fine while being unencrypted.

The durable fix is `union-deploy/livekernel.env`, the file `node_services.sh` sources
(`_run_livekernel()`, ~line 128) immediately before `exec uvicorn`. It carried
`UEA_API_TOKEN` but no `UEA_APP_SECRET`, so **every** restart dropped the key and
reproduced the outage — that is why a manual restart alone does not close the incident.
Append `export UEA_APP_SECRET=<random>` there at mode `0600`, leaving the existing lines
byte-identical. Then prove the restart carries it by hashing both sides, never by
trusting the env — the `export ` prefix differs between them, so strip it on both or both
read empty:

```bash
tr '\0' '\n' < /proc/$PID/environ | sed -n 's/^UEA_APP_SECRET=//p'  | md5sum
sed -n 's/^export UEA_APP_SECRET=//p' livekernel.env                 | md5sum
```

**Append idempotently — a second line for the same variable silently wins.** A failed
append left the file with a real `UEA_APP_SECRET=<64 chars>` line followed by an empty
`UEA_APP_SECRET=`, and the shell's last-wins rule made the empty value override the real
one on every subsequent source. After any write, assert exactly one non-empty line for the
key and keep the file at `0600`.

Verify with `load_credentials(<key>)` returning a password, not with `status()`, which
stays green either way.

## Inspecting a secret file without reading it

A check that only needs *whether a key is set* must not run a substitution over the whole
line. Measured 2026-09-25: `sed -E 's/^([A-Za-z_][A-Za-z0-9_]*)=.*/\1=<redacted>/'` was
used to list `livekernel.env` keys and **printed two live secrets** verbatim, because that
regex never matched `export KEY='value'` (the `export ` prefix, and any quoting, make the
key pattern fail) so the line passed through unchanged. The redaction looked like a
redaction, which is what made it worth reporting rather than withholding.

Use a form that cannot pass a line through when the pattern misses:

```bash
cut -d= -f1 <file> | sed 's/^export //'      # keys only; a miss leaves the value behind
awk -F= 'NF{print $1}' <file | sed 's/^export //'
grep -c '^export KEY=.\+' <file>             # existence only — the safest default
```

**Verify the redaction itself before reporting.** Echo the command on a file whose values
you know are non-sensitive, or `grep -c '=<redacted>'` the output equals the expected key
count. When a value has already reached a transcript, stop re-printing it, state which
keys are exposed, and treat them as rotated.

## Rotating a secret invalidates every stored entry

`_derive_key()` makes the ciphertext depend on `UEA_APP_SECRET`, so **changing that
variable makes every existing `fernet` entry undecryptable** — `load_credentials()`
returns `None` for all of them and the mail path stops at `no_credentials`. Rotate in an
order that does not take the system with it:

1. rotate `UEA_API_TOKEN` (and any other non-cipher key) first — it affects nothing
   encrypted;
2. for `UEA_APP_SECRET`, append the new value idempotently at `0600`, restart, then
   **re-save every credential entry** so it is rewritten under the new key
   (`save_credentials()` then `load_credentials()` returning a password is the check);
3. only then confirm the puller reads `enabled: true` with the new secret in
   `/proc/<pid>/environ`.

A rotation performed without step 2 reads exactly like the outage this file describes —
same `status()` output, same `None`, no way to tell a leak response from a lost value.

On this host (2026-09-25, after an exposure incident): `livekernel.env` carries exactly
one non-empty `UEA_APP_SECRET` line and no empty override, the API server carries the
variable, and `load_credentials('qq')` returns a 16-character password through the `occ`
interpreter — so both the entries and the process are consistent and the rotation, if
wanted, must still be done in the order above.
