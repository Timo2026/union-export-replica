# livekernel Restart: In-Flight Ledger Safety

Read this before and after `node_services.sh restart livekernel` (SKILL.md step 6) when
`data/mail_puller/pending.jsonl` holds work in flight. A restart drops in-memory state
only; everything below concerns the ledger the operator asks about.

## Before: the go condition and the snapshot

The ledger is **append-only** — one `mail_id` occupies as many rows as it was processed.
Count distinct `mail_id`s, not rows: measured 2026-09-26, 14 `HITL` rows were 8 mails,
and `/v1/mail/puller/status`'s `pending.by_state` is already that deduped view
(`HITL: 8` against 14 rows). Report the deduped number.

A restart loses nothing when no row is `PROCESSING` (no half-run engine task):

```bash
cd ~/timo_livekernel
python3 - <<'PY'
import json
rows=[json.loads(l) for l in open('data/mail_puller/pending.jsonl') if l.strip()]
print('PROCESSING:', sum(r.get('state')=='PROCESSING' for r in rows))
h=[r for r in rows if r.get('state')=='HITL']
print('HITL rows:', len(h), '| mails:', len({r['mail_id'] for r in h}))
PY
```

Zero `PROCESSING` rows is the go condition. Then snapshot for recovery under
`data/backups/pre_restart_hitl_<ts>/`: `pending.jsonl.bak`, `state.json.bak`, and a short
`HITL_SNAPSHOT.md` (mail_id, row count, latest `context_id`, waiting time).
`cp -p` the ledger **again immediately before** the restart — the escalation worker
rewrites rows while you work, so an early copy is stale.

## After: the diff that is the mechanism, not damage

On boot, `services/hitl_escalation.py` sweeps the ledger and re-marks every overdue HITL
row via `mark_state(mail_id, HITL, escalated_at=now)`, rewriting `hitl_since`,
`escalated_at`, and `finished_at` on the touched rows. Measured 2026-09-26: after the
restart, the last row of `qq_705d8b788f42de6a` carried new `hitl_since`/`escalated_at`
timestamps while its `state` and the whole mail_id set were unchanged. Judge the restart
by the `state` column and the mail_id set, never by timestamps.

Two consequences that read as faults and are not:

- `mark_state` sets `hitl_since` on **any** `HITL` re-mark, and the escalation worker does
  that every pass — the same row's `hitl_since` moved 01:56:42 → 01:58:07 → 01:58:49
  while the mail had been queued since 23:47. A reported age (and the notification's
  `age_hours`) therefore measures from the latest mark; `queued_at` is the first-wait
  time.
- one mail with several rows emits several `HITL ESCALATED` lines in one pass, each at
  its own age (observed 4.11 h / 3.87 h / 2.19 h for the same `mail_id`). Neither is a
  loop or lost data.

## Proving the new code, not just the new process

`/health`'s `version` comes from `services/_version.py` and is unrelated to feature
labels: the v2.4.0 / v2.5.0 switches are `config/policy.yaml` comments, so a feature
deploy leaves `/health` byte-identical. Never read an unchanged version as a failed
restart, and never quote a policy label as a service version.

The check that decides is file-mtime against process start
(`livekernel-gate-and-verify` step 7 — an edited file after process start is not
deployed). Then one call proves both loops restarted on the new modules:

```bash
curl -s http://127.0.0.1:8888/v1/mail/puller/status
```

`running` / `thread_alive` / `pid_alive` cover the orchestrator autostart;
`puller.state.running` plus a `last_pull_at` no older than the 30 s interval cover the
puller; `autostart.last_error` must be null. Measured 2026-09-26: the restart command
reported `READY on :8888 after 3s`, new PID `2737698`, and the status endpoint returned
all three booleans true with `last_pull_at` one interval old.
