---
name: livekernel-rfq-filter
description: |
  Separating real quote requests from event/notification mail before the RFQ chain, and re-calibrating that classifier: policy rule block, three tiers, mailbox replay, zero-false-kill proof, extraction alias gaps. Use when a HITL backlog fills with missing-field mail, when "only process mail that needs quoting" is requested, or a tier must be re-tuned.
---

# livekernel Quote-Request Pre-Filter

Live module: `services/mail_classifier.py`. The retired `services/rfq_filter.py` orphan
chain **was cleaned 2026-09-25**; the verified end state is: the module sits in
`.backup/rfq-cleanup-20260925/` (moved, not deleted), `config/policy.yaml` carries no
`rfq_filter:` block, and `load_policy()` returns `mail_filter` with no `rfq_filter` key.
CHANGELOG records it (`[未发版] — chore`; the chore landed when the file was 787 → 808
lines — **that was the moment's count, never reuse it as current**). Three checks made that
cleanup safe, and they are the checks for any future orphan (the numbered steps below are
the calibration procedure itself):

- **"No importer" is not "never used."** The grep clears the live tree, but
   `services/mail_orchestrator.py.bak.260924135512` — the orchestrator that ran until
   06:07 the same day — did `from .rfq_filter import classify`, and
   `data/skill_audit.jsonl` held **19 real `rfq_filtered_out` events** (last
   2026-09-24 05:56). The module was *superseded*, not dead on arrival, and CHANGELOG
   carried no record of the switch. Read the `.bak` files and the audit ledger before
   calling anything unused.
- **Same prefix is not same module.** `services/rfq_state_machine.py` looks like part
   of the same retired blast radius and is a **live dependency** — imported by
   `skills/sop-router/tool.py`, `agents/cat_controller.py`, `services/api_server.py`,
   and `tests/test_golden_regression.py`. It was left untouched. List every `rfq_*`
   name and check each one's importers separately.
- **Archive before editing, then re-load.** Move to `.backup/<task>-<ts>/` (never
   `rm`), and delete a config block by **programmatic line range** — find the module's
   comment header, then the next top-level key — not by eye. Regression before
   reporting done: `load_policy()` still returns every other top-level key,
   `load_mail_filter_policy()` still returns its eight keys, and the five live modules
   (`mail_classifier`, `mail_orchestrator`, `rfq_state_machine`, `api_server`,
   `cat_controller`) all import.

**Proving a module is an orphan: exclude the file from its own grep.**
`grep -rn "rfq_filter" --include=*.py services/ agents/ tests/` self-matches the
retired file's docstring and body, which reads as "still live" when nothing imports
it. Add `| grep -v '^services/rfq_filter.py'` — that is the check that returns nothing.

## When to use
- Only genuine quote mail should enter the RFQ chain — events, notices, newsletters, and auto-replies must be filtered out
- A HITL backlog is full of `RFQ 关键信息缺失` rows and the cause is unclear
- Adding or re-tuning the classifier, or a real quote is being tiered as not-a-quote

## Steps

1. **Keep every rule in `config/policy.yaml`, never in the module.**
   The live block is **`mail_filter:`** (a top-level key; locate it with
   `grep -n '^mail_filter:' config/policy.yaml`), holding `enabled`,
   `gray_zone_action`, `mark_read_on_terminal`, `body_scan_chars`, and optional
   overrides of the four term lists; `mail_classifier.py` reads them through
   `load_mail_filter_policy()` and falls back to the constants at the top of the
   module when the file is missing or corrupt. Tiers are **keyword scores**, so the
   classifier never reads `intake`'s required fields.
   **Check:** after any edit, load the block and assert a value survived the merge —
   `load_mail_filter_policy(root)["gray_zone_action"]` equals the policy value.

2. **Clean an HTML body before it reaches the classifier or CAT.**
   Event mail from QQ/Gmail is often a non-multipart `text/html` part, and
   `msg.get_content()` then hands back the whole document. Measured 2026-09-24 on
   `data/mailbox/qq_a3d0f9cd4e20676c.eml`: 61,124 raw characters, **52% of them
   tags/CSS**, and CSS substrings (`pla`, `cif`, `模型`) scoring as evidence.
   `mail_orchestrator.strip_html()` drops `script`/`style` blocks, strips tags,
   decodes a small entity set, and collapses inner whitespace; the same helper
   covers the multipart fallback where no `text/plain` part exists.
   **Check:** the body shrinks by a wide margin (measured 61,124 → 1,924, no `<`
   left) **and** the verdict does not flip. Cleaning is not allowed to move a tier:
   the cleaned body must classify the same way or better (that mail scored −5
   before, −8 after, still `skip`, with its true negatives now visible).

3. **Classify in three tiers, and let the ledger confirm them.**
   `classify(subject=, body=, attachments=, policy=, enabled=)` returns
   `MailVerdict(kind, score, positive, negative, cad_attachment, reason)`.
   Score = each matched positive term counted once, plus `CAD_BONUS` for a CAD
   attachment name, minus `_STRONG_WEIGHT` per strong negative and `_WEAK_WEIGHT`
   per weak negative. A strong negative is decisive regardless of positives.
   - `rfq` — score ≥ +1 → enters the chain (`should_process()` returns True)
   - `skip` — score ≤ −1, or any strong negative → marked `STATE_SKIPPED`, never reaches CAT
   - `gray` — score 0 → `gray_zone_action` decides (`skip_review` default; `process` to let it through)
   **Check:** every row's tier cross-checked against `data/mail_puller/pending.jsonl`'s
   existing state.

4. **Calibrate by replaying the mailbox on disk, not by writing more examples.**
   Call `classify()` directly over `data/mailbox/*.eml` and save the three-tier roster
   for operator review **before** wiring any change into the pipeline — a classifier
   that has not been replayed is not calibrated. `/v1/mail/maintenance/reclassify`
   re-tiers stored mail through the same code path; `/v1/mail/{mail_id}/reprocess`
   re-runs one mail with `force=1`, bypassing the tier and the content fingerprint
   (audited as `mail_force_reprocess`).

5. **Prove zero false kills three ways — a tier count is not evidence.**
   - no `skip` row contains an intent word (报价 / 询价 / quote / 多少钱 / can you make)
   - the highest `skip` score sits a real margin below the threshold
   - read the `skip` subjects; a trustworthy list is events, notifications, key
     alerts, and prize confirmations — and it explains a backlog of `关键信息缺失`
     HITL rows that were never quotations (measured: 39 of 114 on this host, every one
     a dev-event / course / API-key mail)
   Report all three numbers when claiming the filter is safe.

6. **When a real quote tiers down, fix extraction before touching the classifier.**
   The classifier scores intent, not completeness, so a quote that tiers fine but then
   stalls in CAT on missing fields is an **`intake.py`** gap (`_MATERIAL_ALIAS` /
   `_SURFACE_ALIAS` / `_extract_quantity`), not a tier problem. Known gaps closed:
   - materials and surfaces (2026-09-24): 锌合金, 冷轧板, 钣金件, POM/PC/亚克力/紫铜/压铸铝,
     喷粉, 抛光, 电泳, 达克罗, 淬火, 调质, 渗碳, 化学镀镍, 防锈, 焊接, 折弯
   - **quantity units (2026-09-25):** `_extract_quantity` matched only
     `个|件|pcs|pieces|units|qty|数量`, so **`套` — the normal Chinese B2B batch unit** —
     extracted `None`. A real RFQ reading "目前投产3套，BOM中为1套用量" was therefore
     judged `quantity` missing and hung on HITL with a price already computed
     (`RFQ-20260925-F7665D`, unit 281.25). Add the batch units
     (`套|台|批|片|sets|lots`) and gate each ASCII unit with `(?![a-z])`, or `3 settings`
     matches `sets` and `3 united` matches `units`. Widen the tables and re-replay; judge
     by the unit set (12/18 → 19/20 came from aliases alone, not from tuning).
   **Check:** replay the fixture body through `extract_rfq()` and assert the field the
   operator says the mail contains is non-None — a tier alone cannot show this, because
   the classifier never reads those fields. A `dimensions` blocker that the pack answers
   with an attachment is not a gap either; see `livekernel-gate-and-verify` step 9.

7. **When a boundary case flips after an extraction fix, the expectation was wrong, not
   the tier.** A mail that now extracts aluminum + 500 pcs legitimately belongs
   wherever the rules put it. Change the test's expected tier unless the semantic
   score itself moved.

## Pitfalls
- **Subject is input, not metadata.** The live signature takes `subject` alongside
  `body` for a reason: an event notice's strongest negative words live in the
  subject line. Classifying body-only is how a dev-event mail becomes an `rfq`.
- **Content-level deduplication now exists — do not build another id scheme for it.**
  `mail_classifier.content_signature(from, subject, body)` hashes the payload
  (EDRM-MIH style, ignoring transport headers) and is wired in through
  `gmail_imap`'s `dedup_check` callback and `mail_puller`'s content index: a repeat
  of the same content under a new uid is stamped `\Seen` server-side and counted
  `deduped` without building a context. So the "same mail re-interpreted five
  times" failure mode is closed upstream; a reprocessing concern is answered by
  reading `pending.jsonl` and the content index, not by writing another id.
  Mail identity (`_mail_id_for`, sha256 of uid|date|from) is a *different* key —
  the same uid carrying an edited body keeps its id and changes its signature.
- **The replay certifies only the mail on disk.** New mail quoting with no material
  still scores on intent alone; re-replay when the backlog grows.
- **Never write `config/policy.yaml` with a whole-file write.** A full-file overwrite
  while adding a rule block (2026-09-24) destroyed every other section — tolerance,
  margin, amount_gate, dfm, multimodal, oversize, hitl, external_send,
  auto_quote_threshold, flywheel — and took the suite from a 26-failure baseline to
  34 until the backup was restored. Edit the block in place, then re-read the file
  and assert every other top-level key survived. `livekernel-gate-and-verify` step 2
  edits the same file: same rule.
- The retired `rfq_filter._load_policy` had a merge-order bug where a pre-filled
  default `terms` dict shadowed the policy weights (`intent` scoring 1.0 instead of
  1.5). The live loader only replaces a list when the file supplies a non-empty one,
  so that exact mechanism is gone — keep the step-1 assertion anyway, since it is the
  cheap check that catches the next loader rewrite.
- **A delegated result must be re-derived, never inherited — a populated
  `result_json` is a receipt, not a measurement.** Measured 2026-09-25 across six
  subagent lanes: two returned **empty** results (caught, re-run personally), while four
  returned confident ones that a direct probe contradicted — a CHANGELOG claimed as
  "787 lines / md5 `44840b2b…`" against a measured **952 lines / md5 `1a31a3a6…`**;
  DfAM wall thickness claimed as "10–40 mm" where a 20 mm cube measured
  `20.0/20.0/20.0` and a 5 mm plate `5.0/5.0/5.0/60.0`; an extrude direction claimed as
  `YZ → −X` against a measured centroid `(2.50, 10.00, 20.00)` = **+X**; and a CLI
  invocation using flags that CLI does not accept (the entry point is a knowledge-query
  tool taking `--keyword/--limit`). The earlier instance in this file's own history is
  the same shape: "rfq_filter retired, no entry" was wrong on both counts (the *skill*
  stayed `visible` and `eligible`; only the *module* was retired), and the same run's
  "CHANGELOG has only one line, no second line" contradicted `tail -3`.
  Verdict-shaped wording (**only / never / retired / no entry**) is the familiar
  trigger, but the general trigger is **any number, status, or flag a delegated run
  measured**: re-run it yourself — `wc -l`, `md5sum`, the tool's own CLI, the engine's
  own probe — before it reaches a report or a decision, and report the corrected value
  rather than merely noting that the subagent erred. Here the wrong claim was the useful
  one: chasing it is what surfaced the real orphan chain.

## Related
- `livekernel-mail-intake` — the intake gates and idempotency these mails pass through first, plus the outbound gate state and the fetch's seen-flag behavior.
- `livekernel-gate-and-verify` — the HITL gates a surviving `rfq` quote still has to clear.
