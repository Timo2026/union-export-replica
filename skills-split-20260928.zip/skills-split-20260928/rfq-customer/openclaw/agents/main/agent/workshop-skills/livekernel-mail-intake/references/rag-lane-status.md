# RAG Lane Status — Which Layers Are Real

Ingesting with a `customer_id` is only worth what each retrieval layer actually serves.
The lane statuses below were observed **2026-09-23**; they change with deployment, so
re-measure with the commands at the bottom before relying on any of them.

## What the gateway is

`services/rag_layers.py`, wired as `rag_gateway`, runs a layered scheme:

- **quotes lane** — real vector hits, each reporting `scope: own` (this customer) vs
  `scope: shared` (a cross-customer anchor price). It fills
  `commercial.quote_anchor`, which `memory_phrase()` renders into replies. This is the
  lane that can put a **number** into customer-facing text, so
  `livekernel-gate-and-verify` step 3 governs whether it may go out.
- **craft lane** — the process/knowledge retrieval; degraded more often than quotes.
- **audio lane** — `asr_engine` targets `OMNIVOICE_URL` on `127.0.0.1:8082` and nothing
  serves that port, so audio retrieval has no listener at all.
- **conversations lane** — `_layer_conversations` asks `funasr.rag_search()`, which posts
  to `{funasr.base_url}/api/rag/search`. On this host `settings.yaml`'s
  `funasr.base_url` is the **LLM** (`http://127.0.0.1:8002/v1`), so the request becomes
  `:8002/v1/api/rag/search` and can only 404. Measured 2026-09-25, same query to both:
  `:8002/v1/api/rag/search` → **404** `{"detail":"Not Found"}` against the engine's own
  `http://127.0.0.1:7862/api/rag/search` → **200** with a real
  `{"query","results","total"}` body. The lane stays `degraded` with
  `_source = MOCK(rag failed: <HTTPError 404: 'Not Found'>)`. That is a URL naming the
  wrong service, not an outage — retrying never helps. Before retrying any degraded
  lane, read which service each adapter field targets: `base_url`, `asr_url`, and
  `vlm_url` point at different services by design.

## Observed on 2026-09-23

```
quote_anchor : non-mock  source: vector:quote_history(shared)  degraded: false
craft (rag)  : degraded  evidence mock: true
audio (asr)  : no listener (127.0.0.1:8082 unanswered)
```

## Re-measured 2026-09-25

```
conversations : dead-by-URL  8002/v1/api/rag/search -> 404 (7862/api/rag/search -> 200)
embedder      : live, 2048-dim from :8011 — `embedder.source` reads `pending` until the
                first embed, so `pending` does not mean unused
quotes lane   : scored hits rendered `content: ""` — the workbench projection reads
                top-level `text` while `InMemoryVectorStore.search()` returns
                `{"id","score","payload"}` with the text at `payload.text`.
                **Fixed 2026-09-25** in `rag_layers.search()`'s evidence assembly: normalise
                `text`/`snippet`/`note`/`content` up out of `payload`, and backfill `source`
                from the layer when a hit carries none. Re-verify by asserting the match's
                `content` is non-empty; a scored hit with empty content is again a projection
                fault, not an empty index.
```

So "retrieval works" and "retrieval works for prices" were both true while
"retrieval works for craft" was false. Reporting a single verdict for RAG is wrong in
both directions.

## Re-measuring

For any context (`data/contexts/<cid>.json`):

1. `raw.quote_anchor.source` and `raw.quote_anchor.degraded` — the quotes lane.
2. The `rag` evidence entry's `mock` flag — the craft lane.
3. `_layer_conversations`: POST the same query to
   `http://127.0.0.1:7862/api/rag/search` and to `http://127.0.0.1:8002/v1/api/rag/search`
   and compare. A 404 on the second is this lane's steady state, not a fault to chase.
4. Whether `memory_phrase()` in `decision.reply` carries a price, and if so whether it
   came from `own` or `shared` scope. A shared anchor from unrelated small parts is the
   leak that reached a German customer as "vergleichbare Teile liegen aktuell bei
   222.8"; `memory_phrase(suppress_prices=True)` on every price-stop verdict is what
   keeps it out.

## Pitfalls

- The `own_count` / `shared_count` split on the anchor is the ownership signal. A
  healthy-looking hit list that is entirely `shared` is not this customer's history.
- A lane that reports `degraded: false` may still be a hash-embedder fallback rather
  than the real embedder — check the lane's own `embed_source`, not only `degraded`.
