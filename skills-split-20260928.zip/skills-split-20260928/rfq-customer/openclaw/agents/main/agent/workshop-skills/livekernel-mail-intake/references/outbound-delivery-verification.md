# Outbound Delivery Verification

For any livekernel mail sent for real — after `egress_gate.check("smtp")` returns
`allowed=True`. An SMTP `2xx` proves only that the sending server **accepted the
submission**; it says nothing about the recipient's inbox. These checks belong to
`livekernel-mail-intake` step 8.

## 0. Package as one archive, attach it with the RFC 2231 tuple

Bundle every artefact into a single zip — one 2026-09-23 delivery carried STEP + 2D PDF +
PNG preview + XLSX + engine-result JSON + README in 0.97 MB, and the receiving engineer
gets one file to work from. The non-ASCII archive name is the trap: it goes through only
if the filename is a tuple, not a plain string.

```python
from email.mime.base import MIMEBase
from email import encoders
with open(zip_path, "rb") as fh:
    part = MIMEBase("application", "zip")
    part.set_payload(fh.read())
    encoders.encode_base64(part)
    # tuple form (charset, language, filename) is what carries CJK through
    part.add_header("Content-Disposition", "attachment",
                    filename=("utf-8", "", os.path.basename(zip_path)))
    msg.attach(part)
```

Read the account from the credential store, never from chat, argv, or a new file:

```python
from services.credentials import load_credentials
cred = load_credentials("<service>")          # data/credentials.json → account + password
user, password = cred["account"], cred["password"]
```

Set `To` to the **recipient**. A draft whose `To` is the sending account is not a reply and
proves nothing; that placeholder must be replaced before sending. QQ SMTP is
`smtp.qq.com:465` with `SMTP_SSL` (587 + `starttls()` also answers, and is what
`email_notifier._smtp_send` uses).

## 1. Report what you actually know

Say "submitted", with the evidence, and never "sent" or "delivered" until §2–§4 pass.
Measured 2026-09-23: a QQ SMTP send returned `2xx` in 1.9 s, the message sat in the
sender's `Sent Messages` folder complete with a verified attachment, no bounce ever
arrived — and the 163.com recipient never received it. Three of the four checks below
were green while the mail was undelivered.

## 2. Prove the submission in the sender's own mailbox (IMAP)

- Open the folder named by `sent_folders` in `data/gmail_settings.json` (QQ: `"Sent Messages"`).
- **Do not find the message by a CJK subject or a bare CID.** Measured 2026-09-25 on
  a send whose `data/sends/<cid>.jsonl` row and Sent-folder copy both existed:
  `SEARCH SUBJECT 'QUOTE-20260925-ZIPQ112'` returned **0**. QQ stores the subject as the
  MIME-encoded form (`=?utf-8?b?...?=`), so an ASCII term never matches it, and a CJK term
  raises `UnicodeEncodeError` instead (§3). Use `SEARCH ALL`, then fetch the last messages
  and compare `BODY[HEADER.FIELDS (SUBJECT TO FROM DATE)]` against the audit row's `to`,
  `from`, and `ts`. **Zero hits from a subject search here is a false negative, not a
  delivery failure.**
- Find the message by subject or attachment name, then read `fetch(uid, "(BODYSTRUCTURE)")`.
  The attachment went only if a part reads
  `("APPLICATION" "ZIP" ... ("attachment" ("filename*" {n}...)))` — a `TEXT` part alone
  means the message went out without its files.
- Verify the attachment bytes:
  `fetch(uid, "(BODY.PEEK[2])")`, then `body[:4] == b"UEsD"` (ZIP magic `PK\x03\x04`) and
  `len(body)` ≈ `zip_size × 4/3` plus ~2.6 % for CRLF line breaks.
- A non-ASCII archive name arrives percent-encoded
  (`%E4%BA%A4%E4%BB%98…`) — that is correct RFC 2231 encoding, not corruption.

## 3. Check for a bounce from the sender's INBOX and Junk

ASCII search terms work; **non-ASCII terms raise `UnicodeEncodeError` in `imaplib`**
(all four Chinese-subject queries failed 2026-09-23 while every ASCII one returned).
Use ASCII and catch the exception:

```
FROM "MAILER-DAEMON"   SUBJECT "Undelivered"   SUBJECT "Mail Delivery"
SUBJECT "Failure"      BODY "550"              BODY "blocked"
```

No bounce is evidence the message left the sender's infrastructure, not that it arrived.

## 4. Separate "channel blocked" from "attachment filtered"

Send a plain-text probe with **no attachment** to the same recipient, then ask the user
which of the two arrived:

- probe lands, original does not → a recipient-side filter hit the attachment or the
  third-party send; have the recipient check 垃圾邮件 / 广告邮件 / 订阅邮件 and
  allowlist the sender.
- neither lands → the channel or sender reputation is blocked; change the sending
  account or channel before retrying.

Hand the user the fingerprints that make the check take one minute: sender address,
subject prefix, attachment file name, and the send timestamp.

## 5. Read the account's role, and compare header fingerprints, before sending

`load_credentials("<service>")` returns `extra`; the QQ entry carries
`note: "stage0 shadow receiver; puller-only, never send"`. An account designated
receive-only must be surfaced to the user **before** a send, not discovered in the
failure. Then compare the stored copy's headers with the same account's earlier sends:
web-client mail carries `X-Mailer: QQMail 2.x` and `X-QQ-mid: xmappub7…`, while a
third-party SMTP submission carries `Received: from [127.0.0.1]` and
`X-QQ-mid: xmsmtpt…` with no `DKIM-Signature`.

**Do not read that fingerprint as the verdict.** Measured 2026-09-24 against a 163.com
address: two mails from the same account, the same third-party SMTP path, ten minutes
apart, **both without DKIM** — the 263-byte pure text arrived in the inbox and the
0.97 MB zip (1.31 MB after base64) was filed to spam. The send channel and the missing
DKIM were constant across both, so neither caused the split; the attachment did. Read
the fingerprint to know which lane you are in, then attribute classification to what
actually differed (see §6).

## 6. When the recipient reports non-arrival

Do not re-send the same attachment blindly. Offer the routes that remain, then ask which
before spending another send: re-send with the archive split or removed and the figures
inline in the body; deliver the zip through the chat channel for manual forwarding;
switch the sending account.

**When the report comes as "spam" rather than "nothing arrived", the cause is already
known — do not re-run §4.** A controlled A/B against 163.com (2026-09-24) isolated the
one variable that mattered:

| | pure text | single 0.97 MB zip |
|---|---|---|
| attachment | none | `application/zip` (opaque container) |
| payload on the wire | 263 B | 1.31 MB base64 (×4/3, +33 %) |
| DKIM / SPF | absent | absent |
| `Received` from | third-party SMTP | identical |
| result | inbox | spam |

Same account, same channel, ten minutes apart, DKIM absent in both — so the send
reputation and the missing authentication cannot explain the split. Two properties
carry the weight, and they stack: **an opaque container the filter cannot scan, and a
payload that inflates a third over the wire.** A zip is therefore not merely "a large
file", it is an unverifiable one.

Use this to choose the next send rather than guessing:

- **Keep the complete archive as the default; treat the spam folder as an accepted
  outcome, not a defect to engineer around.** Operator ruling 2026-09-24: the recipient
  can reach the spam folder themselves, and neither side can fix the classification, so a
  delivery still goes as one complete zip. The measured trade stays available as the
  fallback — writing the numbers into the body and attaching only what must be opened
  produced a 121 KB send (PDF + XLSX) with every figure readable without any download,
  one-eleventh the payload of the zip route. Use that route when a delivery must be
  provably complete rather than as the standing default.
- **Move anything genuinely large (a STEP measured at 4 MB) out of the mail path.**
  Hand it over in the chat channel, or send a download link; do not compress it into an
  attachment that will simply be filtered again.
- **Splitting the archive into volumes under ~500 KB is the fallback** when a zip is
  genuinely required — it keeps the container form but takes each message under the
  volume line.
- **Say "spam-filed, content verified intact", not "delivered",** until the recipient
  confirms retrieval. The zip was provably complete at submission (magic bytes and
  decoded length matched), so the right report is where it landed and that the artefacts
  were undamaged — never a delivery claim.
