# Draft-Body Acceptance

Where the outbound draft actually lives, how to read it, and what must be true before a
mail-driven cycle is accepted. These checks belong to `livekernel-mail-intake` step 7.

## Where the draft is

A persisted context keeps the verdict at `decision.status` and the reply at
`decision.reply`. Top-level `reply` and `verification` keys are **absent** from the
context file, so reading them directly returns empty fields on a perfectly good quote
and invites a false "draft missing" conclusion.

Read through the endpoint that rehydrates from disk instead:

```
GET /v1/rfq/{cid}/reply-draft
```

## Interpolated `None` is caught, but re-check anyway

`services/reply.py` scans the assembled subject and body with `_TAINT_RE`; on a hit it
rewrites both to the review template and sets `tainted: true` with `status: HITL`. That
is the guard working, not a failure to accept.

Still scan every new draft body yourself for a literal `None`, `nan`, or `undefined` —
a `.get()` with no fallback interpolates straight into customer-facing text. The rule
that decides whether it is safe:

- A tainted draft must appear as `kind: review`, **never** as a quote.
- A draft that claims to be a quote **and** carries `None` means the guard was
  bypassed. Escalate rather than accept.

## Language is detected, never configured, and never keyed on country

Every template renders through `L(key, lang)` in `services/lang.py`.
`detect_language()` reads body marker words first and falls back to the sender's TLD.
Observed across 212 persisted contexts: en 185 / zh 23 / de 4.

- Never report drafting as English-only — the distribution above disproves it.
- Never branch language on `rfq.country`: it is unset in **0/600** contexts on disk, so
  that gate silently stays English. A German inquiry then receives an English body,
  which reads as ignoring the customer.
- Adding a new reason string follows `livekernel-gate-and-verify` step 5 — all four
  languages, verified with one generated draft per language. An internal Chinese reason
  dropped straight into a template ships a mixed-language email to the customer; that
  happened twice on 2026-09-23.

## Acceptance order

1. `decision.status` and `decision.reply.body` exist and are non-empty.
2. The body carries no `None` / `nan` / `undefined`.
3. The language matches the sender's, and the reason strings are localized.
4. On any price-stop verdict, the body carries **no** price at all.
