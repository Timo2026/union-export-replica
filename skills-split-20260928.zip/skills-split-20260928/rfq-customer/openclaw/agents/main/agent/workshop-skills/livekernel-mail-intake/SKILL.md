---
name: livekernel-mail-intake
description: |
  Enabling or repairing email intake into livekernel: the three gates, nested credentials schema, what the IMAP fetch marks seen, restart with a liveness proof, acceptance — plus the quote-reply send path and terminal-state read marking. Use when mail_puller shows enabled=false, a QQ/Gmail mailbox must be wired in, a mail-driven RFQ plan needs its gates verified, a real reply must go to the customer, or a restart has to be proven up.
---

# livekernel Mail Intake

## When to use
- Turning on or repairing mail intake (`/v1/mail/puller/status` shows `enabled: false`, `total_pulled` not growing)
- Adding a QQ or Gmail mailbox to livekernel
- Checking a mail-driven plan does not hand send authority to the system
- Packaging a delivery for mail, proving the send path is open, and verifying a real send

## Steps

1. **Verify all three intake gates first.** Any one missing shows up only as `enabled: false` with no reason attached:
   - `data/gmail_settings.json` exists with `{"service": <credential key>, "enabled": true, …}` — an absent file is a hard disable (`mail_puller.py:201-204`)
   - credentials for that `service` key exist in `data/credentials.json`
   - both poll loops are alive, each started in its own place: puller `DEFAULT_INTERVAL_S`
     (`mail_puller.py:63`, 30 s) and orchestrator `start_loop(poll_interval_s=…)`
     (`mail_orchestrator.py:305`, 5 s default). These are two independent rates — a
     stalled drain looks like `total_pulled` still climbing while `NEW` grows without
     bound, so check both loops rather than assuming one covers the other.
   **"credentials exist" in `status()` is not the third gate.** A `fernet` entry's
   password depends on the **`UEA_APP_SECRET` the running process carries**, so a restart
   without the same secret makes `load_credentials()` return `None` for every service
   while `status()` still lists them. All keys failing at once is that signature; one key
   failing is an entry problem (step 2). See
   `references/credential-secret-mismatch.md`.

2. **Write credentials in the nested schema, and prefer the Fernet cipher.** `load_credentials()` reads `data["services"][<service>]` (`credentials.py:114-128`), so a flat `{"account","encrypted"}` file is silently unreadable and the puller stays disabled even with the gate open. Shape:
   ```json
   {"version":1,"services":{"qq":{"account":"…","encrypted":"…","cipher":"fernet-aes128-cbc-hmac-sha256"}}}
   ```
   `cipher` selects the codec: anything not starting with `fernet` falls back to **base64**, which is not encryption. Two silent states to check rather than assume:
   - `cryptography` missing from the env makes `status()["fernet_available"]` `False` while every read still returns a value — the store is storing base64 and reporting success (observed 2026-09-24 in the `occ` env before `pip install cryptography`). Assert `fernet_available: True` after saving, and re-save the entry so it upgrades. **Choose the interpreter by env, not by habit:** this host has `cryptography` 50.0.1 in `occ` and none in `lk-skills` / `vidproc` / `dfam` (re-measured 2026-09-25), so `load_credentials()` returning `None` from the wrong env is that gap — it is not evidence the credential is lost. Run credential reads from the `occ` interpreter.
   - A legacy entry saved before the cipher existed keeps `base64-insecure`. Migrate by reading the plaintext through `load_credentials()` and calling `save_credentials()` again, which rewrites it in Fernet.
   **Check:** `status()["fernet_available"]` is `True`, every entry's `cipher` starts with `fernet`, and `data/credentials.json` is mode `0600`.

3. **Probe the mailbox read-only before any poller runs.** `IMAP4_SSL(...).select("INBOX", readonly=True)` plus `SEARCH UNSEEN` and `SEARCH ALL`. This proves the credential, shows real volume, mutates nothing, and gives the baseline for later `total_pulled` checks. Keep credentials out of chat and argv.

4. **Know which code stamps `\Seen`, and which deliberately does not.**
   `gmail_imap.sync()` now fetches with `criteria="UNSEEN", mark_seen=False`
   (`gmail_imap.py:140`), added 2026-09-24 after the operator required "mark read only
   once the reply is handled". The pull therefore does **not** stamp `\Seen`: the
   earlier behaviour (fetch defaulting to `mark_seen=True`, which stores the flag
   server-side) is gone, so a co-tenant that polls `SEARCH UNSEEN` is no longer
   starved by livekernel's fetch. Exactly two paths still stamp the flag server-side:
   - a content-signature dedup hit — same content re-delivered under a new uid needs
     no context, so it is stamped `\Seen` and counted `deduped` (`gmail_imap.py`
     `dedup_check` block)
   - terminal-state marking, `mark_mailbox_read(root, mail_id)` via the orchestrator's
     `_maybe_mark_read`, gated by `policy.yaml` `mail_filter.mark_read_on_terminal`
     (default `true`); it fires on DONE/BLOCKED/FAILED/DEAD/SKIPPED and writes an
     `imap_marked_read` audit row
   **HITL is intentionally left unread** — it waits for a human `send-reply` before
   anything is marked. Consequence to state when asked about coexistence: a co-tenant
   `UNSEEN` consumer now keeps seeing every HITL mail indefinitely, which is the
   price of not clearing the flag before a verdict exists.
   Because flags no longer track handling, read-status alone cannot answer "is this
   mail processed?". Use `pending.jsonl` states plus the content-signature index.

5. **Namespace ingested evidence per customer, and read which lane is real.** Always send `customer_id` from mail — `POST /v1/rag/ingest` takes it and retrieval filters on the same value. The scheme is layered (`services/rag_layers.py`) and each lane degrades independently, so one "RAG works" verdict is wrong in one direction or the other; `references/rag-lane-status.md` holds the lane map and how to re-measure. A live `quote_anchor` hit is a **price** that `memory_phrase()` may render into the reply, so `livekernel-gate-and-verify` step 3 governs whether it reaches the customer.

6. **Restart through the service script, not systemd.** livekernel is a tmux/uvicorn process launched by `node_services.sh`, not a systemd unit: `node_services.sh restart livekernel`. Expect at most ~60 s of outage — crontab runs `node_watchdog.sh` every minute with a single-instance lock, a 6 GiB memory floor, and crash-loop backoff, so it self-heals.

   **When mail is in flight, read `references/restart-safety.md` before restarting.** The ledger is append-only, so HITL in flight is *distinct mails*, not rows — measured 2026-09-26: 14 `HITL` rows were 8 mails, and `/v1/mail/puller/status`'s `pending.by_state` is already that deduped view (`HITL: 8` against 14 rows), so report the deduped number an operator asks for. Zero `PROCESSING` rows is the go condition, and the snapshot under `data/backups/pre_restart_hitl_<ts>/` is what recovery reads back. After the boot, `hitl_since`/`escalated_at` timestamps move on overdue rows — that is the escalation worker re-marking them, not damage; the `state` column and the mail_id set are the comparison. `/health`'s `version` comes from `services/_version.py` and is unrelated to feature labels, so it proves nothing either way.

   Then prove the restart actually came up, in this order. Three of these checks each produced a confident wrong answer on 2026-09-24:
   1. `ss -tlnp | grep ':8888'` gives the **real** PID. `pgrep -f services.api_server` returns the tmux wrapper (`bash -c bash node_services.sh _run 'livekernel'`) instead — its cmdline contains the same string — so PID-derived conclusions landed on the wrapper, which has 4 threads and no background work at all.
   2. `data/mail_puller/state.json`'s `pid` must **equal** that port PID. A mismatch is either a dead process (state residue) or — worse — another uvicorn instance you started for testing on a different port, which ran the same lifespan and overwrote the production state file with its own PID. Confirming `autostart` reached `is_enabled=True` is not evidence either: a file probe showed the lifespan entering cleanly while the wrapper had no mail threads.
   3. `last_pull_at` must be advancing (age ≤ `DEFAULT_INTERVAL_S`, 30 s). `running: True` alone is a stale self-report; a rising `last_pull_at` is the puller actually looping.
   4. Do **not** verify threads by name. Every `/proc/<pid>/task/*/comm` reads `python` for Python threads (observed: the `mail_puller` and `mail_orchestrator` threads all reported `python`), so a name-based check reads "no background threads" on a healthy process. If a count is needed, use `Threads:` in `/proc/<pid>/status` and reason from the expected total, or fall back to the functional signals above.
   5. **A locally injected `.eml` proves nothing about whether the queue is draining.** `poll_once()` calls `_enqueue_pending_from_mailbox()` only when the IMAP sync reports `fetched > 0` (`mail_puller.py:296-298`), so a hand-written file in `data/mailbox/` is never enqueued while IMAP returns nothing new. A frozen queue plus an empty mailbox means "no new mail arrived", not "the loop is dead" — the two look identical. Before diagnosing a stalled pipeline, check whether the newest `.eml` mtime has moved at all.
   6. Never launch extra `uvicorn` instances against this root for experiments (a test port is enough to share `state.json` and the credential store). Verify findings against the port owner only, and restore `state.json` by restarting the real service afterwards.

7. **Accept only after the status endpoint proves it.** `curl -s http://127.0.0.1:8888/v1/mail/puller/status`: `total_pulled > 0`, `consecutive_failures` flat, and every `HITL`/`BLOCKED` entry must carry `auto_send=false`. For mail that carried a drawing, open its context (`data/contexts/<cid>.json`) and confirm `geometry.volume_mm3` is populated with `volume_source: ocp_brep` — an approved context with `geometry: {}` means the attachment never reached the chain and its price rests on a default weight. Then apply the four draft checks in `references/draft-body-acceptance.md` before accepting the cycle.

8. **Package an outbound delivery, evaluate the gate, then verify the send.** Bundle the artefacts into one archive and read `references/outbound-delivery-verification.md` for the mechanics — the RFC 2231 tuple carrying a non-ASCII archive name, the credential read, the QQ port, and the post-send checks. Evaluate the gate before claiming a mail can go:
   ```python
   from services.egress_gate import check
   check("smtp")   # allowed=False, reason=默认拒绝: 无显式 egress 授权 (铁律① data-stays-local)
   ```
   While closed, `services/notify/email_notifier.py:43-47` degrades to a local `data/notifications/*.eml` write, so nothing leaks on a wrong assumption. Unblocking means editing `config/settings.yaml` (`egress.allow=true` **and** `channels.smtp=true`), an operator decision — report the blocked draft and wait, never edit the gate to make your own send succeed. The master switch does **not** open the other channels. A finished draft still needs the real `To` address and the approval from a human.

   A `2xx` reply proves only that the server accepted the submission. A mail can sit complete in `Sent Messages` with its attachment verified, raise no bounce, and never reach the recipient — verify per the reference and report "submitted" until the recipient confirms retrieval.

9. **Send a quote reply through `/v1/rfq/{cid}/send-reply`, never through an ad-hoc SMTP block.** The only outbound send path on this host is that endpoint, and it is **human-approved**: `POST /v1/rfq/{cid}/approve` first sets `human_approved` (persisted to `data/contexts/<cid>.json` under `decision`); without it the send returns **409 未人工批准** even when the gate, credential, and SMTP are all healthy. Then `POST /v1/rfq/{cid}/send-reply` with `to_addr` (the real recipient — never the sending account), reading the reply from `decision.reply` on disk when the in-memory entry has no body.

   `services/reply_sender.py` layers, in this order, and every failure **raises** `ReplySendError` rather than degrading:
   `bad_to_addr` (empty or no `@`) → the `egress` master gate → credentials for the key named by `data/gmail_settings.json` `service` (default `qq`) → `_smtp_host()` → attachment render (PDF + XLSX when none supplied) → `SMTP_SSL(host, 465)`. The endpoint maps `egress_blocked` / `no_credentials` / `smtp_host_unknown` / `bad_to_addr` to **409** and `smtp_failed` to **503**. A success writes **`data/sends/<cid>.jsonl`** (ts, context_id, to, from, approver, service, smtp_host, subject, attachment names, egress_reason); nothing is written on failure, so "no audit row" and "not sent" are the same signal.

   **Three traps that read as configuration but are not.**
   - **`settings.yaml`'s `reply_send:` block is inert.** `enabled`, `service`, `from_addr`, `ssl`, and `daily_cap` are read by **no code** (`grep -rn "reply_send" --include=*.py services/ tests/` matches only the comment above the block). Flipping `enabled: true` changes nothing; the real switches are the human approval and the `egress` gate. Likewise there is **no `dry_run`, `cred_override`, `egress_settings`, `daily_cap`, or `"stage"` key** in this module, and it writes no `data/audit/reply_send.jsonl` and no `X-UEA-Status: UNSENT-DRAFT` draft — a doc promising those is describing a different module.
   - **The credential key is `gmail_settings.json`'s `service`, not a name you choose.** `_mailbox_service()` reads that file and falls back to `"qq"`, so a send from an arbitrary sending account requires `service` to name the credential that actually holds that account (on this host the `qq` entry) — adding a new `credentials.json` entry changes nothing until `service` points at it. Never write a mailbox address into a skill or script; read it from the store at call time.
   - `_smtp_host()` resolves from `UEA_MAIL_SMTP_HOST` / `EMAIL_SMTP_HOST` first, otherwise by rewriting the `imap.` prefix of the settings host to `smtp.`. Neither present → `smtp_host_unknown`.

   **Isolate a test of this module without touching the production credential:** stub `smtplib.SMTP_SSL` (raising on construction) and point the credential lookup at a throwaway `credentials.json` under a temp root, or run the endpoint against a temp root with `gmail_settings.json` copied. The module takes no `root` argument — it resolves `data/` relative to the caller's cwd — so run the test from a temp cwd rather than passing a path.

   **What the orchestrator now sends by itself — two limits, both landed.** The
   2026-09-24 mail rewrite dropped the priced auto-send hook, so for a while a PASS mail
   went DONE → `_maybe_mark_read` with **no reply sent at all**, and "mark read after a
   priced reply" really meant "mark read at the terminal state". Both paths are now
   implemented in `mail_orchestrator.py` and each is switched by its own policy key:
   - **price-free clarification letter** (`CLARIFY`, landed 2026-09-25) — the orchestrator
     reads the persisted draft and sends it with `quote=None, attachments=[]`, under a
     policy switch plus a per-recipient cooldown, then marks the mail read. Its status is
     deliberately outside the `never_auto` set below, so the guardrail does not flag it.
     Four gates, no price-leak regex. Wiring: `livekernel-gate-and-verify` step 9.
   - **priced quote** (`PASS`, landed 2026-09-26) — `_try_auto_quote()` under
     `policy.quote_gate.auto_quote_send_enabled` with **eight** gates, including a
     price-equality check (the body must carry the engine's `unit_price`/`final_price`),
     the `auto_quote_threshold`, a **self-send guard** (the recipient must not be the
     mailbox's own account — without it the priced letter runs the same self-loop cycle as
     the clarification letter), and per-`context_id` idempotence. Wiring: step 10.
   The PASS branch of the draft layer stays `draft_only` in both cases; the send decision
   lives in the orchestrator beside the audit trail, never inside the template.

   **A direct `send_quote_reply()` call is legitimate too, but only against an operator's
   explicit authorization recorded in `approver=`** — it is the same function, the same
   egress gate, and the same audit file as the endpoint, minus the `human_approved`
   check, so the authorization has to be written into the call itself. Conditions and the
   `occ`-env requirement: `cnc-zip-quote-mail` step 7. An ad-hoc `smtplib` block stays
   forbidden either way. Gates, audit rows, and the exact wiring
   live in `livekernel-gate-and-verify` steps 9–10.


## Iron rules
- `never_auto = {"BLOCKED", "HITL"}` is enforced in `guardrails.py:217-221`: an auto-send request against those statuses appends an `external_send_blocked` flag, and any guardrail flag forces `auto_send=false`. Never plan around it.
- Prices come only from the deterministic engine. LLM stages may extract, draft, or explain; they never set or adjust a price.
- Data stays on this host: drafts only, no SMTP send, until a phase explicitly approves it. The gate is `services/egress_gate.py`, but its `KNOWN_CHANNELS` covers only `smtp`/`imap`/`webhook` — a direct `urllib` call anywhere else is not gated, so check the target host of any such call before calling a phase local-only.

## Pitfalls
- **Attachments are not in the eml unless they are re-attached.** `_msg_to_eml_bytes` originally rebuilt headers plus body only, so every attachment was silently dropped and `attachments_count` was the only clue. Multipart re-attachment with a cap is shipped (`MAX_ATTACHMENT_BYTES`, 32 MB; oversized items are logged and skipped, not fatal). Check the attachment directory next to the `.eml` exists before debugging the parsers.
- **Where the draft lives, and what its body must contain.** A persisted context keeps the verdict at `decision.status` and the reply at `decision.reply` — top-level `reply` / `verification` keys are absent, so reading them returns empty fields on a good quote and invites a false "draft missing" conclusion. Read `/v1/rfq/{cid}/reply-draft`. Language comes from body markers then sender TLD, never from `rfq.country` (unset in 0/600 contexts). Full checks and the `None`-taint rule: `references/draft-body-acceptance.md`.
- **QQ IMAP throttles login frequency.** Repeated credential probes fail with `Login fail … login frequency limited`, which reads exactly like a wrong authorization code. Space attempts instead of hammering retries, and re-verify through a fresh readonly connection.
- **`ctx.documents` is populated only by callers that set it.** The field lives on the context object (`context_engine.py:54`) and is written into the persisted context, but `cat_controller.run()` takes **no `documents` argument** — its parameters end at `voice_transcript`, `audio_path`, `step_facts`, `use_llm`, `driver` — so a caller that passes `documents=` gets a `TypeError`, and a caller that assumes it was passed persists `[]`. The mail orchestrator passes neither `documents` nor `step_facts`, so **a mail-drawn part cannot arrive through this path today**; an empty `documents` list means the geometry never entered the chain, not that it was dropped mid-flight. Verify a drawing arrived against `data/mailbox/<id>_att/` plus `geometry.volume_mm3` (an `ocp_brep` source is a real parse).
- **`web_search` points at livekernel itself.** `DEFAULT_SEARXNG_URL = http://127.0.0.1:8888` and nothing there is a SearXNG, so `/v1/customer/enrich` returns empty while looking like a search ran — and it is a direct `urllib` call, so `egress_gate` never sees it.
- Host topology: `7862` and `8888` share one `occ` conda env — conda here is process isolation, not per-service isolation, so never claim one service's env failure cannot touch another. Prefer `127.0.0.1:8888` locally (`8051` is a public NAT map to it, not a second process). OpenClaw is a Node service; 8002 omni and 8011 embed are OpenAI-compatible providers, not imports. **The workbench API has an auth gate (Bearer env token + `/__auth` session cookie, `services/security.py` `gate_*`, `api_server.py` `_gate_middleware`, 2026-09-25) rather than no authentication layer** — but it is a gate on the port, not a data-layer permission, so an authorized caller still sees every tenant's data, and a loopback caller is exempt by design. Verify access with `livekernel-endpoint-auth-gate` before assuming the public path is open or closed.
- **Probe residue hides in the vector store, and deleting it on disk alone does not stick.** RAG keeps a second persistence layer outside CRM sqlite / mailbox / ledger / contexts, with a flat per-collection dict whose live data is reachable only at `store._backend._collections`; `JsonFileBackend` holds it in memory and `_save()` rewrites the file whole. Read `references/probe-residue-in-vector-store.md` before removing probe mail, and count with `grep -c` rather than parsing the tens-of-MB file.

## Related
- `thor-native-nemotron-vllm` — serving the 8002/8011 models behind those providers.
- `livekernel-gate-and-verify` — building or verifying an **outbound** price-stop gate (oversize, geometry/text conflict) whose reply must carry no price.
- `external-mail-system-audit` — vetting a foreign email-automation package before it goes near these gates.
- `external-skill-pack-install` — scrubbing and pinning a third-party skill pack before it runs here.
- `ocp-geometry-code` — reading or authoring OCP geometry code.
- `livekernel-drawing-pack-quote` — when an attachment is a whole drawing pack (BOM + STEP + PDF) priced as a batch table; zip staging lands where it starts.
- `livekernel-offline-engine-bridge` — engine-backed calls (`step_geometry`, `calc_quote`, `conflict_check`) from outside the running service.
