# platform
平台件：运行时桥接、skill 目录索引、知识库、检索与配置
## 内容
- 19 个 skill / 155 个文件 / 0.6M
- `hermes/openclaw-imports/` — 2 个 skill（原 ~/.hermes/skills/openclaw-imports/）
- `livekernel/` — 5 个 skill（原 ~/timo_livekernel/skills/）
- `openclaw/` — 3 个 skill（原 ~/.openclaw/skills/）
- `openclaw/agents/main/agent/workshop-skills/` — 9 个 skill（原 workshop-skills/）

## 跨仓依赖

被全部业务 repo 依赖（_runtime.py / _pack_bridge.py 在 timo_livekernel 内必须就位）

## 部署

```bash
# 与本仓同系列的其他仓库一起部署到同一框架目录
# skill 名即目录名，直接按 framework 拷回原路径
```
