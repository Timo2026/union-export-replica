---
name: thor-native-nemotron-vllm
description: Nemotron NVFP4/Omni on GB10/Thor via native conda vLLM, plus reading local video/audio. Use when Docker is unavailable, an NVFP4 MoE must launch, reasoning must split from answers, Omni won't start, media is ignored, ASR is empty/slow, or tool calls 400.
---

# Thor Native Nemotron vLLM Serving

## When to use
- Serving a Nemotron checkpoint on this host where Docker is not usable
- Launching an NVFP4 MoE model (30B-A3B class) on Thor silicon
- The response returns reasoning and answer fused, or a model refuses to load
- Starting the any-to-any Omni model (video/audio/image/text input)
- `tool_choice=auto` returns HTTP 400 against a server that passes every plain-probe check

## Steps

1. **Confirm the native path is allowed before building anything container-shaped.**
   GB10 / Thor silicon (Compute Cap 12.1) supports upstream vLLM 0.20+ natively; the
   Jetson serving recipe accepts "a validated native vLLM 0.20+ install" on Thor.
   Check Docker usability first (`groups | grep docker`, and whether `sudo` needs a
   password). If Docker is unusable, native conda is the correct path, not a fallback
   to argue about.

   **Measured on this host 2026-09-25** (the decision was already made, so the numbers can
   be reused instead of re-measured): driver **580.82.09** ✓ and CUDA Toolkit **13.0** ✓
   both meet the TAO minimums, but **NVIDIA Container Toolkit is 1.17.8 < 1.19.0** and the
   **Docker NVIDIA runtime is not configured** (`tao-setup-nvidia-gpu-host
   scripts/setup-nvidia-gpu-host.sh --check-only` → exit 1 naming exactly those two).
   The docker CLI exists but the daemon is unreachable (`permission denied`) and the
   account is not in the `docker` group. Those four facts are why the container route is
   closed here; closing it is an operator decision (`--install --yes` needs sudo + package
   installs), not something to work around.

   **The `jetson-*` skill family refuses on this host, and that is correct.** Measured
   2026-09-25: `jetson-print-device-info` → exit 1 ("Not running on a Jetson target"),
   and `jetson-diagnostic/scripts/detect_jetson.sh`, `snapshot.sh` and
   `jetson-memory-audit/scripts/audit.sh` → exit 2, because `/proc/device-tree/model`
   does not exist, `/dev/nvmap` is absent, and `tegrastats` / `nvpmodel` /
   `jetson_clocks` / `jetson_release` are all uninstalled. This host is GB10 / DGX Spark
   class — the recipes are not broken and their gates are what stop them returning fake
   data. Do not "fix" them. Two exceptions to know before running one:
   - `jetson-diagnostic/scripts/mem_summary.sh` exits **0** on a non-Jetson host and
     prints a reading taken from `nvidia-smi` compute-apps (`RAM … | GPU 73.5 GiB [sum(
     nvidia-smi compute-apps)]`). Its exit code therefore proves nothing about Jetson
     coverage — a success there is not evidence the skill applies.
   - The route that **does** work here is vendor detection, not Jetson-family
     detection: `gpu-container-setup-flagos/scripts/detect_gpu.py` → exit 0 with
     `{"vendor":"nvidia","devices":["NVIDIA GB10"],"count":1}`, and
     `accelerated-computing-cudf` needs only a `pip install cudf-cu13` (CPU/toolchain
     already qualify, no env in this host's conda set ships it yet).

2. **Pin the runtime versions vLLM 0.20.0 requires.**
   It hard-pins `torch==2.11.0`, `torchaudio==2.11.0`, `torchvision==0.26.0`, and
   `flashinfer-python==0.6.8.post1`. Do not upgrade transformers casually — a Nemotron
   checkpoint needs a version that can import its remote modeling code.

3. **Export the NVFP4 MoE kernel switches before starting an NVFP4 MoE model.**
   Without them the model either fails to load or falls back to a slow path:
   ```bash
   VLLM_USE_FLASHINFER_MOE_FP4=1
   VLLM_FLASHINFER_MOE_BACKEND=throughput
   VLLM_ALLOW_LONG_MAX_MODEL_LEN=1
   MAX_JOBS=2               # caps flashinfer JIT/ninja build parallelism
   ```
   `MAX_JOBS` is read by `flashinfer/jit/cpp_ext.py`. Without it ninja defaults to
   `nproc` (20 here) and ~90 concurrent `nvcc` processes exhaust unified memory; the
   build dies with `FAILED: [code=137]` (128+9 = SIGKILL from the OOM killer) and
   surfaces as `Ninja build failed` / `Engine core initialization failed`. Raise the
   cap only with enough free memory for that many `nvcc` processes.

4. **Pass `--trust-remote-code` for every Nemotron checkpoint.**
   They ship custom modeling code (`configuration_nemotron_h.py`,
   `modeling_nemotron_h.py`). Omni additionally ships `audio_model.py`,
   `video_processing.py`, `image_processing.py`.

5. **Split reasoning from answer text with the model's reasoning parser.**
   For the Nano family add `--reasoning-parser nemotron_v3`, then prove the separation
   is real rather than assumed: one chat completion must return **both** fields —
   `print(m.get('reasoning'),'|',m.get('content'))` on
   `choices[0].message`. An empty `content` with reasoning present means the parser
   is not applied.
   **Launch with the tool-calling flags when the model must serve an agent loop.**
   OpenClaw agent turns send `tool_choice=auto` plus a tools payload, so a server
   started without `--enable-auto-tool-choice --tool-call-parser qwen3_coder`
   rejects every such request with HTTP 400 — while a plain chat probe through the
   same endpoint still returns its exact answer. Verified 2026-09-24 on
   `127.0.0.1:8002`. The flags are **per-launch**: after any relaunch re-read them
   from `/proc/<pid>/cmdline`, never from the launcher and never from a pattern grep,
   which self-matches. Accept a launch per `references/agent-loop-tool-calling.md`
   (tool-carrying curl, then a real agent turn pinned to the model, then the
   consumer's own router) — a plain probe cannot see a missing parser. That
   reference also holds this model's measured fitness limits and its
   subagent-relay arithmetic trap.

6. **Serve from the local cache only.**
   Set `HF_HOME=<cache root>` and `HF_HUB_OFFLINE=1`, and point `--model` at the
   `files/` directory of the cache entry, not at `blobs/` or
   `snapshots/<hash>/` (the latter holds only config symlinks and lacks
   `tokenizer.json`). Verify the shards with
   `hf-mirror-fast-download/scripts/verify_safetensors.py` first — a truncated shard
   can pass a header parse and still fail at load.

7. **For the Omni any-to-any model, confirm the architecture is registered and cap media per prompt.**
   ```bash
   python -c "from vllm.model_executor.models.registry import ModelRegistry; print(ModelRegistry.get_supported_archs())"
   ```
   `NemotronH_Nano_Omni_Reasoning_V3` is registered in vLLM 0.20.0 (mapped to
   `nano_nemotron_vl.py`) and imports cleanly. Launch with
   `--limit-mm-per-prompt '{"video":1,"image":1,"audio":1}'` and a bounded
   `--max-num-batched-tokens`; unbounded media per request is what OOMs unified memory.

   Mamba hybrid checkpoints (`hybrid_override_pattern` like `MEMEM*E...`) fail with
   `AssertionError: In Mamba cache align mode, block_size (2128) must be <=
   max_num_batched_tokens (2048)` at default settings. Raise
   `--max-num-batched-tokens` above the reported block size (4096 works).

   Audio input needs `av` (PyAV) **and** `librosa`/`soundfile`; `vllm/multimodal/media/audio.py`
   try-imports them at module scope and substitutes a `PlaceholderModule` that raises
   "install vllm[audio]". Audio bytes cannot be decoded without `av`.

8. **Prove each media input is encoded by predicting its token count, not by eyeballing the delta.**
   A media input can return a fluent answer while carrying none of its content. Compare
   `usage.prompt_tokens` against a text-only baseline for the same question
   (image ≈ +283, video ≈ +3265 per item), and for audio predict the delta from the
   processor constants rather than from a rough baseline:
   `ceil((samples // audio_hop_length) / audio_subsampling_factor)` at
   `audio_sampling_rate` — hop 160, subsampling 8, 16 kHz input gives ~13 sound tokens
   per second, so a 1.5 s clip legitimately adds ~19 tokens plus its text. That "small"
   audio delta is correct encoding, not a dropped input: both `input_audio` and
   `audio_url` parts are accepted and encoded. A confident wrong answer (a 440 Hz tone
   called "~110 Hz") is hallucination, not recognition — and a pure tone is not a fair
   test of a speech model.

   **Do not use the `chat_template.jinja` `part['type']` whitelist to decide whether an
   input was dropped.** It lists `audio` / `audio_url` but not the OpenAI-standard
   `input_audio`, which invites the conclusion that `input_audio` is silently
   discarded. Token arithmetic disproved that: `input_audio` encodes exactly like
   `audio_url`. Treat the whitelist as a hint about what the template renders, never as
   the verdict — the token count is the verdict.

   For audio capability and test recipes, read `references/audio-input-testing.md`. For
   preparing a **local** file for that comparison — frame extraction, 16 kHz audio
   conversion, OCR of on-screen text, an offline ASR fallback, and cross-modal
   corroboration — read `references/local-media-extraction.md`.

9. **Verify every performance, context, or quality number against
   `references/generation-and-context-verification.md` before reporting it.**
   On this server each of these produced a confident wrong verdict: a `max_tokens`
   budget that starved the answer, an `ignore_eos` flag, a missing `include_usage`,
   a +16-token chat-template drift, a prefix-cached TTFT, and a buffered log.

10. **Size `--gpu-memory-utilization` against the unified-memory budget, not a VRAM figure.**
   This host has 121 GiB shared LPDDR5X and no discrete VRAM. Run `free -g` and check
   `available`, then keep a margin for the OS and any other running server. Concurrent
   servers must each fit inside that one shared pool.

11. **Before bouncing an endpoint other services share, read the consumers from
    their own router and gate on their queue.** `ModelRouter(load_settings()).status()`
    returns `{"backend","online_roles","routes"}`, `routes[role] = {online, model,
    endpoint}` — on this host `:8002` carries FAST / VISION / REASON / ASR. Then
    confirm the consumer's work is terminal: no `NEW` / `PROCESSING` / `CLAIMED`
    row in `data/mail_puller/pending.jsonl`. "The endpoint answers again" afterwards
    does not prove the interrupted work completed.

## Pitfalls
- `nvidia-smi` reports `memory.total: [N/A]` on unified-memory parts. Use `free -g`;
  do not report a made-up VRAM number.
- The Omni checkpoint's tensor map names its towers `language_model`,
  `sound_encoder`, `vision_model`, `mlp1`, `sound_projection` — checking only for
  `vision_model` and concluding the audio tower is missing is wrong. Its audio config
  key is `sound_config` (parakeet-style, 128 mel bins / 16 kHz), not `audio_config`;
  `audio_config: None` is expected and does not mean audio is unsupported.
- Audio is an **input-only** modality on this checkpoint: the tensor map has
  `sound_encoder`/`sound_projection` but no decoder, vocoder, or codec, so transcription
  works and TTS cannot be served. See `references/audio-input-testing.md`. For
  **Chinese** speech the audio path is a dead end — it encodes the input and answers
  with an English scene description, so route Chinese ASR to a real transcriber and
  read that reference's §7 before concluding the model is broken.
- An empty `content` field with a populated `reasoning` field means the token budget
  was consumed, not a failed parser — **`finish_reason="length"` decides the direction
  of the fix**. *Raise* the budget when reasoning is short (the classic trap: 200 tokens
  spent inside reasoning); *lower* it when reasoning is running away — 8192 at
  temperature 0.2 starved answers on prompts as short as 10k tokens, while 4096 at 0.6
  returned `finish_reason="stop"` with a real answer.
  **A third option beats both when the task needs no reasoning: turn thinking off.**
  Measured 2026-09-25 on the same 15.07 s speech clip through the production ASR path
  (`_mock: False`, HTTP 200 throughout): `max_tokens=4096` with thinking on = 72.9 s /
  3406 tokens / 35 characters; `8192` with thinking on = 159.9 s / `content: null` /
  `finish=length`; `4096` with **`chat_template_kwargs={"enable_thinking": False}`** =
  **0.6 s / 25 tokens / 34 characters / `finish=stop`** — a 121× speedup no budget change
  produces. Raising `max_tokens` is therefore the *wrong* direction for transcription or
  extraction: reasoning has no ceiling, so a larger budget only lengthens the run.
  Do not reach for the `/no_think` prompt prefix to get the same state — on this model it
  empties every answer (§2 of `references/generation-and-context-verification.md`).
  `chat_template_kwargs` is the switch that works; `/no_think` is the one that does not.
- MoE + NVFP4 decode is memory-bandwidth-bound: a 30B-A3B model can decode ~2x faster
  than a smaller dense BF16 sibling. Do not treat "smaller is faster" as a symptom.
- `openclaw gateway stop` does not stop an unmanaged foreground gateway; see
  `openclaw-process-scoped-kill` for scoped process control.

## Related
- `openclaw-model-config` — putting the served model into the agent's model list,
  repointing a provider at another endpoint, and keeping every id reference consistent
  after a rename.
