---
name: openclaw-process-scoped-kill
description: Killing or auditing all OpenClaw processes of one type (tui, gateway, agent) while keeping the current session alive. Use when asked to close other TUIs/sessions, or when runtime context reports no active sessions but detached work is running.
---

# OpenClaw Scoped Process Kill

## When to use
- "Kill every openclaw tui except this one" and similar scoped process requests
- Deciding whether runtime context's `Active exec sessions: none` is trustworthy
- Any time a kill list must exclude the process serving the current turn

## Steps

1. **Never trust the runtime session count alone; corroborate with `/proc`.**
   Internal context reports `none` for exec sessions, but processes started with
   `setsid` (and their whole subtree) leave the session group and stop being counted.
   A detached download or server can be running while context says nothing is.
   Enumerate directly:
   ```bash
   for p in $(ls /proc | grep -E '^[0-9]+$'); do
     CMD=$(tr '\0' ' ' < /proc/$p/cmdline 2>/dev/null)
     case "$CMD" in *openclaw*) echo "$p $CMD";; esac
   done
   ```
   Treat `/proc` as authoritative for liveness.

2. **Find the current session's own process chain before building the kill list.**
   Walk `$PPID` upward from the current shell and record every ancestor. A webchat
   turn runs `gateway → spawn-broker/worker.js → service-child-relay.js →
   service-child-group-anchor.js → bash`, and **has no controlling TTY** (`tty=?`).
   That means it cannot be carried by any `openclaw-tui` process on a pts, which is
   what makes "kill all other TUIs" safe to execute at all.

3. **Try to map the remaining candidates to their sessions before killing.**
   In order of decreasing reliability: process `environ`, open file descriptors,
   open regular files, heap memory scan for the session UUID, gateway journal
   (`journalctl --user -u openclaw-gateway.service`), and `openclaw sessions list --json`.
   When none of these yields a mapping — TUI clients do not expose their session key
   in the environment, files, or heap — say so explicitly rather than guessing.

4. **Build the preserve list before the kill list.**
   Always protect: the gateway process and its systemd unit, `spawn-broker/worker.js`,
   every `service-child-relay.js` / `service-child-group-anchor.js`, the current
   `bash` and its ancestors, and any unrelated CLI processes (`openclaw`,
   `openclaw-configure`) that are not the requested target type.

5. **Ask for confirmation when the mapping is ambiguous.**
   If step 3 cannot prove which candidates belong to the current session, present the
   evidence (process tree, tty, timestamps, heap-search misses) and the exact
   consequence, then wait for a yes. Never kill on a guess.

6. **Kill by exact PID, SIGTERM first.**
   Send `kill -TERM` to each listed PID, sleep, then re-check `/proc`. Escalate to
   `kill -KILL` only for survivors. Record the list first so the result is auditable.

7. **Verify after the kill, in this order.**
   No target-type processes remain; the gateway process and systemd unit are still
   `active`; the listening port is still bound; the current exec chain is still alive;
   any detached work (downloads, servers) still has live PIDs in `/proc`.

## Pitfalls
- A dead PID from an earlier snapshot is not evidence anything stopped; re-read
  `/proc` for every claim you make.
- Killing a `service-child-relay.js` or `group-anchor.js` kills the current turn's
  own plumbing. Only the requested target type is in scope.
- Detached work started with `setsid nohup ... < /dev/null` survives the exec session
  that launched it; that is why downloads keep progressing across turns.
  **`setsid` is the load-bearing part.** Plain `nohup cmd > log 2>&1 &` without it is
  still in the exec session's process group and is killed when that session ends — the
  symptom is a 0-byte log and a PID already gone on the next check, which reads as
  "the command failed instantly" rather than "the work never detached". Confirm
  detachment with `[ -d /proc/<pid> ]` from a later turn before concluding anything
  about a background job.
- **`pgrep -f <pattern>` matches the exec shell running your own command.** The shell's
  full cmdline contains the pattern text, so `pgrep -f "pdl.sh"` returns your own
  shell and `kill` aborts the turn with `Command aborted by signal SIGTERM`. Enumerate
  candidates by walking `/proc/*/cmdline` and excluding the current PID and every
  ancestor from `/proc/<pid>/stat` field 4, or anchor the pattern to something the
  shell does not contain (e.g. match `curl` by executable name with `pgrep -x`).
- **The same trap recurs through the gateway journal, in the opposite direction.**
  `[agent:nested]` writes this agent's own reply text into the journal, so a health
  grep counts its own prose as evidence. A standing check for
  `journalctl … | grep -E "stalled session|FailoverError"` returned 2 hits that were
  both lines of an earlier reply containing those words, and the same grep on a
  run that had just described them returned 2 more. Anchor to the logger's field
  before the keyword — the journal is JSON lines whose diagnostic rows live at
  `raw["subsystem"]`, with no `[diagnostic]` line prefix, so `grep -aE "\[diagnostic\]"`
  matches nothing at all and is worse than the bare grep:
  ```python
  import json
  for line in open('/tmp/openclaw/openclaw-<date>.log', encoding='utf-8', errors='ignore'):
      try: d = json.loads(line)
      except: continue
      raw = d.get('0')
      if isinstance(raw, str):          # <-- "0" is a JSON *string*; it needs a second decode
          try: raw = json.loads(raw)
          except: raw = {}
      sub = raw.get('subsystem','') if isinstance(raw,dict) else ''
      body = d.get('1'); txt = body if isinstance(body,str) else json.dumps(body, ensure_ascii=False)
      if sub == 'diagnostic' and 'stalled session' in txt: ...
  ```
  **The second decode is load-bearing.** `d["0"]` is a quoted JSON string
  (`"{\"subsystem\":\"diagnostic\"}"`), so a single `json.loads(line)` leaves `raw` a
  `str`, `isinstance(raw, dict)` is `False`, `sub` is `''` on **every** row, and
  `if sub == 'diagnostic'` matches nothing — the check reports a healthy journal with a
  straight face. Measured 2026-09-25 on this host: the one-decode form grouped all
  7,712 rows under subsystem `''`, where the two-decode form gave
  `provider-transport-fetch 2745 / agents/subagent-registry 2143 / channels-qqbot 797 /
  gateway-channels-qqbot 186 / diagnostic 135 / …`. If a field-anchored count comes back
  0, print the parsed row once before believing it.
  Two separate commands in one session were wrong for the same reason — first the
  bare keyword grep, then a prefix-anchored grep that looked stricter and matched
  zero rows — so treat "my check says 0" as needing the field anchor, not as a
  healthier result than a non-zero count. When a status report quotes a number,
  re-derive that number with the field-anchored form before repeating it.
