---
name: "local-media-processing"
description: "Local media processing (frames/OCR/ASR) in the vidproc conda env: ffmpeg fps extraction, tesseract chi_sim+eng, faster-whisper VAD trap, HF mirror flags."
---

# Local Media Processing (vidproc)

Resolve every media tool through the conda env `$HOME/miniconda3/envs/vidproc` — never the system python, and never a bare venv.

## Steps

1. Verify the env before use: run `$HOME/miniconda3/envs/vidproc/bin/ffmpeg -version` and confirm it prints `ffmpeg version 9.0.2`. Completion: version line printed.
2. Probe the media before transforming: `$HOME/miniconda3/envs/vidproc/bin/ffprobe -v error -show_entries stream=codec_type,width,height,r_frame_rate -show_entries format=duration -of json <file>`. Read fps/resolution/duration from this output; never assume them.
3. Extract frames at fps=2: `mkdir -p frames` then `$HOME/miniconda3/envs/vidproc/bin/ffmpeg -i in.mp4 -vf fps=2 frames/%04d.png`. Completion: frame count ≈ duration × 2 (24fps 854×480 15.07s clip → 30 frames in ~0.14s).
4. OCR with `$HOME/miniconda3/envs/vidproc/bin/tesseract frame.png stdout -l chi_sim+eng`. Always pass `-l chi_sim+eng` on mixed CN/EN frames — eng-only silently drops the Chinese. Completion: non-empty text for a frame that visibly contains text.
5. Do image/frame analysis with `$HOME/miniconda3/envs/vidproc/bin/python` (opencv 5.0.0, numpy 2.4.6, soundfile 0.14.0): video through cv2, audio through soundfile.
6. Transcribe with faster-whisper 1.2.1 from the same env. Treat a zero-segment result as inconclusive: VAD filters a quiet recording (~-30 dBFS) to nothing, so cross-check with `$HOME/miniconda3/envs/vidproc/bin/ffmpeg -i f -af volumedetect -f null -` and re-run with `vad_filter=False`. Completion: either a transcript, or a measured level plus a VAD-off re-run proving silence.
7. Download any HuggingFace model with both flags: `HF_ENDPOINT=https://hf-mirror.com HF_HUB_DISABLE_XET=1 <cmd>`. Direct connect times out and the xet-bridge handshake always times out. Completion: download finishes without a network timeout.
8. Re-run one real file end to end after any pipeline change and record measured numbers (wall time, frames, chars). A probe that only proves a 200 or a tool_calls shape does not prove working output.

## Install rules

- `sudo` requires a password and `apt` is unavailable — install missing tools with `conda install -n vidproc -c conda-forge <pkg>`.
- The env is ~1.5 GB (Python 3.11.16); rebuild from conda-forge rather than mixing in system packages.

## Related

- `thor-native-nemotron-vllm/references/local-media-extraction.md` — the same `vidproc`
  toolchain, but aimed at one job: preparing a local file so its audio can be compared against
  the `:8002` sound encoder (16 kHz mono conversion), with measured dBFS levels and the
  cross-modal corroboration check. Read it when the media is being tested *against* omni.
  Its §4 holds the measured rms values for the files that produced this skill's VAD floor.
- `livekernel-media-ingest` — operating the *service* intake path rather than the local
  pipeline: `asr_cli.py`, the `cli` branch in the adapter, and cleaning up test documents
  afterwards.
