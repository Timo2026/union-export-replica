# Media Understanding: `tools.media`

Read when step 4's media path applies: a model must accept an image, voice note, video, or
audio file; an attachment is ignored or misread; or a media route returns `ok:true` with the
wrong *kind* of text. Everything below was measured on 2026-09-25 against OpenClaw
2026.9.5 on this host.

## 1. Where attachments are actually selected

Two independent layers, and the second is the one people miss:

- `models.providers.<pid>.models[].input` — what the *model* accepts. Read it back with
  `openclaw models list` (column `Input`). Not this.
- `tools.media.models[]` — a capability-tagged list of **media entries**. This is what
  selects a model for an attachment, with `tools.media.<modality>.enabled` and
  `.preferredModel` choosing among them.

**There is no `audioModel` key in this version.** Verified: `grep -c audioModel
dist/index.js` → **0**. Writing one is silently ignored. Three neighbours that are real and
easy to confuse:

| key | actually is |
|---|---|
| `agents.defaults.imageModel` | older **image-only** path (image describe/generation fallback) |
| `agents.defaults.mediaModels` | image/video **generation** models |
| `agents.defaults.voiceModel` | voice/realtime capabilities, a separate lane |

Before editing anything here, enumerate what is valid rather than guessing a key:
`openclaw config schema` and `openclaw config get tools.media` (the second reads
`Config path is valid but unset` when nothing was ever authored — that is the default
state, and on this host it was exactly that until 2026-09-25).

## 2. Two entry types, and why a local engine needs the second

`tools.media.models[]` entries are either:

- **`type: "provider"`** — names a *registered* media-understanding provider id. The
  registry here is the external-provider catalog: `deepgram`, `elevenlabs`, `google`,
  `openai`, `openrouter`, `senseaudio`, `xai` (list with
  `openclaw infer audio providers --json`, or `image providers`). A locally served model's
  provider id is **not** in it.
- **`type: "cli"`** — runs a local command. This is the only route a local engine takes.

The asymmetry is in `runProviderEntry()` (`dist/runner.entries-Yy96XoK0.mjs`): for
`capability === "image"` it resolves `provider?.describeImage ?? describeImageWithModel`,
so an **unregistered provider id still works for images**; for `capability === "audio"` it
resolves `getMediaUnderstandingProvider(providerId)` and throws
`Audio transcription provider "<id>" not available` when the id is not registered. So
images get a local fallback and audio does not — which is why the same provider id that made
image work left audio failing with a provider-availability error rather than a model error.

## 3. The CLI entry contract

```json5
{
  type: "cli",
  command: "$HOME/.openclaw/bin/livekernel-asr",
  args: ["{{MediaPath}}"],
  capabilities: ["audio"],
  language: "zh",
  timeoutSeconds: 600,
}
```

- **Placeholders are double-braced: `{{MediaPath}}`.** `runCliEntry` maps each `args` element
  through `applyTemplate`, whose regex is `/{{\s*(\w+)\s*}}/gi`. A single-brace `{MediaPath}`
  matches nothing and reaches the script **literally** — the failure is your script's own
  usage error (`Command failed with exit code 2: … '{MediaPath}'`), which reads like a broken
  command rather than a template typo.
- Available placeholders: `AttachmentPath`, `AttachmentUrl`, `AttachmentContentType`,
  `AttachmentDir`, `AttachmentIndex`, `MediaPath`, `MediaUrl`, `MediaType`, `MediaDir`,
  `OutputDir`, `OutputBase`, `Prompt`, `Language` (audio only, when a language is set),
  `MaxChars`.
- **Output is `stdout.trim()`**, truncated to `maxChars`. By default nothing else is parsed.
  A few command basenames get special handling (`whisper`, `whisper-cli`, `parakeet-mlx`,
  `sherpa-onnx-offline`, `gemini` read a transcript file or a JSON field instead) — a custom
  name is the simple case: write the transcript to stdout and nothing else.
- Empty stdout is treated as "no result" (`if (!text) return null`) — the entry is skipped
  and the next fallback tried. **Exit non-zero on a real failure** so it is reported rather
  than silently falling through.
- `timeoutSeconds` here bounds the run; set it above the local model's cold start
  (a cached whisper `small` load took ~2m20s on this host, so 600).
- **`language` and `prompt` are template *values*, not environment variables.** `runExec`
  receives no `env` option, so nothing reaches the child process's environment — the only
  way a configured value reaches your script is a `{{Language}}` / `{{Prompt}}` placeholder in
  `args`, and `Language` is injected **only** when `capability === "audio"`
  (`...capability === "audio" && language ? { Language: language } : {}`). An entry that
  declares `language` while `args` contains only `{{MediaPath}}` is therefore **inert**: the
  script still runs, and whatever language it decides for itself is what you get. Verified
  2026-09-25 on this host, where the live entry reads `language: "zh"` with
  `args: ["{{MediaPath}}"]` while the script behind it auto-detects. Add `{{Language}}` to
  `args` before treating a configured language as authoritative.

## 4. What the audio/image knobs do

`tools.media.audio` (and `image` / `video`, same shape): `enabled`, `preferredModel`,
`language`, `maxBytes`, `maxChars`, `timeoutSeconds`, `prompt`, `attachments.mode`
(`first` | multi), `echoTranscript`, `echoFormat`, plus `scope`
(`{default: allow|deny, rules:[…]}` keyed by channel / chatType / keyPrefix) for restricting
where transcription runs at all.

- `preferredModel` for a CLI entry is `cli:<command>`, not `<provider>/<model>`.
- `prompt` is the **default transcription instruction** for entries that do not override it.
  Put "transcribe only, do not describe" here when the model tends to narrate.
- `echoTranscript: false` keeps the transcript out of the chat; `true` echoes it first.

## 5. Prove each modality, and judge the text — not `ok`

```bash
openclaw infer image describe  --file /tmp/x.png  --json
openclaw infer audio transcribe --file /tmp/timo_voice.wav --json
```

Success: `{"ok":true,"capability":"image.describe"|"audio.transcription","outputs":[{"text":…}]}`.
Unset pipeline: `{"ok":false,"error":{"message":"No audio transcription provider is
configured or ready …"}}`.

**`ok:true` does not mean the route is right.** This host's omni server returns `ok:true`
for audio with an **English scene description** where a Chinese transcript was required
("In the Tan Sui Xia, the mini can be high scale…") — the request was valid, the model
answered, and the output was the wrong *kind* of text. Read `outputs[0].text` against what
the task actually needs; for transcription, assert the transcript language and content
match the source. `provider` in the response names the entry that ran
(`livekernel-asr`, `nvidia-omni`, …), which is the record of which branch answered.

**Image-side attribution, cheap version:** flip `tools.media.image.enabled` to `false` and
re-run the same file. If it now fails, the success was this config rather than a stray
`agents.defaults.imageModel`.

## 6. Apply and verify

These are hot-reloaded like any other config path — no restart. Prove it from the journal,
not from the CLI's promise: `gateway/reload` rows naming
`tools.media.models` / `tools.media.<modality>.*` (`config change detected` then
`config hot reload applied`). Then re-read with `openclaw config get tools.media`.

Back up before editing (`cp ~/.openclaw/openclaw.json /tmp/ab_stash/openclaw.json.<ts>`)
and diff the flat key sets before and after: an intended `tools.media` edit must add keys
and remove none.

## 7. Local ASR wrapper (this host)

`$HOME/.openclaw/bin/livekernel-asr` — the `type:"cli"` entry point for audio. It
is a **thin shell** that `exec`s `timo_livekernel/scripts/asr_cli.py`, which runs
faster-whisper from the `vidproc` conda env, auto-detects the language (`LIVEKERNEL_ASR_LANG`
pins one), and keeps `vad_filter=False`. Read the repo script for the exit-code contract
(0 success; 2/3/4/5 usage/dependency/inference/empty) and the stderr audit lines that carry
the detected language; the reasoning behind the flag and the model choice lives in
`thor-native-nemotron-vllm/references/audio-input-testing.md` §7 and in `AGENTS.md`.

**A configured language is not a selected language.** Because of §3's template rule, the
`language: "zh"` on this entry never reaches the script — the transcript's language is
decided by the script's auto-detection. Do not conclude the entry is broken, or "fix" it by
rewriting the script, before checking whether `{{Language}}` is in `args`.

## Related

- `thor-native-nemotron-vllm` — serving the model, and `references/audio-input-testing.md`
  for what this checkpoint can and cannot transcribe (Chinese ASR returns an English
  description; TTS is unavailable).
- `openclaw-model-config` steps 4 and 7 — the two-layer declaration and the probes.
- `qqbot-channel-connect` — the channel side; its own media-glue pitfalls apply when the
  attachment arrives over QQ.
