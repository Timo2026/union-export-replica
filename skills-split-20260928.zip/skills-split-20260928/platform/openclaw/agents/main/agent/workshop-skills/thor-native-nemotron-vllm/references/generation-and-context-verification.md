# Generation and Context Verification (Nemotron/Omni on GB10)

Read this before quoting any number or verdict from this server: a benchmark, a
long-context run, an ASR or quality check, or a background test whose log looks
frozen. Every rule below exists because the opposite assumption produced a wrong
conclusion on this host.

## 1. Never let `max_tokens` or `ignore_eos` decide a verdict

Three traps, observed together:

- **`max_tokens` too small for a reasoning model.** With
  `--reasoning-parser nemotron_v3`, `reasoning` is emitted first and `content`
  only afterwards. At `max_tokens=200` the budget ran out inside `reasoning`,
  `content` came back empty, and a working ASR was recorded as a failure.
  Recognize it by: `finish_reason="length"` **and** a long `reasoning` field
  **and** empty `content`.
- **`ignore_eos=True` destroys quality measurements.** It forces output past
  every natural stop point; a 64000-token run collapsed to a 0.006 unique-word
  ratio purely from this flag. Use it only to prove a token count is
  *mechanically* reachable, never to judge output quality.
- **`stream_options: {"include_usage": true}` is required**, or `usage` never
  arrives in a stream and `prompt_tokens` reads 0.
- **A budget that is too *large* starves the answer as surely as one too small.**
  On this model `max_tokens=8192, temperature=0.2` made `reasoning` consume the
  entire budget on prompts as short as 10k tokens (`reasoning_chunks` ≈ 8000,
  `content` empty, `unique_ratio` 0.0), so a five-depth curve reported every row
  INCONCLUSIVE. At 4096/0.6 the same prompts returned `finish_reason="stop"` with
  answers. The signature to recognize is `finish_reason="length"` **and** empty
  `content`; it means the budget was consumed, not that the model failed.
- **Near-cap starvation is probabilistic, so one green run proves nothing about the
  next.** A structured-JSON call (named prompt + 3 few-shot, `max_tokens=2000`) was
  measured 2026-09-25 five times on **identical** input: `completion_tokens` 919 /
  1014 / 1694 / 1799 / 993 — every run `finish=stop`, 5/5 parseable, **201 tokens of
  headroom** at worst. The same call through the production chain landed over the cap,
  returned `live:parse_failed` with `content` cut mid-JSON, and the layer above read it
  as "no geometry extracted" and priced the part from defaults. The symptom is a parser
  error nowhere near the budget; the cause is a race. Report the headroom
  (`max_tokens - completion_tokens`) with any verdict, and treat a single green run on a
  near-cap budget as unmeasured. For a task needing no reasoning, close reasoning off
  instead of sizing around it: `chat_template_kwargs={"enable_thinking": false}` took
  this same call from ~919-1799 completion tokens to **80** (SKILL.md Pitfalls).

Rule: a quality verdict requires a natural stop (`finish_reason="stop"`) or an
explicitly budgeted run whose budget you account for. Never key PASS/FAIL on a
`finish_reason` you deliberately forced, and never key a retrieval or quality
verdict on `finish="length"` with empty `content` — that is budget starvation,
not a model result. When the task is extraction or transcription rather than
analysis, turn thinking off rather than sizing a budget around it — see SKILL.md's
Pitfalls for the measured switch.

## 2. `/no_think` suppresses the answer on this model

Prefixing a prompt with `/no_think` — a documented `chat_template.jinja`
toggle — made all six probes return empty `content` with 4–15 completion
tokens. Do not use it to force concise output here; raise `max_tokens` instead.

## 3. Request-size arithmetic: `prompt + max_tokens <= max_model_len`, plus drift

The server answers HTTP 400 when `prompt_tokens + max_tokens` exceeds
`max_model_len`. Two drift sources make an exact fit fail:

- **Chat-template drift is a constant +16 tokens** (server `prompt_tokens`
  minus your local `encode`), measured twice at the same value.
- **encode → slice → decode → encode is not lossless.** It added +1 token on a
  truncated body and +16 on a cached one. Build the final string, encode once,
  slice once, and never decode it back before sending.

Budget rule for a target output `O`:

```
local_encode <= max_model_len - O - 16
```

Verified boundary: `259960 + 16 + 64000 = 323976 <= 324000` accepted;
`260001 + 64000 = 324001` rejected.

## 4. TTFT is meaningless unless you defeat the prefix cache

With `--enable-prefix-caching`, re-sending an identical prompt reported TTFT
0.7 s, while a cold prefill of the same prompt took 109.8 s (2369 tok/s). Vary
the prompt before quoting any prefill or throughput figure.

For a reasoning model, time the first token of **either** field: `reasoning`
streams before `content`, so recording only the first `content` delta reports
`ttft=None` for every long prompt (observed for 131k and 260k) while the run is
healthy. Log `t_first_any` and `t_first_content` separately and quote the former
as TTFT.

Measured anchors on the live instance (2026-09-24, `8002`): prefill peaks at
~8,100 tok/s near 16k tokens and decays to ~3,300 tok/s at 260k tokens, so a
near-full-window prompt has a ~80 s latency floor; decode is ~64 tok/s.

## 5. A frozen log does not mean a stalled test

`setsid nohup python ... > log` buffers stdout, so a log can sit at 436 bytes
for 20 minutes while the run is healthy. Corroborate before concluding:

```bash
curl -s http://127.0.0.1:<port>/metrics | grep generation_tokens_total   # server-side truth
awk '{print $14+$15}' /proc/<enginecore-pid>/stat                          # CPU ticks
```

`num_requests_running=1` plus a rising token counter proves progress without
touching the client's stdout.

## 6. Context limits and the RoPE extrapolation zone

- Omni's native `max_position_embeddings` is **262144**
  (`tokenizer_config.model_max_length` is also 262144). Serving beyond it needs
  `VLLM_ALLOW_LONG_MAX_MODEL_LEN=1`, and vLLM warns that RoPE positions past
  the trained range can produce NaN.
- **Verified functional at +54k past native.** One request with a 316,428-token
  prompt generated 3000 tokens entirely at positions 316,428–319,428, recalled
  4/4 needles (two planted at token offsets 290,084 and 310,031, i.e. inside the
  extrapolated zone), kept a 0.060 unique-word ratio, and produced coherent
  prose. `metrics` showed `error=0`, `abort=0`, `repetition=0`.
- **Treat ≥180k as unreliable for retrieval, and >262k as unproven.**
  Five-depth recall curve, 2026-09-24 (4 ASCII passcodes per depth planted in a
  pure-Chinese filler, every row `finish_reason="stop"`): **10k 4/4, 30k 4/4,
  100k 4/4, 180k 2/4** (only the 20% and 50%-deep needles recalled; the 75% and
  95% needles were lost), **280k unproven** — one run returned `finish=stop`
  having fabricated all four codes, and its rerun was starved by §1's budget
  trap. The 180k row sits **inside** the native window, so deep-position loss
  begins well before RoPE extrapolation and cannot be blamed on it. The
  earlier +54k single-point test stays as one data point; it does not
  generalize across depths, so quote a depth curve rather than a point.
  Reliable operating range for needle recall: **≤100k tokens**.
- Cost of raising the window depends on the launch, so record the util with the
  number: 32768 window → 1,927,968 tokens (188.75x concurrency at 32k per
  request); 324,000 window at util 0.45 → 3,089,856 tokens in 44.22 GiB KV
  memory (45.11x at 324k per request); the same 324,000 window at util 0.30 →
  1,349,152 tokens (19.70x). A larger window trades concurrency, not just memory.

## 7. Designing a needle test that actually tests the zone

An earlier FAIL was a design error, not a model defect: the test demanded
60,000 generated tokens with `ignore_eos`, and the model tried to answer at
output token ~218 — absolute position ~257,122, still **inside** the native
range. Retrieval never entered the zone under test, and the `ignore_eos`-induced
repetition was misread as broken RoPE.

Rules:

- Put the generation itself in the zone: size the prompt so decoding starts
  past the boundary.
- Plant needles on both sides of the boundary and report each needle's token
  offset, so a hit can be attributed to native or extrapolated positions.
  Encode the final prompt locally first and assert each needle string is
  present in it — that proves the harness planted the needles before any
  retrieval claim is made.
- **Make each needle's surface form impossible to confuse with the filler.**
  Filler built from Chinese paragraphs carries its own `编号 NNNN` patterns, and
  needles labelled like them (`求索印记 阿尔法: 7Q4M2X`) drew answers of
  `求索印记: 9952` — fabricated numbers that read like filler text, so a miss
  and a hit were indistinguishable. Use codes the filler cannot contain
  (`K9QX4M`, ASCII and digits only) inside a pure-Chinese body; then any code
  appearing in the answer is unambiguous evidence of retrieval.
- Ask for a bounded answer, without `ignore_eos`.
- Report the unique-word ratio; collapse (<0.02) invalidates any recall score.

## 8. Name test scripts after their task, not after a stdlib module

A script saved as `bisect.py` broke every later run with
`ImportError: cannot import name 'URLError' from partially initialized module
'urllib.error'` — `random` imports `bisect` and picked up the script instead.
Use task names (`ctbound.py`, `rope_test2.py`).
