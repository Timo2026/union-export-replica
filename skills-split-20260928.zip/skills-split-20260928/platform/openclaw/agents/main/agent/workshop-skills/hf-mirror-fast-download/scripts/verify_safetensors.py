#!/usr/bin/env python3
"""Verify safetensors files are byte-complete by header arithmetic.

A truncated file usually still has a readable header, so parsing the header
alone proves nothing. Check `8 + header_len + sum(numel * dtype_bytes) == filesize`.

Usage: verify_safetensors.py <file.safetensors> [more.safetensors ...]
Exit code 0 when every file is consistent, 1 otherwise.
"""
import json
import os
import struct
import sys

DT = {
    "F64": 8, "I64": 8, "F32": 4, "I32": 4, "U32": 4,
    "F16": 2, "BF16": 2, "I16": 2, "U16": 2,
    "F8_E4M3": 1, "F8_E5M2": 1, "U8": 1, "I8": 1, "BOOL": 1,
}


def check(path):
    size = os.path.getsize(path)
    with open(path, "rb") as f:
        n = struct.unpack("<Q", f.read(8))[0]
        if n <= 0 or n > 100 * 1024 * 1024:
            return False, size, 0, 0, 0
        hdr = json.loads(f.read(n))
    data = 0
    nten = 0
    for k, v in hdr.items():
        if k == "__metadata__":
            continue
        nten += 1
        numel = 1
        for s in (v.get("shape") or []):
            numel *= s
        data += numel * DT.get(v.get("dtype"), 2)
    return (8 + n + data == size), size, nten, data, n


bad = 0
for p in sys.argv[1:]:
    ok, size, nten, data, n = check(p)
    print("  {}: {} bytes, {} tensors, header={} data={} expected={}  {}".format(
        p, size, nten, n, data, 8 + n + data, "OK" if ok else "MISMATCH"))
    if not ok:
        bad += 1
print("  => {} consistent / {} checked".format(len(sys.argv[1:]) - bad, len(sys.argv[1:])))
sys.exit(1 if bad else 0)
