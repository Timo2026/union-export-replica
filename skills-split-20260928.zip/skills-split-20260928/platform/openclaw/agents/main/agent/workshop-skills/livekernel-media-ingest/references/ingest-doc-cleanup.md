# Cleaning Up Test Documents After an Ingest

Read when ingest testing is finished, or when `GET /v1/rag/media/status` reports a `docs`
count that still includes your own test files. Measured 2026-09-25 on this host.

## Why an ingest leaves three traces

One `POST /v1/rag/media/ingest` writes to three independent places:

| layer | where | how it is counted |
|---|---|---|
| registry | `data/media_docs.json` (`REGISTRY`, a `docs` list) | `/v1/rag/media/status`'s `docs` field |
| vector point | the `ingest_docs` collection inside `data/rag_vectors.json` | `GET /v1/rag/docs` |
| file on disk | `data/media/<doc_key>.*` (original plus `.txt` transcript) | directory listing |

The registry and the vector store are separate files with separate counts, so a cleanup
that touches only one of them leaves the other reporting the test data.

## The two delete endpoints do different amounts

- `DELETE /v1/rag/docs/{doc_id}` calls `delete_ingested_doc()` → `store.delete()`, removing
  **only the vector point**. The registry row survives, so the status count stays high and
  the two listings disagree — which reads as a routing problem rather than an incomplete
  delete.
- `DELETE /v1/rag/media/docs/{doc_key}` removes **all three**: registry (`_save`), vector
  point (`media:{doc_key}`), and the files (`data/media/{doc_key}.*`). This is the one to
  use for a real cleanup.

## The `doc_key` is the stem, not the filename

`doc_key` is `Path(dest).stem`, so for a video named `…_a26d0e58….mp4` the key ends **before**
the extension — 98 characters, no `.mp4`. Passing the full filename returns
`404 doc not found`; passing the exact stored value succeeds. Read the key from
`GET /v1/rag/docs` or `data/media_docs.json` instead of reconstructing it from the filename,
which matters most for the long generated names.

## Procedure

1. Back up both `data/rag_vectors.json` and `data/media_docs.json` — neither is recoverable
   from the other stores, and `timo_livekernel` is not a git repo.
2. List what is in scope **with its timestamp**, so business data is never deleted by a
   cleanup pass aimed at your own test files:
   ```bash
   curl -s "http://127.0.0.1:8888/v1/rag/docs?limit=100"
   ```
3. Delete each test document through `/v1/rag/media/docs/{doc_key}` using the exact key.
4. Verify all three layers, by counting rather than parsing the fat vector file:
   - `GET /v1/rag/media/status` → `docs` equals the registry count
   - `GET /v1/rag/docs` → no test `customer_id` remains
   - `ls data/media/` → only pre-existing files

## Pitfalls

- `"vector_removed": false` in a delete response is normal when the vector point was already
  removed by an earlier call; it does not mean the delete was incomplete.
- A `data/media/` entry with a leading underscore (for example `_863b6f`) is a temporary
  directory left by an interrupted ingest, not a document — nothing references it, and it is
  safe to move aside.
- Deleting a point that a still-queued mail will re-ingest only removes it until that mail is
  processed; wait for the queue to reach a terminal state
  (`livekernel-mail-intake` holds the restart-and-verify discipline).
- Per-collection counts in the vector store are not all comparable: `ingest_docs` counts
  ingested media and mail attachments together, while `conversations` holds the far larger
  mail-derived set. Count the specific collection you cleaned.
