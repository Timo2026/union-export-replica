# Primary-Seat Fitness

Read this when a locally served model is about to take an OpenClaw agent's **primary**
seat, when a session emits corrupt-looking replies, or when an earlier verdict about a
model's agent fitness needs re-checking.

`scripts/promotion-gate.py` is what you run. This file is what its result means, plus the
two causes measured on this host that neither a probe nor a single bad turn can separate.

The capability **ladder** (the three levels a launch is accepted in, the four-task bench,
and the subagent-relay arithmetic trap) has its home in
`thor-native-nemotron-vllm/references/agent-loop-tool-calling.md`. Read it first when the
question is "is this server usable at all"; read this file when the question is "why did a
turn that returned HTTP 200 come back corrupt, and what fixes it".

## What each gate catches

| Gate | Shape | The failure it isolates |
|---|---|---|
| A | plain dialogue, no tools, no scaffold | `content` empty, or the reply replays a tool-call listing / scaffold heading — the 2026-09-24 corrupt turns on `:8002` |
| B | openai `tools` schema, `tool_choice=auto` | no `tool_calls`, wrong name, or arguments missing the required key |
| C | tool result returned, model must issue the next call | `content` and `tool_calls` both empty — the shape that starves when a reasoning parser consumes the budget |
| D | five identity probes | inconsistent self-identification — informational only |

Gate A is the one a curl probe cannot replace: it is the only gate without a tools
payload, so it is the only one that sees the model as a conversational model. Run it
first — a failure there means do not switch, whatever B says.

## Measured outcome on this host (2026-09-24 11:20–11:27)

`nvidia-omni/nemotron-omni-30b-a3b` at `127.0.0.1:8002`, once `maxTokens=16384` and
`timeoutSeconds=300` were set on both `nvidia-omni` and `nvidia-reason`:

- A: `我是Nemotron，由NVIDIA开发的大语言模型。`, `finish=stop`, reasoning 284 chars correctly
  separated into `message.reasoning`
- B: `get_weather(city="深圳")` in `tool_calls`
- C: `write(path=/tmp/omni_gate_c.md, content=Shenzhen's current temperature is 31°C.)`
- D: self-identifies as Nemotron/NVIDIA in **5/5** probes on the first run — but on a
  re-run minutes later, **3/5**, with two probes answering "通义千问 … 阿里巴巴集团" instead.
  Identity is unstable across runs and temperature 0.3, which is exactly why D is
  informational: a model can pass every hard gate and still mis-name itself. The
  parameter-count claim is fabricated too, and it moves with the thinking switch —
  measured 2026-09-25 on this server, thinking **off** self-reporting "数千亿参数"
  and thinking **on** "约 1750 亿参数" for a 30B-A3B checkpoint (actual: 30B total /
  3B active), with `reasoning_content: null` in both. Never quote a model's own size or
  identity as evidence of which model answered; the `[model-fetch]` journal line and
  `/proc/<pid>/cmdline` are.

A subagent then carried a real `exec` → tool-result → report chain correctly. So the
earlier verdict in `agent-loop-tool-calling.md` §3 — "route omni to short, low-branch tool
tasks" — was measured **before** the budget fault below was found, and should be
re-measured before it is relied on.

## Two causes measured for this endpoint's bad turns

They are different failures with different fixes, so separate them before declaring a
model unfit.

**1. Starved budget — a provider-config fault, fixed by config.** A vLLM
`--reasoning-parser` routes thinking into `message.reasoning`, which still consumes the
request's `max_tokens`. With the small default an unset `maxTokens` sends, reasoning fills
it and the turn returns `content: null` with `tool_calls: []`; the agent loop, holding
nothing to deliver, emits scaffold-shaped text. Same payload, two budgets:
`max_tokens=300` → `content:null, tool_calls:[]`; `max_tokens=4096` → correct `write` call.
This is the first thing to check on any empty turn, because it reads exactly like model
degradation.

**2. Repetition-penalty skeleton replay — a launch fault, fixed at launch.** The
checkpoint's `generation_config.json` ships `repetition_penalty: 1.0`, which let the agent
loop replay the previous turn's skeleton verbatim. This one is per-launch, so read it back
from `/proc/<pid>/cmdline` after any relaunch (`thor-native-nemotron-vllm` step 5).

## A non-fault that looks like one

`Embedded agent failed before reply: prepared model catalog owner config was replaced
during the read (<agentDir>)` is a transient reload race during `config set` hot reloads —
three turns failing inside one second sharing a traceId, zero afterwards. Re-send the turn
and confirm the journal count stopped growing before investigating anything else.

**A tool call rendered as plain text, with `finish_reason: stop`.** A probe that sends a
question but **no `tools` declaration** gets the call back as prose, not as
`tool_calls` — measured 2026-09-25 on `127.0.0.1:8002`, the request asking omni to check a
city's weather returned `content: "\nget_weather(\"北京\")"`, `tool_calls: null`, and
surface output of a few dozen characters; the *same* server with one `tools` entry plus
`"tool_choice":"auto"` returned the structured call. Auto tool choice is engaged by the
request, not by the launch alone, so this shape is the endpoint working. It is also exactly
the 2026-09-24 corrupt-turn signature (§3), which is the trap: before attributing a
text-shaped tool call to this model, confirm the payload declared `tools`. Canonical
request: `openclaw-model-config` step 7.

## Capability is not fitness

The ladder, and this conclusion, are in `agent-loop-tool-calling.md`. The part that
matters here: a passed gate list, a 200 tool-carrying curl, and a one-tool agent turn each
prove capability only. The primary seat is decided by a live session carrying a person —
one free-form conversational turn plus one multi-step tool chain, in the session that must
use them. When such a session produces a corrupt turn, do not decide fitness from that
turn alone: check cause 1 above first.
