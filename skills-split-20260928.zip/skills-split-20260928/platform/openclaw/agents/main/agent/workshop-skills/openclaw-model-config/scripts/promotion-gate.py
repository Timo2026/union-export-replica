#!/usr/bin/env python3
"""Pre-flight gate: promote a local vLLM to an OpenClaw agent primary model.

Lesson (2026-09-24, spark-388d): a curl probe returning 200 + valid tool_calls
only proves *tool-calling* eligibility. Used as a conversational primary, the
same model replied with fabricated "tool call sequences" as plain text.

Root cause chain:
  1) vLLM --reasoning-parser nemotron_v3 routes thinking into
     message.reasoning, which still consumes the max_tokens budget. With a
     small OpenClaw maxTokens default the turn ended with content=None and
     tool_calls=[] (agent loop starved) -> scaffold-shaped garbage text.
  2) generation_config.json shipped repetition_penalty 1.0, so the agent loop
     replayed the previous turn's skeleton verbatim (fixed: 1.05 in
     node_services.sh _run_omni()).
OpenClaw-side fix: models.providers.<p>.models[].maxTokens = 16384 and
timeoutSeconds = 300 for every provider that points at a reasoning-parser
vLLM endpoint.

Gates:
  A  plain dialogue  - content non-empty, no scaffold replay
  B  tool round      - valid tool_calls via the openai tools schema
  C  multi-turn      - issues a valid next tool call after a tool result
  D  identity (info) - how often it self-identifies as Nemotron/NVIDIA

Usage: python3 promotion-gate.py [base_url] [model]
"""
import json
import sys
import urllib.request

BASE = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8002/v1"
MODEL = sys.argv[2] if len(sys.argv) > 2 else "nemotron-omni-30b-a3b"
MAXTOK = 8192
SCAFFOLD = ("工具调用序列", "原始数据", "是否成功", "## 工具")


def chat(payload, timeout=300):
    req = urllib.request.Request(
        BASE + "/chat/completions",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def has_scaffold(text):
    return any(s in text for s in SCAFFOLD)


def report(name, ok, note=""):
    print(("PASS" if ok else "FAIL"), "-", name, ("-- " + note) if note else "")
    return 0 if ok else 1


fails = 0

# ---- Gate A: plain dialogue, no tools -------------------------------------
try:
    d = chat({"model": MODEL,
              "messages": [{"role": "user",
                            "content": "用中文一句话回答：你是什么模型？谁开发的？"}],
              "max_tokens": MAXTOK, "temperature": 0.3, "stream": False})
    msg = d["choices"][0]["message"]
    content = msg.get("content") or ""
    print("A content:", repr(content[:200]))
    print("A finish:", d["choices"][0].get("finish_reason"),
          "| reasoning chars:", len(msg.get("reasoning") or ""))
    fails += report("A plain dialogue: content non-empty, no scaffold replay",
                    bool(content.strip()) and not has_scaffold(content))
except Exception as e:
    fails += report("A plain dialogue", False, "%s: %s" % (type(e).__name__, e))

# ---- Gate B: tool round via openai tools schema ---------------------------
try:
    d = chat({"model": MODEL,
              "messages": [{"role": "user", "content": "深圳现在天气怎么样？"}],
              "tools": [{"type": "function", "function": {
                  "name": "get_weather",
                  "description": "Get weather of a city",
                  "parameters": {"type": "object",
                                 "properties": {"city": {"type": "string"}},
                                 "required": ["city"]}}}],
              "tool_choice": "auto", "max_tokens": MAXTOK,
              "temperature": 0.3, "stream": False})
    msg = d["choices"][0]["message"]
    tc = msg.get("tool_calls") or []
    print("B tool_calls:", json.dumps(tc, ensure_ascii=False)[:220])
    ok = bool(tc) and tc[0].get("function", {}).get("name") == "get_weather" \
        and "city" in (tc[0]["function"].get("arguments") or "")
    fails += report("B tool round: tool_calls[name=get_weather, args.city]", ok,
                    "" if ok else "no valid tool_calls")
except Exception as e:
    fails += report("B tool round", False, "%s: %s" % (type(e).__name__, e))

# ---- Gate C: multi-turn follow-through after a tool result ----------------
try:
    d = chat({"model": MODEL,
              "messages": [
                  {"role": "user",
                   "content": "帮我查深圳天气，然后写成一句话总结存到 /tmp/omni_gate_c.md"},
                  {"role": "assistant", "tool_calls": [
                      {"id": "call_1", "type": "function",
                       "function": {"name": "exec",
                                    "arguments": json.dumps(
                                        {"command": "curl -s -m 5 wttr.in/Shenzhen?format=1"})}}]},
                  {"role": "tool", "tool_call_id": "call_1",
                   "content": "Shenzhen: +31C"},
                  {"role": "user", "content": "好，现在写文件并给我最终一句话"}],
              "tools": [
                  {"type": "function", "function": {
                      "name": "exec", "description": "Run a shell command",
                      "parameters": {"type": "object",
                                     "properties": {"command": {"type": "string"}},
                                     "required": ["command"]}}},
                  {"type": "function", "function": {
                      "name": "write", "description": "Write a file",
                      "parameters": {"type": "object",
                                     "properties": {"path": {"type": "string"},
                                                    "content": {"type": "string"}},
                                     "required": ["path", "content"]}}}],
              "tool_choice": "auto", "max_tokens": MAXTOK,
              "temperature": 0.3, "stream": False})
    msg = d["choices"][0]["message"]
    tc = msg.get("tool_calls") or []
    content = msg.get("content") or ""
    print("C finish:", d["choices"][0].get("finish_reason"), "| tool_calls:", len(tc))
    for t in tc:
        print("   ->", t["function"]["name"],
              (t["function"].get("arguments") or "")[:150])
    if content:
        print("C content:", repr(content[:150]))
    ok = bool(tc) or (content.strip() and not has_scaffold(content))
    fails += report("C multi-turn follow-through: valid next call or real answer",
                    ok, "" if ok else "empty reply")
except Exception as e:
    fails += report("C multi-turn follow-through", False,
                    "%s: %s" % (type(e).__name__, e))

# ---- Gate D: identity stability (informational) ---------------------------
print("\nD identity probes (info, not a promotion blocker):")
good = 0
try:
    for i in range(5):
        d = chat({"model": MODEL,
                  "messages": [{"role": "user",
                                "content": "你是什么模型？谁开发的？只用一句话回答。"}],
                  "max_tokens": MAXTOK, "temperature": 0.3, "stream": False})
        txt = (d["choices"][0]["message"].get("content") or "").replace("\n", " ").strip()
        print("  D%d: %s" % (i + 1, txt[:90]))
        if ("Nemotron" in txt) or ("NVIDIA" in txt) or ("英伟达" in txt):
            good += 1
    print("D: self-identifies as Nemotron/NVIDIA in %d/5 probes" % good)
except Exception as e:
    print("D: probe error: %s: %s" % (type(e).__name__, e))

print("\n=== RESULT: %d hard gate(s) failed ===" % fails)
sys.exit(1 if fails else 0)
