---
name: external-mail-system-audit
description: |
  Auditing an exported or vendored email-automation package from another host before running it here: auto-send defaults, interpreter pins, external dependencies, mailbox ownership, credential redaction. Use when a zip or copy of an email receiver or auto-quote system arrives for review.
---

# External Mail-System Audit

## When to use
- A zip/export of another host's email receiver, auto-reply, or quote system arrives for review
- Deciding whether that package can be deployed here, adapted, or used as reference only

## Steps

1. **Read the send-policy defaults first.** Grep for `AUTO_REPLY_ENABLED`, `SMTP_`, `auto_send`. A package shipping `AUTO_REPLY_ENABLED = True` hands send authority to the system the moment it runs, contradicting the local rule that sends stay human-approved. If it cannot be made false in config, it is not deployable here — say so before spending effort on anything else.

2. **Resolve the interpreter before reading further.** A hardcoded `#!/usr/bin/env python3.8` plus `PYTHON_BIN = /usr/bin/python3.8` fails immediately where that binary is absent. Check `ls /usr/bin/python3.8` and `python3 --version` on this host before proposing any run.

3. **Enumerate the external dependencies the package assumes.** Follow every `os.path.expanduser` and `sys.path.insert` target and check it exists here (shared data layer, quote engine, SQLite DBs, optional geometry libs such as `gmsh`). Missing geometry tooling does not fail loudly: volume degrades to a file-size estimate, which silently corrupts every price derived from it.

4. **Check mailbox ownership from both sides.** Polling `UNSEEN` while another daemon owns the mailbox is a collision, but the verdict depends on who marks mail seen, not on shared use. Determine, for each consumer, whether it queries by `SEARCH UNSEEN` or by UID/ALL, and whether its fetch stores `\Seen` server-side. The starved party is the one that relies on `UNSEEN`: if the foreign package is the `UNSEEN` consumer and any co-tenant stamps `\Seen`, mail disappears for it. If instead the foreign package dedupes by UID (a `processed_ids.json`) and tolerates already-read mail, coexistence is a config decision rather than a blocker. Parse its account, folder, and seen-marking behavior before deciding, and state which side loses and how.

5. **Check where its prices come from.** If quotes are template values, or come from a different engine than the deterministic one in use here, its numbers are unusable even if the code runs.

6. **Check credential hygiene.** Look for plaintext authorization codes in config files and whether the export redacted them. Keep credentials out of chat, argv, and newly written files; a 0600 file or the secrets tool is the only acceptable route.

7. **Conclude with a deployability verdict, not a summary**: deploy as-is / deploy after change X / reference-only — each backed by the specific file evidence that forces it.

## Pitfalls
- A `COPY_MANIFEST.sha256` proves the copy is faithful to its source, not that the source fits this host.
- "Production in use" on the source host is not evidence of deployability here; the interpreter, user account, dependency paths, and mailbox are all host-specific.
- Carried-over state (`processed_ids.json`, old logs) can make a fresh deployment look like it has been running.
- A redacted credential in the export is not the same as a missing one — the real value exists on the source host and must not be requested through chat.
- A package built on `imaplib` with `SEARCH UNSEEN` is the fragile party in any shared box, because its trigger is a flag any other consumer can clear. Verify against live flags before and after a probe pull, not against the package's own claims.

## Related
- `livekernel-mail-intake` — the local gates and iron rules any adopted package must satisfy.
