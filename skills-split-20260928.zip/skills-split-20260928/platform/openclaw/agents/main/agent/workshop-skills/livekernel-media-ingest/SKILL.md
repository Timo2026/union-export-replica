---
name: "livekernel-media-ingest"
description: "Fix livekernel media intake: ASR language auto-detect, ffmpeg video gap, VLM thinking failures. Use for MOCK sources or wrong-language text."
---

# livekernel Media Ingest Repair

## When to use
- `GET /v1/rag/media/status` shows `ffmpeg: false`, or `asr.mode` is `omni` while a transcript is required
- An ingest returns `transcribe_source` starting with `MOCK` or `live:omni-asr`, or text in the wrong language for the recording
- A video ingest returns `MOCK:video-needs-ffmpeg`
- A VLM frame description fails with `content 为空 (… reasoning=… finish=length)`
- Ingest testing is finished and test documents must be removed from the production RAG

## Steps

1. **Read all four blocks of `/v1/rag/media/status` before changing anything.** It returns `asr` (mode/url/online/source), `vlm`, `embed` (`live`/`degraded`/`dim`), `ffmpeg`, `docs`. They degrade independently, so a single "media works" verdict is wrong in one direction or the other — fix `embed` first when `degraded:true`, or the ingest writes nowhere. `embed.live:false` **with** `source:"pending"` and `dim:null` is the pre-first-request state of a lazy init, not a fault; the source becomes `live:<url>` only after a real `embed()`, which a restart resets. Prove it with a search/ingest, not by re-reading the status.

2. **Do not install an ASR engine into the service interpreter.** livekernel runs `miniconda3/envs/occ/bin/python`, where `faster_whisper`, `funasr`, `whisper`, `openai_whisper` — and even `requests` — all raise `ModuleNotFoundError`. The engine must arrive as a subprocess from another env; the working one is `vidproc` (faster-whisper 1.2.1, models already cached under `~/.cache/huggingface/hub`).

3. **Let ASR auto-detect the language; never hardcode one.** `scripts/asr_cli.py` originally pinned `language="zh"`, and a 32s English recording came back as 29 bytes of garbage (`"NVIDIA INTERN!NVIDIA INTERN!"`) while the same audio auto-detected to a correct 368-byte transcript (`lang=en`, confidence 0.9749). Pin a language only through the `LIVEKERNEL_ASR_LANG` env var; the default must be `auto` → `language=None`. Log `info.language` / `info.language_probability` to **stderr** so stdout stays transcript-only, then regression-test both directions against a known Chinese and a known English clip.

4. **Put the engine in the repo.** Copy this skill's `scripts/asr_cli.py` to `<repo>/scripts/asr_cli.py` and `chmod +x`. It must write the transcript to stdout and nothing else, and exit non-zero on every real failure (`2` usage, `3` dependency, `4` inference, `5` empty) so the caller degrades honestly instead of reading silence as "no speech".

5. **Register it in `config/settings.yaml`** under `funasr`:
   ```yaml
   asr_mode: cli                        # funasr | omni | cli
   asr_cli: "scripts/asr_cli.py"        # resolved relative to repo root
   asr_cli_timeout_s: 900               # 38.6s audio + cold start measured 139-142s
   asr_cli_fallback: false              # see pitfalls
   ```

6. **Add the `cli` branch to `adapters/funasr_adapter.py`.** Read `asr_cli`, `asr_cli_python`, `asr_cli_timeout`, `asr_cli_fallback` from the `funasr` block; add `_transcribe_cli()` plus a `_resolve_asr_cli()` that accepts an absolute path and otherwise resolves relative to the repo root (`Path(__file__).resolve().parent.parent`). Success returns `_source: "live:asr-cli:<script name>"`; failure returns an explicit `MOCK(asr-cli failed: …)` or raises when `allow_mock:false`. Leave `_transcribe_omni()` reachable — it is both the fallback target and the `funasr` mode. **Edit `adapters/` at the repo root, not `services/adapters/`** — the running service imports the root copy and the other is a drift copy.

7. **Disable thinking on every call to the reasoning model, not just the ASR call.** `:8002` is `nemotron_v3`, a reasoning model: without `chat_template_kwargs={"enable_thinking": False}` the whole token budget burns on reasoning, the result is `finish=length` with empty `content`, and `_extract_content` raises — surfacing as `MOCK(vlm failed: RuntimeError('content 为空 …'))`. Grep the adapter for *all* `chat/completions` call sites and guard each one (ASR, `perceive_image`, and any future lane) with the same `disable_thinking` flag. A video ingest then returns `transcribe_source: "live:asr-cli:…+live:vlm:…"` with no MOCK.

8. **Give ffmpeg to the service, not to the shell.** `services/media_api.py` gates video on `shutil.which("ffmpeg")`, which searches only the process PATH — and the service PATH is `nemotron/bin:/usr/local/cuda/bin:/usr/local/{sbin,bin}:…`, with **no `~/.local/bin`**. `sudo` is password-gated, so symlink into a writable directory already on that PATH (`nemotron/bin` is first): a *copy* breaks, because the binary carries `RPATH=$ORIGIN/../lib` and would then look for `libavcodec` in the wrong tree. Confirm under the service's own PATH, not the shell's:
   ```bash
   env -i PATH=$HOME/miniconda3/envs/nemotron/bin:/usr/local/cuda/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/bin \
     ffmpeg -hide_banner -version
   ```
   `media_api` calls `which` per request, so this takes effect without a restart.

9. **Restart the service, then prove it with a real ingest.** livekernel is a tmux/uvicorn process, not a systemd unit: `bash $HOME/union-deploy/node_services.sh restart livekernel`, about 60s. Take the real PID from `ss -ltnpH "sport = :8888"` — `pgrep -f services.api_server` returns the tmux wrapper, whose cmdline also contains that string. Then:
   ```bash
   curl -s -X POST http://127.0.0.1:8888/v1/rag/media/ingest \
     -F "file=@/tmp/<real-speech>.wav" -F "customer=verify-cli-asr"
   ```
   A restart also rotates the service log instead of truncating it: `node_services.sh` now
   archives `svc.log` to `.1` (and `.1`→`.2` on up to `LOG_KEEP`, default 5, generations
   configurable with `UEA_LOG_KEEP=0` for the old truncate-in-place behaviour), so the
   previous boot's output and any crash trace stay readable — enable it before diagnosing an
   unexplained restart.

10. **Clean up test documents afterwards.** Each ingest writes a registry row, a vector point, and a file, and the two delete endpoints remove different amounts of them. Read `references/ingest-doc-cleanup.md` for which endpoint to use, how to derive `doc_key` from the generated name, and how to verify all three layers agree.

## Completion check
- `transcribe_mock: false`, `transcribe_source` carries a real source (Chinese → `live:asr-cli:`, video → both `live:asr-cli:` and `live:vlm:`), `indexed: true`, and `transcript_preview` reads as the actual speech in the actual language
- `embed_source` is a live URL, not a hash-degraded one
- a video ingest's `transcribe_source` carries real vlm/asr sources, never `MOCK:video-needs-ffmpeg`
- `ffmpeg: true` in `/v1/rag/media/status`
- `py_compile` clean on the adapter, `yaml.safe_load` clean on settings.yaml, rollback snapshot recorded
- test documents removed from all three layers, with the counts agreeing (`references/ingest-doc-cleanup.md`)

## Pitfalls
- **`asr.mode: "cli"` in the status endpoint proves nothing.** `media_status()` reads `ctrl().funasr.asr_mode`, and the controller is a module singleton built once at first use; `POST /v1/config/reload` refreshes only `config_reload` singletons, not `_CTRL`. A stale process reports `cli` while still executing the old code. The `_source` from a real ingest is the only proof. (`api_server.py`'s `/v1/models/config` handler nulls `_CTRL`, which would force a rebuild on the next call — read in source, not measured; a restart is the verified path.)
- **`asr_cli_fallback: true` puts the wrong kind of text into RAG.** The fallback is labelled `→omni-fallback:` in `_source`, but the indexed document text is still the English caption, and retrieval later surfaces it as if it were a transcript. Default it to `false` and accept an explicit MOCK instead.
- **A quiet recording is not an absent one.** VAD filters ~-30 dBFS speech to zero segments, so `vad_filter=True` yields a 0-char transcript that reads as "no speech". Keep `vad_filter=False` and cross-check with `ffprobe`/`volumedetect` before claiming silence.
- **A model load that hangs is usually the hub, not the model.** With the model already cached (`model.bin` 483,546,902 B, four symlinks intact, `refs/main` populated), `WhisperModel()` still probes huggingface.co for a revision, and direct connections here always time out — the process sat ~2 min at ~1 s CPU with all 20 threads in `futex_wait` and no stdout/stderr, which looks exactly like a corrupted model. Resolve it in the script itself: set `HF_HUB_OFFLINE=1` when `~/.cache/huggingface/hub/models--Systran--faster-whisper-<size>` exists, otherwise fall back to `HF_ENDPOINT=https://hf-mirror.com` with `HF_HUB_DISABLE_XET=1`. Also do not test a fallback by setting the env var to an empty string — `os.environ.get(key, default)` returns `""` and faster-whisper rejects it (`'' is not a valid language code`, exit 4).
- **Two ASR wrappers exist on this host and can drift.** `~/.openclaw/bin/livekernel-asr` serves OpenClaw's `tools.media` CLI entry; `scripts/asr_cli.py` serves livekernel. Keep them md5-aligned, or — as shipped — make the OpenClaw one a thin shell that `exec`s the repo script (single source of truth).
- **Check the supervisor is alive before blaming the code.** Both `union-deploy/node_services.sh` and `node_watchdog.sh` were mode 0644 while crontab declared them as direct executables, so every cycle logged `Permission denied` (194 of them) and nothing self-healed from 12:31 onward. **`chmod +x` on both files was the whole fix; the crontab was never wrong.** Verified with a deliberate canary: SIGTERM to searxng produced `watchdog: searxng DOWN on :8080` → `relaunching searxng` → `READY on :8080 after 3s` → `relaunch reported OK`, then `GET /search?q=test` returned HTTP 200. A restart also proves the entry point: `bash node_services.sh start all` idempotently adopts the five services (memAvailable floor 6 G, 15-min/3-restart crash-loop cap, flock single-instance). The shebang is `#!/usr/bin/env bash`, so `bash <script>` also works — a `Permission denied` on direct execution means the exec bit, not the interpreter.
- **Do not verify a mutation in the same parallel batch as the mutation.** A `chmod +x` issued in one exec while a direct-execution probe ran in a sibling produced a spurious `Permission denied`, which briefly suggested a `noexec` mount. Mutate, then verify, serially.
- **`pgrep -f <pattern> | kill` kills the shell running your own command.** Its cmdline contains the pattern too. Enumerate `/proc/*/cmdline` and exclude your own PID plus its ancestors, and never trust a runtime "running" record — confirm with `/proc/<pid>` or `ss`.
- `timo_livekernel` is not a git repo, and neither is `union-deploy`. Back up `adapters/funasr_adapter.py`, `config/settings.yaml`, and `node_services.sh` under `/tmp/ab_stash/` first, and pin the baseline with `stat` + `md5sum` — several snapshots of the same file can coexist there and get mistaken for one version. After any edit, re-check the exec bit and `bash -n`; losing the bit is exactly how the watchdog died at 12:31.

## Related
- `openclaw-model-config` — the OpenClaw half of this path (`references/media-understanding-pipeline.md`): `tools.media` entry types, the `{{MediaPath}}` double-brace contract, and the media probes.
- `local-media-processing` — the `vidproc` env itself: frame extraction, tesseract `-l chi_sim+eng`, the VAD trap, HF mirror flags.
- `thor-native-nemotron-vllm` — what the `:8002` model can and cannot transcribe, and its reasoning-model token budget.
- `livekernel-mail-intake` — the restart and PID-verification discipline on this same service.
- `references/ingest-doc-cleanup.md` — which delete endpoint removes what, deriving `doc_key`, and verifying the three layers agree.
