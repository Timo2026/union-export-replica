# Reading a Local Video or Audio File on This Host

Read this when the material to understand is a **file on this host** — an `mp4`, `m4a`, a
screen recording — rather than a request that arrives at the server. This is the upstream
half of SKILL.md step 8: it prepares the media, and it separates a chain that worked from
one that merely returned text.

## 1. Build the toolchain once, out of conda

`sudo` needs a password and `apt` is unusable here, so the toolchain is a conda env:
`$HOME/miniconda3/envs/vidproc` (Python 3.11.16), carrying ffmpeg 9.0.2 /
ffprobe 9.0.2, tesseract 5.5.3 (125 languages, including `chi_sim` + `eng`), opencv
5.0.0, faster-whisper 1.2.1, numpy 2.4.6, soundfile 0.14.0, pytesseract 0.3.13.

Call the env's binaries by absolute path (`$HOME/miniconda3/envs/vidproc/bin/…`).
A `ffmpeg`/`tesseract` found on `PATH` belongs to whichever env exported `PATH`, and a
version check against the wrong one is worse than no check.

**Every model download from HuggingFace needs two env vars.** `huggingface.co` times out
directly and the xet transfer handshake always times out:

```bash
HF_ENDPOINT=https://hf-mirror.com HF_HUB_DISABLE_XET=1
```

A download that "hangs with no progress and no error" is the xet bridge, not bandwidth.

## 2. Probe, then extract at the lowest rate that keeps the content

`ffprobe` first — it reports the real codec, frame count, and audio track, which is what
a later claim must match. A 854×480 h264 / 24 fps / 15.07 s / 4.6 MB mp4 carried 361
frames and a 32 kHz stereo AAC track.

Extract frames with `ffmpeg -vf fps=2` rather than a fixed count: 30 frames / 1.2 MB in
**0.137 s** on this host. Then OCR the frames when the screen carries text — for a screen
capture, tesseract usually recovers the very prompt the video was made from, which is
often the only text in the file.

## 3. Convert audio to the encoder's input shape before sending

The omni sound encoder is 16 kHz, parakeet-style (SKILL.md step 8). One conversion is
enough: `ffmpeg -ac 1 -ar 16000` to a mono `.wav`. A 48 kHz stereo 32.3 s m4a became a
1,034,990 B wav; the mp4's own track became 482,382 B.

Measure the level before judging any transcript. `soundfile` + numpy give rms/peak per
channel; on this host the same day's material read −9.0 dBFS (pure 440 Hz tone), −22.3
dBFS (the video track), and **−30.9 dBFS** (a light voice recording).

## 4. Two ways to get 0 characters, and which one means "quiet"

faster-whisper (offline fallback) VAD-filters below its speech threshold, so a quiet file
returns **0 characters in 0.1 s** while a louder one of similar length returned 31
characters in 0.4 s. Zero characters on a negative-rms file is a VAD silence, not an
absence of speech. Report the rms with the empty transcript, and put the loudest clip
through the server before calling a recording silent.

## 5. Corroborate the modalities against each other

When one source yields several modalities, they check each other. A video's own audio
transcribed as "…含散热孔和安装孔" while OCR of those same frames read the on-screen prompt
"请帮我设计一个 GV 内挂机:预安装孔" — two independent extractions of one instruction, from
different pipelines. **That agreement, not a fluent answer from either path alone, is the
evidence the whole chain is real.** When the two disagree, suspect extraction before
suspecting the model, and re-run the extraction.

## Completion check
- ffprobe's frame count and audio-track format match what you extracted
- the extracted frames OCR to text, or the frame count itself is the stated evidence
- audio is 16 kHz mono, and its transcript is reported **with** the measured rms
- the modalities either agree, or the disagreement is named as the next thing to fix
- any figure you took from a subagent about this extraction was re-derived by you
