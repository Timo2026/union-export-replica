# Engine-side silent parameter gaps (measured 2026-09-23)

Every gap below **raises nothing**, returns a complete confident quote, and is visible only
in `cost_breakdown`. Before quoting any part whose requirements include a roughness,
tolerance, or surface tier, read this file. All measurements come from the same
Ø80 × 3 mm 12-tooth 304 gear (z=12, m=6.667, α=20°), priced through
`main_lite.calc_quote`.

## 1. The adapter's key mapping drops roughness

`TimoAdapter._rfq_to_params` (`adapters/timo_adapter.py:260`) is a hand-written projection
carrying exactly eight process keys: `material`, `surface`, `surface_treatment`,
`quantity`, `weight_kg`, `max_dim_mm`, `tolerance`, `surface_area_dm2`, `thread_count`,
`dim_x/dim_y/dim_z`. **There is no roughness key.**

Passing `roughness_ra=1.6` through the public `TimoAdapter.quote()` is therefore accepted
and silently discarded. The response reports `roughness_ra: 0.0` and
`cost_breakdown.rough_coef: 1.0`, so a Ra1.6 part is priced as if Ra3.2.

| route | qty=1 unit price | `cost_breakdown.rough_coef` |
|---|---|---|
| `TimoAdapter.quote()` (public) | 305.41 | 1.0 ← Ra lost |
| `timo._offline("calc_quote", {...})` full signature | 325.84 | 1.15 ← correct |

That is a **6.3 % under-quote**, and `cost_breakdown` is the only place it is visible.

**Rule:** when a requirement carries roughness (or any coefficient beyond the eight keys
above), call the engine through `_offline("calc_quote", params)` with the full
`main_lite.calc_quote` signature rather than the public adapter route, then assert
`cost_breakdown` shows the coefficient you expect (`tol_coef`, `rough_coef`,
`volume_discount`) before quoting. The same applies to `thread_count` when the geometry
carries holes the requirement named.

### 1b. The same projection destroys a tiny part's weight — the paired drop

A second silent drop lives in the *same* hand-written projection, and it reaches the
0.5 kg default by a different route, so a clean `volume_source` does not clear it:

1. `adapters/_kernel_bridge.py` computed `round(weight_kg, 4)`, which turns a
   2.68e-05 kg part (volume 3.36 mm³ × 7.98 g/cm³, a few-mm part) into exactly `0.0`.
2. `adapters/timo_adapter.py:269` then evaluated
   `float(rfq.get("weight_kg", 0.5) or 0.5)` — and `or` treats `0.0` as absent, so the
   engine default 0.5 kg replaced the real value.

The part priced at **443.30 against 130.27** at its true weight — a 3.4× over-charge on a
correctly parsed file, with `volume_source` still reading `ocp_brep`.

**Rule:** assert the weight is *plausible*, not merely present. Recompute
`volume_mm3 × density / 1e6` and reject any part whose bounding box is under ~100 mm while
reporting 0.5 kg. Both layers are fixed — `float(f"{w:.9g}")` in the bridge (9 significant
figures preserves a milligram part where `round(x, 4)` and even `round(x, 9)` do not) and
an `isinstance(...) and > 0` test instead of `or` in the adapter — so re-check after any
change to either file. This is why `density_guard` in §4 also formats with `%.9g`.

## 2. `surface_area_dm2` is the bounding-box area, not the part's

`step_geometry` reported `surface_area_dm2: 1.854` for the gear. The true B-rep area from
`BRepGProp.SurfaceProperties_s(shape, props).Mass()` is 111.647 dm² — 66 % lower. The
engine value is exactly `2·(93.33² + 2·93.33·3)/10000`, i.e. the area of the shape's
enclosing box, which for any thin non-square part overstates the real surface.

Harmless while `surface="无"` (`surface_cost = 0 + 0 × area`), but every plating tier
multiplies that area by `SURF_AREA_RATE` (镀锌 30, 镀铬 25, 氮化钛 50, dlc 60 元/dm²), so a
plated part is over-charged on the box area. For a B-rep area, measure it:

```python
from OCP.BRepGProp import BRepGProp
from OCP.GProp import GProp_GProps
props = GProp_GProps()
BRepGProp.SurfaceProperties_s(shape, props)
area_dm2 = props.Mass() / 100.0
```

## 3. 去毛刺 has no tier, and cannot be given one

`SURF_COEFS`, `SURF_FIXED_FEE`, and `SURF_AREA_RATE` share the same 14 keys —
无 / 发黑 / 阳极氧化 / 镀锌 / 镀铬 / 镀镍 / 磷化 / 喷漆 / 喷砂 / 钝化 / 氮化钛 / dlc — with
no deburring entry anywhere. A deburring requirement passed as `surface="去毛刺"` therefore:

- matches no key, so `surf_coef = 1.0`, `surf_fixed = 0.0`, `surf_area_rate = 0.0`
- raises no conflict, since `SURF_INVALID` is also keyed on those 14 names
- prices at ¥0

Do **not** force it into `surface`; the string just disappears. Carry the deburr
requirement in the quote sheet's own notes and add the labour as a business-side amount
(≈ ¥1–2 per part observed for a gear of this size), stating that the engine tier
contributes nothing.

## 4. The engine's density table misses four priced materials, so they weigh 2.8

`step_parser.get_material_density` (`src/runtime/step_parser.py:158`) resolves through
`DENSITY` in `src/runtime/step_generator.py`, which holds **14 entries**:
`45钢 / 45# / q235 / 6061 / al6061 / 7075 / 304 / sus304 / 316l / sus316 / tc4 /
钛合金 / h59 / 黄铜`. Any other key takes the module default **`2.8`**.

Four of the keys `MAT_PRICE_PER_KG` *does* price are absent from that table, so they are
weighed at 2.8 g/cm³ while the quote uses their real billet rate — both numbers wrong in
the same direction:

| key | real density | engine uses | weight error |
|---|---|---|---|
| `yg8` (tungsten carbide) | 14.50 | 2.8 | **5.2× under** → material cost understated |
| `440c` | 7.85 | 2.8 | 2.8× under |
| `pom` | 1.41 | 2.8 | 2.0× under |
| `abs` | 1.04 | 2.8 | **1.7× over** → material cost overstated |

BOM names carrying a modifier — `YG8钨合金`, `POM 白色` — hit the same wall from the
other direction and land on 6061 (see SKILL.md step 4). So a tungsten-carbide part can be
under-weighed 81 % *and* under-priced at aluminium rates simultaneously.

`density_guard.audit_geometry(geo, material)` (`services/density_guard.py`, added
2026-09-23) is the guard, and `TimoAdapter.step_geometry` already calls it: it keeps the
B-rep volume as fact, substitutes the authoritative density, and leaves
`density_engine` / `density_authoritative` / `density_corrected` / `density_verified`
behind so the substitution is auditable rather than silent. It preserves precision with
`float(f"{w:.9g}")` — a fixed `round(w, 4)` would zero a 2.7e-05 kg part (SKILL.md step 3).

**Rule:** after any geometry call, read `density_verified` / `density_corrected` from the
result. A `True` on `density_verified` is the completion check; a `density_verified: False`
means the material has no authoritative density and the weight must not be quoted. This is
the density-side twin of step 1: both are silent drops that only show up by reading the
response back.

## 5. Reading the verdict back

The only reliable check is `cost_breakdown`, which returns every coefficient separately:

```python
{"base_fee", "material_cost", "machining_cost", "setup_cost", "qc_cost", "surface_cost",
 "tol_coef", "rough_coef", "surface_area_dm2", "process_coef", "surf_coef_legacy",
 "thread_cost", "thread_fee_per_hole"}
```

A quote is sound when each named requirement has a matching non-default coefficient:
roughness → `rough_coef != 1.0`, tolerance grade → `tol_coef != 1.0`, quantity → the
`volume_discount` ladder. Cross-check by recomputing the unit price from the parts:

```
base_fee + material_cost + machining_cost×tol_coef×rough_coef
           + setup_cost + qc_cost + surface_cost + thread_cost
```
then apply the quantity premium (1.5 × for 6061 at qty=1, 1.2 × for other materials) and
the thin-part premium (3.0 × for 6061, 2.0 × otherwise, when `min(dim) ≤ 3` and
`max/min < 30`). For the gear that reproduces 325.84 exactly, which is what proves the
tolerance and roughness coefficients both reached the price.

## Related
- `../SKILL.md` step 4 — the material-recognition rule these gaps generalise.
- `ocp-geometry-code` step 5 — reading a written STEP back, for the geometry side.
