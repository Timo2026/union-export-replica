---
name: hf-mirror-fast-download
description: Downloading or resuming large HuggingFace model files on this host (huggingface.co blocked, hf-mirror.com fast). Use when a model download is slow, truncated, or must be proven byte-complete before serving.
---

# hf-mirror Fast Download

## When to use
- Fetching model weights from HF on this host (`huggingface.co` times out; `hf-mirror.com` works)
- `huggingface_hub` LFS crawl (~1.8 MB/s) is too slow, or an earlier download is truncated
- Verifying a local safetensors set is byte-complete before serving

## Steps

1. **Get the authoritative file list and sizes from the HF API.**
   `curl -s "https://hf-mirror.com/api/models/<repo>?blobs=true"`
   Parse `siblings[].lfs.size`. Without `?blobs=true` every size comes back 0.
   Save the result — it is the size contract used for later verification.

2. **Resolve a single file's true size with a 1-byte Range request.**
   `curl -sL -r 0-0 -D - -o /dev/null -m 120 "<url>"`
   The answer is `Content-Range: bytes 0-0/<total>`. Parse the token **after** the
   `bytes A-B/` prefix:
   `awk 'tolower($1)=="content-range:"{n=split($3,a,"/"); if(n>=2 && a[2] ~ /^[0-9]+$/) print a[2]}'`
   Field 2 is the literal word `bytes`; parsing it yields nothing and the caller sees
   "cannot determine size".

3. **Always pass `-L` together with `-r`.**
   hf-mirror answers a Range request with `HTTP/2 302`. Without `-L`, curl stores the
   ~1 KB redirect page as file content. Symptom: every chunk file is exactly ~1058 bytes
   and aggregate throughput reads 0 MiB/s.

4. **Parallelize when a single connection is slow.**
   One connection here runs ~1 MiB/s; 6–8 connections aggregate ~7–8 MiB/s.
   Use `scripts/pdl.sh <repo> <filename> <outfile> [nconn]`: it splits the remaining
   tail into equal ranges, launches each chunk with `setsid nohup` so it survives the
   exec session, and runs a parent retry loop with `--retry 8`.

5. **Kill stalled chunks; do not wait out `-m`.**
   A wedged curl with `-m 7200` holds its range for up to two hours. Detect it by
   sampling chunk size and `/proc/<pid>/stat` CPU ticks over 30 s: 0 bytes growth
   **and** frozen ticks means dead. `kill -TERM` it — the parent loop relaunches the
   chunk from its current size with `curl -C -`, and a fresh connection usually runs at
   full speed again.

6. **Assemble with byte-exact truncation.**
   `curl -C -` combined with `-r` over-downloads; a chunk file can exceed its target
   length. Never `cat` the chunks. Write each chunk's first `CSZ` bytes at its offset:
   `dd if=c$i of=$OUT bs=1M iflag=skip_bytes,count_bytes skip=0 count=$CSZ oflag=seek_bytes seek=$((BASE+i*CSZ)) conv=notrunc status=none`
   Then confirm `stat -c %s` equals the remote total exactly.

7. **Verify safetensors by header arithmetic, then by sha256 when chunks were assembled.**
   Read the 8-byte little-endian header length, parse the JSON, and check
   `8 + header_len + sum(numel * dtype_bytes) == filesize`.
   Run `scripts/verify_safetensors.py <files...>`. A truncated file often still has a
   perfectly readable header, so parsing the header alone proves nothing.

   Header arithmetic only proves size consistency — it cannot tell correct bytes from
   wrong bytes at the same length, which is exactly the risk when a file was assembled
   from chunks that over-downloaded. For any assembled file, also verify content against
   the repo's LFS pointer:
   ```bash
   curl -sL "https://hf-mirror.com/<repo>/raw/main/<file>"   # -> "oid sha256:<hex>"
   sha256sum <file>
   ```
   Size plus sha256 both matching is the completion check before serving.

## Pitfalls
- The cache root is `<CACHE>/hub/models--<org>--<name>/files/`. `blobs/` is the symlink
  target store and can look empty while `files/` is complete — checking `blobs/` and
  concluding "weights missing" is a wrong conclusion. Always check `files/`.
- `.incomplete` leftovers are not evidence about `files/` content; only delete them
  after the real target is verified.
