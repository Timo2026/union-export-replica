# Audio Input Testing (Omni NVFP4 on GB10)

Read this when step 8's audio path applies: an audio part was sent, you must prove it
was encoded, or you need to judge whether the model can transcribe.

## 1. Dependencies that actually gate audio

`vllm/multimodal/media/audio.py` try-imports `av` (PyAV) at **module scope** and swaps
in a `PlaceholderModule` on failure. The failure only surfaces when an audio request
decodes, and the message names the wrong extra:

```
Please install vllm[audio] for audio support
```

The missing package is `av`, not librosa/soundfile (both are already in the nemotron
env). Fix, then **restart the server** — the import happens at module scope, so a
running EngineCore keeps the placeholder:

```bash
pip install av          # verified: av-18.1.0, cp311-abi3 aarch64 wheel
```

`librosa` and `soundfile` cover the processor's own loading path; `av` covers the
server's decode path. Both are required.

## 2. Predict the audio token delta; do not eyeball it

The processor computes sound tokens from the waveform length
(`processing.py::_process_audio`):

```
num_frames = samples // audio_hop_length      # hop_length = 160
n_tokens   = ceil(num_frames / audio_subsampling_factor)   # factor = 8
```

At `audio_sampling_rate` 16000 that is ~13 sound tokens per second. So the deltas
below are **correct encoding**, not a dropped input:

| clip | predicted | observed `prompt_tokens` delta |
|---|---|---|
| 0.8 s | 10 | +13 (10 sound + 3 text) |
| 1.2 s | 15 | +19 |
| 1.5 s | 19 | +22 |

Both `input_audio` (OpenAI-standard) and `audio_url` are accepted by the server after
`av` is installed; do not conclude a type was dropped from a small delta.

## 3. Test with speech, not tones

`sound_config` describes a parakeet-style recognizer (128 mel bins, 16 kHz, 24 layers).
It was trained on speech, so a pure sine tone is out of distribution: a 440 Hz tone
answered "~110 Hz / sawtooth" — that is hallucination, not recognition, and proves
nothing about ASR. Synthesize known text instead.

## 4. Synthesizing test speech on this host

There is **no `espeak-ng` CLI** and no `espeak`/`pico2wave`/`festival`; only the shared
library `libespeak-ng.so.1` is present. The `py-espeak-ng` pip package shells out to
the CLI and fails here. Drive the C library directly with ctypes:

```python
import ctypes
lib = ctypes.CDLL("libespeak-ng.so.1")
lib.espeak_Initialize.restype = ctypes.c_int
sr = lib.espeak_Initialize(ctypes.c_int(1), ctypes.c_int(0), None, ctypes.c_int(0))  # 1 = RETRIEVAL
lib.espeak_SetVoiceByName(b"en-us")

CB = ctypes.CFUNCTYPE(ctypes.c_int, ctypes.POINTER(ctypes.c_short), ctypes.c_int, ctypes.c_void_p)
buf = bytearray()
@CB
def cb(w, n, e):
    if w and n > 0: buf.extend(ctypes.string_at(w, n * 2))
    return 0
lib.espeak_SetSynthCallback(cb)          # pass the decorated function, not CB(cb)
lib.espeak_Synth(b"hello world", 11, 0, 0, 0, 1, None, None)   # flags=1 (espeakCHARS_UTF8)
lib.espeak_Synchronize()
```

Traps:
- `output=1` (RETRIEVAL). `output=2` (SYNCHRONOUS) opens the audio device and segfaults
  headless.
- Pass the decorated `cb` to `espeak_SetSynthCallback`; wrapping it again makes a
  double function pointer and segfaults.
- Native rate is 22050 Hz; resample to 16000 Hz to match `sound_config`.
- `synth_wav(txt, fmt='txt')` from the pip package returns WAV **bytes** and does not
  write a file, and it needs the CLI — unusable here.

## 5. Reading ASR results

- Prompt for a transcript, not an analysis: `"Transcribe the English speech exactly as
  heard. Output only the transcript."`
- An answer that is reasoning about the task ("The user wants me to transcribe...")
  is a budget/instruction failure, not an audio failure; re-run with a larger
  `max_tokens` and the direct instruction.
- Score with word-level similarity, not exact match. With espeak-ng (formant, not
  neural) speech, expect roughly 6/10 phrases exact and ~64% mean similarity; short
  phrases land, digit strings degrade. Treat that as the floor for this synthetic
  voice, not the model's ceiling on natural speech.

## 6. TTS is not available on this checkpoint

The tensor map has `sound_encoder` (708 tensors) and `sound_projection` (3) — input
side only. There is no decoder, vocoder, flow, wav2vec, hifi/bigvgan, codec, upsample,
istft, or speaker projection anywhere in 25205 tensors, and `language_model` has no
audio output head. Audio-in works; audio-out does not. Serve TTS from a separate model.

## 7. Chinese speech: it encodes, but it does not transcribe

This checkpoint is not the ASR engine for Chinese. Measured 2026-09-25 on a real 38.6 s
Mandarin voice note (1854798 B, pcm_s16le 24 kHz) through livekernel's production path
(`POST 127.0.0.1:8888/v1/upload/audio`, field name **`file`**):

```json
{"ok":true,"text":"In the Tan Sui Xia, the mini can be high scale, which is a bit
 more than a bit.","_mock":false,"_source":"live:omni-asr:127.0.0.1:8002"}
```

Three things that read separates are not separates:

- **`_mock:false` proves the channel, not the language.** The request really reached
  :8002 and really was answered — the pipe is live. It says nothing about the output kind.
- **§2's token arithmetic still holds, and must not be re-litigated.** omni *encodes*
  Chinese speech exactly as measured (~13 sound tokens/s, +19 for a 1.5 s clip). The
  audio is not being dropped. Encoding and transcription are different claims, and a
  wrong transcript does not overturn the token count.
- **The output is an English scene description, not a transcript.** The same failure
  shape for an English clip would read as success, which is why a synthetic-English
  test in §3–§5 would have green-lit this checkpoint as an ASR engine. Test with the
  language you actually need.

**Rule: for Chinese speech, route to a real transcriber.** What worked on this host is
faster-whisper from the `vidproc` env behind OpenClaw's `tools.media` `type:"cli"`
entry (`openclaw-model-config/references/media-understanding-pipeline.md` §3 for the
contract). Measured on the same file, through `openclaw infer audio transcribe`:
`ok:true` with the correct transcript ("你现在探测一下这个mini-con的环境和Scale…"),
provider `livekernel-asr`. Costs to expect, because they set the timeout you need:
`tiny` = 135.7 s load / 0.9 s transcribe / 113 chars; `small` ≈ 2 m20 s for 38.6 s of
audio (model load dominates).

A fuller prompt does not rescue omni here. The same wrapper kept the transcript
instruction static and only swapped the backend; changing the instruction while staying
on omni's `input_audio` buys an English description with more words in it.
