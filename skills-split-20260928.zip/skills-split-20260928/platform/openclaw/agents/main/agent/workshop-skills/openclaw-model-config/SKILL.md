---
name: openclaw-model-config
description: |
  Putting a served model into OpenClaw's model list, repointing or renaming a provider,
  and keeping every reference and resolution layer consistent — including the separate
  media-understanding pipeline that actually routes attachments, the token budget a
  reasoning backend needs, and reverting a degraded model off the primary seat. Use when a
  model id or endpoint changes, an override is refused by modelPolicy.allow, a subagent
  resolves a model you did not set, a session emits corrupt replies, or an image/voice
  attachment is ignored or misread while `models list` shows the modality.
---

# OpenClaw Model Provider Config

## When to use
- Adding a locally served model to the agent's model list
- Repointing a provider at a new port/baseUrl, or renaming a model id
- `model override "<id>" is not allowed for agent "<a>" by modelPolicy.allow`
- `models list` shows a model but every call through it fails
- Assigning a modality (image/audio) a model must accept for a role
- A `sessions_spawn` receipt resolves a model that is not the agent's `model.primary`
- A reasoning-parser provider returns empty `content` / `tool_calls`
- An image, voice note, or audio attachment is ignored, misread, or transcribed as an English
  scene description while `openclaw models list` shows the model accepts that modality

## Steps

1. **Count every place the id is written, and every layer that resolves it.** On this host
   (2026.9.5) an id appears in at least five locations:
   - `models.providers.<pid>.models[<i>].id`
   - `agents.defaults.model.primary`
   - the keys of `agents.defaults.models`
   - `agents.entries.<agent>.modelPolicy.allow`
   - `agents.entries.<agent>.subagents.model` (or `agents.defaults.subagents.model`) — the
     layer that decides a **subagent's** model; it does not fall back to
     `agents.entries.<a>.model.primary`

   Grep first: `grep -o '<id>' ~/.openclaw/openclaw.json | wc -l`. A rename that changes
   only `providers` breaks the default route silently: the listing still shows the model,
   and every agent turn fails on a route that no longer exists.

2. **Confirm the id the endpoint actually serves, not the one you expect.**
   `curl -s http://127.0.0.1:<port>/v1/models`. Renaming to an id the endpoint does not serve
   is indistinguishable from a dangling reference. A local vLLM `/health` under `/v1`
   answers **404** — `/v1/models` returning 200 is the health probe.
   **A local vLLM's served id carries no provider prefix.** Measured 2026-09-25 on `:8002`:
   curling with the config id `nvidia-omni/nemotron-omni-30b-a3b` answers
   `{"error":{"type":"NotFoundError","message":"The model ... does not exist."}}`, while the
   bare id `nemotron-omni-30b-a3b` answers normally. The `nvidia-omni/` prefix is OpenClaw's
   own routing, added by the provider layer, so the same request through the gateway resolves.
   Treat a 404 from a *prefixed* curl as the wrong-name case, not a dead endpoint — confirm
   with the bare id before reporting the service down.

3. **Mutate through `openclaw config set`, dry-run first, one path per call.**
   ```
   openclaw config set 'models.providers.<pid>.models[0].id' '"<served-id>"' --strict-json --dry-run
   openclaw config set 'models.providers.<pid>.models[0].id' '"<served-id>"' --strict-json
   ```
   Quote JSON strings (`'"value"'`) so the shell does not eat them. Applied this way, values
   take effect without a gateway restart.

4. **Declare the modality in two independent layers, not one.** `models[].input`
   (`text`/`image`/`audio`/`video`) says what the *model* accepts; the endpoint accepting a
   media payload is not proof the route is configured for it — read `input` back from
   `models list`. But that declaration alone routes **nothing**: attachments are selected by
   a separate pipeline under `tools.media`, whose entries carry their own
   `capabilities` tags. A model can be listed `text+image+audio` and still receive no
   attachment at all, because no `tools.media.models` entry tags it for that capability.
   There is **no `audioModel` key** in this version (`grep -c audioModel dist/index.js`
   returns 0) — `agents.defaults.imageModel` is the older image-only path and
   `agents.defaults.mediaModels` is image/video *generation*, a third unrelated thing.
   Land both layers, then prove each with the step-7 probe. Entry types, the CLI
   contract, and the exact working config:
   `references/media-understanding-pipeline.md`.

5. **Set `maxTokens` and `timeoutSeconds` on any provider whose server runs a reasoning
   parser.** A vLLM `--reasoning-parser` puts thinking into `message.reasoning`, which still
   consumes `max_tokens`. An unset `maxTokens` sends a small default, reasoning fills it, and
   the turn returns `content: null` with `tool_calls: []` — the loop then delivers
   scaffold-shaped text over HTTP 200 with nothing marking it corrupt. Set both on every
   provider pointed at that endpoint:
   ```
   openclaw config set 'models.providers.<pid>.models[0].maxTokens' '16384' --strict-json
   openclaw config set 'models.providers.<pid>.timeoutSeconds' '300' --strict-json
   ```
   `finish_reason` plus the length of `reasoning` decides whether to raise or lower the
   budget (`thor-native-nemotron-vllm`'s Pitfalls hold the measured trade-off).

6. **Then reconcile the agent references from step 1, in any order.** One asymmetry:
   `openclaw config set --batch-file <file>` **refuses** to replace `agents.defaults.models`
   (`Refusing to replace ... it would remove existing entries`). Use `--replace` or set each
   key individually. `modelPolicy.allow` and `model.primary` accept plain writes.

7. **Prove the route with the light probe, not the agent turn.**
   ```
   openclaw infer model run --gateway --model <pid>/<served-id> --prompt "Reply with exactly: PROBE-OK"
   ```
   Expect the exact string. `openclaw agent --agent <a> --model <id> -m "..."` is the
   roster-safe form but backgrounds and swallows its output on this host, so a probe that
   appears to hang has usually already succeeded — do not re-run it.

   For a media route the probe is the same CLI with a real file:
   `openclaw infer image describe --file <img> --json` and
   `openclaw infer audio transcribe --file <wav> --json` both answer
   `{"ok":true,"outputs":[{"text":…}]}` on success, and
   `{"ok":false,"error":{"message":…}}` naming the entry when the pipeline is unset.
   Read `outputs[0].text`, not the exit code — and judge the *content*, because a route
   can return `ok:true` with a description where a transcript was required
   (`references/media-understanding-pipeline.md` §5).

   **The probe proves the route, not primary-seat fitness.** An agent turn sends
   `tool_choice=auto` plus a tools payload, so a server launched without
   `--enable-auto-tool-choice --tool-call-parser` rejects every real turn with 400 while the
   probe keeps answering (measured 2026-09-24 on `:8002`, probe returned exactly `PROBE-OK`).
   Send that shape yourself — one `tools` entry plus `"tool_choice":"auto"`. 200 means the
   model can carry an agent loop; 400 naming the missing flag means the launch is not, and
   the fix is a relaunch (`thor-native-nemotron-vllm` step 5), not a config change.
   **Before a model takes an agent's primary seat, run `scripts/promotion-gate.py` (gates
   A/B/C)** — a probe, a 200, and a one-tool agent turn each prove only capability. The
   ladder and this endpoint's two measured bad-turn causes: `references/primary-seat-fitness.md`.

8. **Take a degraded model back off the primary seat the same way it went on.**
   Verified 2026-09-24 11:01 UTC:
   - back up first: `cp ~/.openclaw/openclaw.json /tmp/ab_stash/openclaw.json.<ts>`
   - one path per `config set`, dry-run then apply:
     `openclaw config set agents.entries.<a>.model.primary '"stepfun-plan/step-5-preview"' --strict-json`
   - **remove the model from `fallbacks` in the same pass** — a fallback list that still
     contains the primary is a no-op, because failover starts at the primary itself.
   - **clear every other seat the model holds in the same pass**:
     `agents.entries.<a>.subagents.model` and `agents.defaults.subagents.model`. A
     subagent layer does **not** fall back to `model.primary` (step 1), so a demotion that
     moves only the primary keeps the demoted model spawning every delegated task.
     Verified 2026-09-25: `subagents.model` was set to the demoted model while `primary`
     still pointed at it, and clearing it was a separate edit.
   - **expect the demotion to be undone by something, and pin the baseline so you can tell.**
     Verified 2026-09-25: the 2026-09-24 11:01 demotion was already gone — both
     `/tmp/ab_stash` snapshots taken on 09-24 23:36 and 09-25 14:43 carried the demoted
     model back on `primary` — with nothing in the journal or on disk recording who.
     `stat` + `md5sum` the live file against every snapshot before editing, and re-check
     the step-1 grep after; finding the model back on the seat is not by itself evidence
     that a re-promotion was decided.
   - before concluding the model is unfit, check step 5: an unset `maxTokens` produces empty
     turns that read exactly like model degradation.
   - prove the reload from the journal, not the CLI: `config hot reload applied
     (agents.entries.main.model.primary)` is evidence; "Change will apply without restarting
     the gateway" is only a promise.
   - prove the *session* moved: count `provider=<pid> model=<id>` `model-fetch` lines across
     the session's window — a running session keeps its own model resolution, so a
     config-only check can read healthy while the live session still runs the old model.
   - `openclaw doctor --lint` must add no new finding (this host's two standing ones are the
     loopback bind and the local sentinel `apiKey`).

   Modality roles are separate: `agents.defaults.imageModel` can keep a local model off the
   primary seat.

## Completion check
- `openclaw models list --agent <a>` lists the model with the intended `input` and context window
- the step-1 grep for the old id returns **0**
- the probe returns the exact expected string; a tool-carrying request also returns 200 when
  the model is meant to serve agent turns
- for every modality the agent must accept, `tools.media.models` holds an entry tagged with
  that capability and the matching `tools.media.<modality>.enabled` is `true`
- the media probe for each such modality returns `ok:true` **and** text of the kind the task
  needs (a transcript for audio, not a scene description)
- `maxTokens` and `timeoutSeconds` are set on every provider whose server runs a reasoning parser
- `scripts/promotion-gate.py` gates A/B/C pass before the model takes an agent's primary seat
- every subagent path resolves the intended model — the receipt's `resolvedModel` is the record
- `openclaw doctor --lint` reports no new finding caused by the change

## Pitfalls
- **`audioModel` and `videoModel` are not config keys in this version.** The
  media-understanding pipeline is `tools.media` (`audio` / `image` / `video` / `models` /
  `concurrency`); `agents.defaults.mediaModels` is image/video *generation*. Writing an
  `audioModel` key is silently ignored, so a media route can look configured and never fire.
  `openclaw config get <path>` returning `Unknown config path` is the tell — enumerate valid
  paths with `openclaw config schema`.
- **`models[].input` and `tools.media` are two layers with different failure modes.**
  Missing `input` fails at the provider; a missing `tools.media` entry fails at attachment
  selection, before any model is called. The symptom of the second is silence — no request
  reaches the model at all.
- **The image and audio branches of the media runner do not have the same fallback.**
  `runProviderEntry()` resolves `provider?.describeImage ?? describeImageWithModel` for
  images, so an unregistered provider id still works for image; for audio an unregistered
  provider id throws `Audio transcription provider "<id>" not available` and the entry
  cannot run at all. A local engine therefore reaches OpenClaw audio only through
  `type:"cli"`.
- **A CLI media entry's placeholders are double-braced.** `{{MediaPath}}` is substituted;
  `{MediaPath}` reaches your script literally and the run fails with your own usage error
  (`references/media-understanding-pipeline.md` §3).
- **`agents.main.model` is not a valid path** and returns `Unknown config path`. The real
  paths are `agents.defaults.model.primary` and `agents.entries.<a>.model.primary`.
- `openclaw models list` requires `--agent <id>` on a multi-agent roster.
- `allow` is an allow-list of `provider/model-id` strings; after a rename the *old* full
  string is what gets refused, so the fix is a new entry, not a different endpoint.
- Local sentinel `apiKey` values (`__OPEN…ED__`) are placeholders for a no-auth local
  endpoint; `doctor --lint` flagging them as plaintext secrets is expected.
- **A subagent does not inherit `agents.entries.<a>.model.primary`.** With that primary set
  to `nvidia-omni/nemotron-omni-30b-a3b` and every subagent layer unset, a spawn resolved
  to `stepfun-plan/step-5-preview` (then `agents.defaults.model.primary`); passing `model`
  to `sessions_spawn` resolved to omni and carried a real tool chain. Read the receipt's
  `resolvedModel` as the record, and bind `agents.entries.<a>.subagents.model` when no
  per-spawn override is wanted.
- **`Embedded agent failed before reply: prepared model catalog owner config was replaced
  during the read (<agentDir>)` is a transient reload race, not a model or channel fault.**
  Observed 2026-09-24 11:07 UTC: three turns failed inside one second sharing a traceId
  while the agent DB reindexed after `config set` hot reloads; zero since. Re-send the turn
  and confirm the journal count stopped growing before investigating anything else.
- **When a session's replies come back corrupt, identify the serving model before blaming
  the channel or the endpoint.** The journal's `[model-fetch]` lines carry `provider=<pid>
  model=<id>` with a timestamp and are the attribution of record. Two corrupt replies on
  this host matched `provider=nvidia-omni` fetch lines to the second while the same session
  ran clean on `stepfun-plan` minutes before and after — nothing in the response marked them
  corrupt (status 200, normal stop reason). One bad turn is not a fitness verdict.

## Related
- `scripts/promotion-gate.py` — the executable gates A/B/C (+D identity stability).
- `references/primary-seat-fitness.md` — what each gate catches, this host's measured
  outcome, and the two causes measured for this endpoint's bad turns.
- `references/media-understanding-pipeline.md` — the `tools.media` layer: entry types, the
  CLI placeholder contract, and the media probes.
- `thor-native-nemotron-vllm` — serving the model on this host before any of this applies;
  its `../thor-native-nemotron-vllm/references/audio-input-testing.md` §7 records which audio
  this model can and cannot transcribe.
- `add-model-provider` (bundled) — generic provider-add with API keys and SecretRefs.
- `qqbot-channel-connect` — the equivalent consistency discipline for channel config.
