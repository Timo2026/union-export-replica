#!/bin/bash
# Parallel chunked downloader for a single large file, with setsid detachment.
# Usage: pdl.sh <repo> <filename> <outfile> [nconn]
set -u
REPO="$1"; FN="$2"; OUT="$3"; NCONN="${4:-8}"
BASE="https://hf-mirror.com"
URL="$BASE/$REPO/resolve/main/$FN"
WORK="$(dirname "$OUT")/.pdl-$(basename "$OUT")"
mkdir -p "$WORK"

# authoritative total via 1-byte Range
# header looks like: "Content-Range: bytes 3068030976-3069079551/3999641680"
# so the token carrying "/total" is field 3, not field 2.
TOTAL=$(curl -sL -r 0-0 -D - -o /dev/null -m 120 "$URL" 2>/dev/null \
  | tr -d '\r' | awk 'tolower($1)=="content-range:"{n=split($3,a,"/"); if(n>=2 && a[2] ~ /^[0-9]+$/) print a[2]}' | tail -1)
CUR=$(stat -c %s "$OUT" 2>/dev/null || echo 0)
if [ -z "$TOTAL" ] || [ "$TOTAL" = "0" ]; then echo "FATAL: cannot determine size"; exit 1; fi
if [ "$CUR" -ge "$TOTAL" ]; then echo "already complete: $CUR/$TOTAL"; exit 0; fi

REM=$((TOTAL-CUR))
CSZ=$(( (REM + NCONN - 1) / NCONN ))
echo "file=$FN total=$TOTAL cur=$CUR rem=$REM nconn=$NCONN chunk=$CSZ"
echo "$TOTAL" > "$WORK/total"

rm -f "$WORK"/done-*
i=0
while [ $i -lt $NCONN ]; do
  S=$((CUR + i*CSZ))
  [ $S -ge $TOTAL ] && break
  E=$((S + CSZ - 1)); [ $E -ge $TOTAL ] && E=$((TOTAL-1))
  setsid nohup bash -c '
    URL="$1"; S="$2"; E="$3"; CF="$4"; DF="$5"
    for try in 1 2 3 4 5 6 7 8; do
      have=$(stat -c %s "$CF" 2>/dev/null || echo 0)
      want=$((E-S+1))
      [ "$have" -ge "$want" ] && break
      if [ "$have" -gt 0 ]; then
        curl -sL -C - --retry 5 --retry-delay 2 --retry-all-errors \
             -m 7200 -r $((S+have))-$E -o "$CF" "$URL" 2>/dev/null
      else
        curl -sL --retry 5 --retry-delay 2 --retry-all-errors \
             -m 7200 -r $S-$E -o "$CF" "$URL" 2>/dev/null
      fi
      sleep 2
    done
    touch "$DF"
  ' _ "$URL" "$S" "$E" "$WORK/c$i" "$WORK/done-$i" < /dev/null > /dev/null 2>&1 &
  echo "  launched c$i range=$S-$E"
  i=$((i+1))
done
echo "$NCONN" > "$WORK/nconn"
echo "LAUNCHED"
