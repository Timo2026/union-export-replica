# Agent-Loop Tool Calling: Proof and Limits

Read this when a Nemotron/Omni instance must carry OpenClaw agent turns, or when a
relaunch may have dropped the tool-calling capability. Every measurement below is
from `127.0.0.1:8002` (`nemotron-omni-30b-a3b`) on 2026-09-24.

## 1. The flags are per-launch — re-prove them after every relaunch

A restart from a different recipe drops `--enable-auto-tool-choice` silently and
every agent turn 400s again, while plain chat keeps working. The launcher is not
evidence and a pattern grep self-matches (see `openclaw-process-scoped-kill`):
`pgrep -af "port 8002"` returned two "hits" that were the shell running the
command itself. Read the running process directly:

```bash
PID=$(ss -ltnpH "sport = :8002" | grep -oE 'pid=[0-9]+' | head -1 | cut -d= -f2)
tr '\0' '\n' < /proc/$PID/cmdline | grep -c enable-auto-tool-choice   # expect 1
```

## 2. Accept the launch in three levels

Each level catches what the previous one cannot.

**Level 1 — a tool-carrying curl returns 200 with a real call.** The identical
request 400'd before the relaunch and afterwards returned
`get_weather(city="深圳")` in `tool_calls`. This proves the *server* side only.

```bash
curl -s http://127.0.0.1:8002/v1/chat/completions -H 'Content-Type: application/json' -d '{
  "model":"nemotron-omni-30b-a3b",
  "messages":[{"role":"user","content":"深圳天气如何？用工具查"}],
  "tools":[{"type":"function","function":{"name":"get_weather",
    "parameters":{"type":"object","properties":{"city":{"type":"string"}}}}}],
  "tool_choice":"auto","max_tokens":256}'
```

**Level 2 — a real agent turn pinned to the model executes a tool.** Spawn a
subagent with `model: <provider>/<id>` and a task that must call `exec`. The
transcript must hold a genuine tool call *and* its result. A plain chat probe
cannot see a missing parser (`openclaw-model-config` step 7 says the same from
the config side). This is the level a 400 loop hides behind, because a probe
through the same endpoint keeps answering.

**Level 3 — the consumers agree.** Every role the consumer's own router reports
for that endpoint is `online`, and its queue was terminal before the bounce
(step 11 of the main procedure). Enumerate rather than recall.

## 3. Levels 1–2 prove capability, not fitness

Measured on this model on 2026-09-24, four subagent tasks:

| Task shape | Result |
|---|---|
| one `exec` call, echo a string | clean, 11 s, 60.9k tokens |
| `exec` → `write` → `read` chain | all three tools called, write verified on disk, 4m22s |
| read a file then report three facts | tools called, final reply `stopReason=length`, body empty |
| two curls + a sleep + a python extract | blew the 5-minute run budget at 130k tokens |

So a single tool call is reliable, while multi-step work under this model can
truncate its own answer or exhaust its budget. Route omni to short, low-branch
tool tasks (extraction, format conversion, one command plus one file op) and
keep multi-step reasoning on the cloud model until re-measured. Do not
generalize from a probe — or from a pass — without a task of the shape you
intend to run.

**This bench predates the token-budget fault** found later the same day
(2026-09-24 11:20–11:27): an unset `maxTokens` starved multi-step turns, and the
very payloads that starved here returned clean tool calls at 4096 tokens. Re-measure
before relying on these limits, and read
`openclaw-model-config/references/primary-seat-fitness.md` for the two measured
causes of this endpoint's corrupt-looking turns.

**A passed task list is still not the primary seat.** The bench above only ran
subagent-shaped tasks, each with one objective and a report back; none of these
is a long-lived session answering a person turn after turn. On 2026-09-24 the
same model was put on `agents.entries.main.model.primary` for real QQ
conversations and produced a reply that was the *literal text of a tool-call
listing* (twice, 09:01 and 09:12 UTC, each matched to the second by a
`provider=nvidia-omni model=nemotron-omni-30b-a3b` `[model-fetch]` line), then
answered its own model name incorrectly. Both were HTTP 200 with a normal stop
reason, so nothing in the transport marks them corrupt. The evidence for the
primary seat is the live session itself: a free-form conversational turn plus a
multi-step tool chain, in the session that must carry them.

## 4. Re-derive every number a subagent reports

A subagent can relay a contradictory output faithfully. The statistics task
printed `TOTAL LINES 43690` and, in the same output, `21845 total` with
per-file lines that were individually correct. The cause was its own command:
`wc -l {} +` appends a `total` row for multi-file input, so an awk pass that
sums every row double-counts it (21845 × 2 = 43690).

Rules:
- Re-run the arithmetic yourself before passing a number on; `cat`-piped `wc`
  is the cheap independent form (`find … -name '*.py' -exec cat {} + | wc -l`).
- Treat one command output holding two disagreeing totals as a *harness* signal
  first (`wc` tail rows, sort-vs-raw mixes), then as a model signal — and say
  which you concluded.
- A tool result on disk beats a model's transcript of it: `stat` and `md5sum`
  the artifact when accuracy matters.

- **A number a subagent reports may have no tool call behind it at all.** Measured
  2026-09-25: a subagent delegated a three-step quote chain (local quote skill →
  second engine → quotation file) reported `unit 212.80 / total 2128.00` and spent
  its entire run rewriting an input file — its 62-message transcript holds **zero**
  calls to either engine. The price was invented, and the step that would have
  produced the real one was never attempted. For any figure that is supposed to come
  from a tool, engine, or file, confirm a tool call exists in the child's transcript
  that produced it before passing the number on: consistent arithmetic over a
  fabricated input is still fabricated. This is a stronger failure than a mis-relayed
  total — re-deriving the arithmetic from the child's own numbers would still leave
  the invented figure intact, because the error is a missing source, not a bad sum.

- **`outcome: ok` is not evidence the delegated steps ran.** That same run settled
  `status: ok` with an empty result body while its only artifact was a hand-written
  JSON input. A green settle proves the child *stopped*, not that it did the work.
  When delegating a multi-step task, check each required step has a corresponding
  tool call (or a file on disk) before reporting the chain succeeded. When it
  degrades — flailing on one sub-step across many turns — take the task over at the
  failing step and finish it yourself rather than relaying the half-result, because
  omni's known limit is exactly multi-step work (§3).
- **A finished child may never be announced at all, so do not wait on the relay.**
  Measured 2026-09-25: six completed subagent runs each read `outcome: ok` in
  `sessions_history`, but **five carried `delivery: pending`** and their results never
  reached the parent turn. The journal showed 28 `outcome=error` dispatch rows and a
  single `rawErrorHash` **88 times across both providers** (`rawErrorPreview: "Session
  transcript keyed user is outside the current turn"`) — so the relay path is
  model-independent and intermittent (one of the six was delivered late). The chat
  channel itself was healthy throughout: the same session's inbound turns and its
  visible replies all worked. **The completion-pull default is the workaround, not a
  fallback:** collect with `subagents(action=list)` / `subagents(action=wait,
  taskIds=[…])` and read the body with `sessions_history`, and treat `delivery: pending`
  as "not yet seen" rather than "lost". Reserve `sessions_yield` for a child that is
  genuinely still running.
- **Verify every part of a multi-part measurement separately.** A subagent's
  reproduction can be half true, and the correct half buys the fabricated half its
  credibility: a direction claim reported as "`XZ` extrudes −Y and `YZ` extrudes −X,
  bug reproduced" had one correct half and one invented half, and the invented half
  was already written into a live skill's pitfalls. Re-measure each component against
  an independent criterion (centroid, engine normal, bounding box) before any part of
  it reaches a report, a skill, or a changelog — a verified neighbour is not a
  verified claim. When a wrong one has already landed, the repair is the
  re-measurement plus editing the durable artifact, not a note that the subagent is
  unreliable.

## 5. What "capability present" does not license

The primary seat is decided by the live session, not by the ladder. On
2026-09-24 the fitness evidence above was already measured and omni was still
put on the primary seat of the real QQ session, where it answered two turns as
corrupt text (§3). Treat levels 1–2 plus the §3 bench as necessary and still
not sufficient: the primary seat needs a free-form conversational turn plus a
multi-step tool chain in the session that must carry them.

Do not edit any workspace rule that says this endpoint is unfit for agent turns
without reporting what changed: the fitness evidence above, the flag re-proof in
§1, and the level-2 agent-turn result belong in the same message, so the rule is
superseded by measurement rather than by a single probe. The reverse carries
the same duty — a rule that says the endpoint is fit for the primary seat is
superseded by a corrupt live turn, and the revert procedure is
`openclaw-model-config` step 8 (back up the config, set `primary` and
`fallbacks` in one pass, then prove the reload and the session's model from the
journal).
