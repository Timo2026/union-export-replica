---
name: external-skill-pack-install
description: |
  Installing a third-party skill pack after scrubbing it for external endpoints,
  plaintext keys, and real-send paths, then pinning its interpreter and proving each
  pack runs. Use when a skills zip or repo arrives, a pack's documented mode fails,
  or its endpoints need remapping.
---

# External Skill Pack Install

## When to use
- A zip/repo of skill packs arrives and the user asks to install some of them
- An installed skill must be repointed at this host's models instead of a vendor API
- Verifying an already-installed skill pack is clean before trusting it

## Steps

1. **Inventory before trusting anything.** Count packs and files
   (`unzip -l`, then `find` for `*/SKILL.md`), and list what is already installed
   (`ls ~/.openclaw/skills`) to catch name collisions. Install only what was asked
   for; do not install the whole archive.

2. **Scan for outbound credentials and hosts before extracting into the install dir.**
   Stage the zip somewhere disposable (`/tmp/skill_stage_<ts>`) and grep every
   `*.py`, `*.sh`, `*.json`, `*.md` for external IPs, vendor base URLs, token-looking
   strings (`sk-...`), and hardcoded absolute paths from another machine
   (`/home/<otheruser>/`). Do not run `setup.sh` in that staging dir — one installer
   phone-home writes keys or installs packages as a side effect.

3. **Report and stop on a P0 finding rather than patching silently.** A plaintext key
   plus a hardcoded external endpoint means installing the pack sends its future
   payloads to a stranger and stores a live key on disk. Say so, name the files and
   lines, and let the operator decide — installing it and scrubbing it first is not
   the same decision.

4. **Remap endpoints to this host, and remove any external fallback.** Point model
   and API calls at the local services (for this host: 7862 CNC kernel, 8002 omni LLM,
   8011 embed) and delete the vendor base URL entirely, so a local outage fails
   visibly instead of quietly reaching outward. Keep a `local-noauth` placeholder for
   credentials; do not copy a real key into a skill file.

5. **Close real-send paths when the policy is draft-only.** Replace SMTP sends with a
   local draft write (`_draft_only`, a `.eml` on disk) and make any mailbox read-only
   so the skill cannot clear another consumer's `UNSEEN`. A pack with an
   `AUTO_REPLY_ENABLED = True` default is not deployable — see
   `external-mail-system-audit`.

6. **Pin the interpreter and rewrite installers as zero-install.** Prepend the env's
   absolute interpreter path to every `.py` you install
   (`#!$HOME/miniconda3/envs/<env>/bin/python`), and delete a vendored
   `setup.sh`'s pip/conda/network steps — the operator's approval policy governs
   installs, not a script inside a skill. Leave pre-existing packs' shebangs alone;
   only the packs you install need pinning.

7. **Create the env through the operator's normal route** (conda create/env use, or the
   host's standard path). Record which interpreter the pack is pinned to, so a later
   reader knows which env to reinstall.

8. **Prove each installed pack with a real run, then trace its advertised flow to the
   binary that exists.** Three checks, and the third is the one that a green first run
   does not cover:
   - a `health`/`test` subcommand returning green, or one call that leaves a number or
     file on disk. A `SKILL.md` exists check is not a smoke test.
   - **run the pack's own entry script end-to-end, not just a library function.**
     Importing a module proves the interpreter and the imports, not the wrapper's
     control flow, the exit-code contract, or the writes around it. Measured 2026-09-24
     installing a quotation pack: importing its validator and running its HTML generator
     directly both succeeded, while its own `generate-all.sh` wrapper broke in three
     independent ways that neither test could see — (a) a **hardcoded other-OS binary
     path** (`/Applications/Google Chrome.app/...`) made the HTML→PDF step silently skip,
     with `[ -x ]` returning false and no error; (b) an **`exit 0` before the remaining
     steps** in its `--html-only` branch, so the documented "one-click" flow finished
     while the PDF step it advertised never ran; (c) a **hard `exit 1` on a missing
     optional sibling skill**, so one absent Excel/Word script killed the whole pipeline
     instead of warning-and-continuing. Fix host-specific breakage of exactly these kinds
     (binary paths, control flow that skips a documented step); do not rewrite the pack's
     business logic or invent a missing script — report which modes survive.
   - **verify the paths the pack's own docs advertise.** Resolve every `scripts/…` and
     sibling-skill reference in `SKILL.md`, its shell wrappers, and `INDEX.md` against the
     installed tree. On 2026-09-24 an installed pack advertised six `.py`/`.js` scripts
     living in *sibling skills absent from the archive* (`excel-xlsx/…`, `word-docx/…`,
     `imap-smtp-email/smtp.js`, `imap-smtp-email/okki-sync.js`), so its documented
     Excel / Word / CRM-sync modes could not run on any host. State which modes are
     actually usable here and why the rest cannot be, instead of reporting the manifest's
     file list as installed capability.
   **Exit codes need reading, not assuming.** A non-zero exit may carry facts rather than
   failure: one installed tool exits **2** with a complete JSON report when a single fact
   family degraded and **0** only when every family measured, and another exits **2**
   for a validation rejection its wrapper correctly treats as failure. Read the payload
   and the tool's own documented contract before treating a status as pass or fail.
   **A non-zero exit from your own verification command is not a finding about the pack**
   — the `ls` that follows a successful run returns 2 as readily as the script does.
   - **read the artifact the pack produced, not just the exit code.** All three checks above
     ask *did it run*; none asks *did it write the right thing*. Measured 2026-09-25 on an
     installed quotation pack that had already been fixed through the three execution
     breakages above: its own validator exited **0** and emitted a 2-page PDF that opened
     and extracted cleanly, yet the document named **another company as the supplier**
     (a hardcoded default in the pack's own HTML template, which the caller's data cannot
     override), printed every CNY amount with a **`$`** prefix, and showed a template default
     lead time where the data had supplied one. All three were wrong in the output while
     nothing was wrong in the run. So grep the produced file for the identity fields the
     pack was supposed to fill: supplier name, currency symbol against the stated currency
     code, and any date/lead-time the caller supplied. A pack that ships one customer's
     identity as its default will address your customer's quotation to a stranger.
     **When the currency symbol is wrong, compare the field path in the validator against
     the one in the renderer before changing either.** Measured 2026-09-25: the same pack's
     validator accepted `trade_terms.currency` while its HTML generator read only top-level
     `data['currency']` — two readers of one field, each with its own default, so a CNY
     quote placed under `trade_terms` silently degraded to USD in every printed amount
     (货值高估约 7 倍) with a 0-exit validation run. Fixing only the symbol map leaves the
     contract mismatch in place; align both readers, then re-run the case that failed.
     The same mismatch shape hid a fabricated-terms defect: the renderer substituted four
     invented defaults (`MOQ 500 pcs` / `PayPal` / `Gift box`) when the data supplied none,
     so grep the produced document for any boilerplate the caller never sent.

9. **Verify the scrub is complete, then record it.** Re-run the step-2 grep over the
   installed tree and report the count of remaining hits (0 expected). Note the
   install, the pinned interpreter, the endpoint map, and the smoke results in the
   daily memory log so the next session can tell a clean install from an unvetted one.

## Pitfalls
- A pack's own frontmatter may be missing a required `description`, and the skill
  loader then **skips it silently** — the scripts run but the agent will never call
  the skill. Inspect each installed `SKILL.md` for `name` and `description` after
  copying; the loader's log line names the offending file.
- Frontmatter lines are fragile across patches: an embedded colon inside a
  `description` value can parse as a nested mapping. Quote the value.
- "SKILL.md exists" is not "skill is loaded" and not "skill works". Check the loader
  log, then run it.
- **Many installed NVIDIA skills are Jetson-shaped and will self-reject on this DGX Spark
  host.** That is the skill working correctly, not an install defect. Re-measured 2026-09-25
  (piped, so the recorded codes were the pipe's): `jetson-diagnostic`'s `snapshot.sh` **and**
  its `scripts/detect_jetson.sh`, plus `jetson-memory-audit`'s `scripts/audit.sh`, each print
  `ERROR: not running on a Jetson device.` and exit **2** — not 0, and not a hang. An earlier
  version of this bullet recorded exit **0**, which would make a future run report a
  self-rejecting guard as "did nothing"; treat a non-zero exit that carries a clear
  not-applicable message as the guard firing. `jetson-print-device-info` has **no `scripts/`
  directory at all** — it is a doc-only stub whose SKILL.md describes a script that was never
  shipped (its guard snippet, run inline from the SKILL.md, exits **1**). One member of the
  family is *not* guarded: `jetson-diagnostic/scripts/mem_summary.sh` exits **0** on this
  non-Jetson host and prints a real `RAM used/GPU sum/swap` line sourced from
  `nvidia-smi compute-apps`, so a green number from it is not evidence the skill "works
  here" — only `snapshot.sh`/`detect_jetson.sh`/`audit.sh` encode the platform check.
  Probe with `ls <pack>/scripts/` before concluding anything about a pack, and report
  "not applicable to this host" rather than "broken".
- Pre-installed packs are out of scope unless asked: their count will differ from
  yours, and their `#!/usr/bin/env python3` shebangs are not yours to rewrite.
- **A thin SKILL.md that instructs the agent to invoke another skill is a
  platform-specific forwarding stub, not a capability.** Measured 2026-09-25 on
  `mattpocock/skills`: `grill-with-docs` is **247 bytes** whose entire body is "Call the
  Skill tool twice, for grilling and domain-modeling", and `grill-me` / `implement` are
  433–500 bytes of the same shape. On Claude Code that resolves; where skills are
  instruction files read by the agent it installs a dead letter that will never fire.
  Read the byte count and the body first, resolve every named target against what is
  actually installed, and install the **real dependency** instead (`grilling` +
  `domain-modeling` here) so the advertised workflow has an entry point. Then report
  which advertised flows have a runnable home and which do not — the "which modes are
  actually usable here" answer step 8 already demands for scripts, applied to stubs.

## Related
- `external-mail-system-audit` — deployability verdict for a vendored *mail system*,
  including send-defaults and mailbox ownership.
- `ocp-geometry-code` — reading or authoring OCP geometry code, including the
  typed-accessor traps that make an OCC example fail under OCP.
- `livekernel-mail-intake` — the local mail gates any mail-touching skill must
  satisfy.
