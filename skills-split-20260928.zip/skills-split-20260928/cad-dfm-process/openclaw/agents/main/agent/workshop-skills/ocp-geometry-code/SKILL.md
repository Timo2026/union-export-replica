---
name: "ocp-geometry-code"
description: "Fixing or writing OCP/CadQuery geometry code that was copied from OCC examples: the missing Core layer, typed builder accessors, the Transfer enum, no Edge_s cast, and extrude direction. Use when an OCC-derived script raises TypeError or attribute errors under OCP, when an extrude or cylinder lands mirrored on the wrong side of a part, or when STEP output must be proven written."
---

# OCP Geometry Code

## When to use
- An OCC/`OCC.Core`-style snippet fails under the `OCP` bindings
- `TypeError: ... incompatible function arguments` from a `BRepBuilderAPI_Make*` call
- A script reports success but the STEP file is never written
- An extrude, cylinder, or boss lands mirrored on the wrong side of a part (step 7)
- Adding geometry code to a skill or smoke test

## Steps

1. **Assume the bindings differ, not the geometry.** Code written for pythonocc
   (`from OCC.Core.*`) does not import under OCP. The layer between is gone: OCP puts
   everything under `OCP` directly (`OCP.TopoDS`, `OCP.BRepBuilderAPI`,
   `OCP.STEPControl`). Rename the imports first, then look for the real error.

   **But the rename target splits by builder family, and OCC's `BRepPrimAPI_*`/
   `BRepBuilderAPI_*` names are not interchangeable.** The primitives
   `MakeBox` / `MakeCylinder` / `MakeSphere` / `MakeTorus` live in **`OCP.BRepPrimAPI`**,
   while `MakeEdge` / `MakeWire` / `MakeFace` / `MakeSolid` / `Transform` live in
   `OCP.BRepBuilderAPI`. Mapping a `BRepPrimAPI_MakeBox` onto `BRepBuilderAPI` yields
   `module 'OCP.BRepBuilderAPI' has no attribute 'MakeBox'` — which reads like a build
   missing a feature when it is simply the wrong module: `dir(OCP.BRepBuilderAPI)` returns
   63 names and **no `Make*` at all**. Probe before trusting either import:
   ```python
   from OCP import BRepPrimAPI, BRepBuilderAPI
   print([n for n in dir(BRepPrimAPI) if 'Make' in n][:6])   # the primitives
   ```
   In this build the class name keeps the underscore form
   (`OCP.BRepPrimAPI.BRepPrimAPI_MakeBox`) — a bare `MakeBox` fails in both modules.

   **On this host, stop fighting raw OCP once two builder calls have failed and build
   through cadquery.** `$HOME/miniconda3/envs/occ/bin/python3 -c "import
   cadquery"` gives 2.8.0, whose `Workplane` API covers boxes, cylinders, `cut`/`union`,
   and `cq.Assembly` **named multi-solid** STEP export. Verified 2026-09-24: a two-part
   `cq.Assembly` exported to STEP and read back through
   `cq.importers.importStep(p).solids()` returned **2** solids (not one flattened solid),
   so the named-assembly route is real. A 12-part assembly exported the same way gives
   **13 `PRODUCT` entities** (1 assembly root + 12 parts) and every part re-reads as its
   own solid — that is the proof a part set is independently editable rather than merged
   into one solid. Raw OCP stays the right tool for the fine-grained accessors in step 2;
   cadquery is the right tool for whole-part modelling.

   **Exporting through this host's STEP writer with non-ASCII part names produces
   mojibake**, so name the STEP entities in ASCII (`PART_01_FrontPanel`) and carry the
   localized name in the BOM or report instead.

2. **Fix `TypeError: incompatible function arguments` with the typed accessor.** The
   builder classes are strict about the concrete TopoDS type; their `.Shape()` method
   returns the base `TopoDS_Shape`, which is rejected by anything wanting a subtype.
   Use the narrow accessor instead:
   - `BRepBuilderAPI_MakeEdge(...)`  → `.Edge()`   (gives a `TopoDS_Edge`)
   - `BRepBuilderAPI_MakeWire(...)`  → `.Wire()`   (gives a `TopoDS_Wire`)
   - `BRepBuilderAPI_MakeFace(...)`  → `.Face()`

   This is the recurring one: `MakeWire.Add(<Shape>)` and `MakeFace(<Shape>)` both
   fail while identical code under pythonocc passed, because pybind downcast there.

   The same check applies to **vertex coordinates**. `BRepBuilderAPI_MakePolygon.Add()`
   has only two overloads, `Add(gp_Pnt)` and `Add(TopoDS_Vertex)` — so the natural
   `for x, y in pts: mk.Add(x, y, 0.0)` raises the same opaque
   `TypeError: incompatible function arguments (… 30.0754794, -9.91177643, 0.0)`. When
   a loop adds coordinates, import `gp_Pnt` from `OCP.gp` and pass
   `mk.Add(gp_Pnt(x, y, 0.0))`. The error names your own data, not a missing type —
   that is what makes it read as a value problem instead of an overload problem.

3. **Pass the `STEPControl` enum, not an integer.** `STEPControl_Writer().Transfer()`
   takes a mode from the enum. `writer.Transfer(shape, 1)` is the ported form of the
   OCC constant and is rejected under OCP — use
   `from OCP.STEPControl import STEPControl_AsIs` and pass it. Every call site in the
   file needs it; grep for `Transfer(` before finishing.

4. **Do not reach for `TopoDS.Edge_s` / `Vertex_s`.** OCC's static casts are absent
   from this OCP build — `hasattr(OCP.TopoDS,'Edge_s')` is `False`. The correct
   pattern is the narrow accessor in step 2. Verify first when tempted:
   `print([m for m in dir(OCP.TopoDS) if m.endswith('_s')])`.

5. **Treat the STEP writer's success print as the evidence.** A working emit ends with
   the `Step File Name: ... Write  Done` line and a file whose `stat` size matches an
   entity count in the 100s+. A run that prints a header and then dies on a builder
   call has written nothing. Count the files it claims to create.

   Then **read the file back** rather than trusting the write, especially for a shape
   whose cross-section came from a point list:
   ```python
   rd = STEPControl_Reader(); assert rd.ReadFile(p) == IFSelect_RetDone
   rd.TransferRoots()
   props = GProp_GProps(); BRepGProp.VolumeProperties_s(rd.OneShape(), props)
   # props.Mass() must match the volume you computed from the profile
   ```
   For an extrude also compare `props.CentreOfMass()` against the expected shape — a
   symmetric solid gear about the origin must centre at (0, 0). A mismatch means the
   face is wrong even though the write reported Done.

6. **Prove the whole shape set in one smoke run.** A geometry module's `test` subcommand
   should generate every primitive/compound it advertises and leave a file for each.
   Failures that appear only for one shape (the polygon path using edges and wires) are
   the typed-accessor bug in step 2, not a flaw in that shape.

7. **Probe extrude direction with a bounding box before assembling.** Run
   `shape.val().BoundingBox()` and assert the sign and span of each axis against the
   intended placement *before* any pairwise interference check (see the extruded-plane
   pitfall below). **Check:** every axis span matches the intended placement, and the
   solid count equals the number of parts you added to the assembly.

## Pitfalls
- Chasing the traceback past the first typed-accessor fix wastes turns: the same
  mistake usually appears at the next builder call in the same file. Fix all of them
  in one pass and re-run.
- **`Workplane.extrude()` on the `XZ` plane extrudes along the negative axis (`−Y`).**
  Verified 2026-09-25 on this host (cadquery 2.8.0, `occ` env) — re-measured because an
  earlier version of this pitfall also blamed `YZ`, which is **wrong**. Probe with the
  **centre of mass**, not the bounding box alone: the extrusion axis is the axis the
  centroid moved along, and its offset is `length/2` from the profile.
  ```python
  cq.Workplane("XZ").workplane(offset=0).center(10, 20).circle(2).extrude(5)\
      .val().Center()     # (10.00, -2.50, 20.00) -> extruded along -Y
  cq.Workplane("YZ").workplane(offset=0).center(10, 20).circle(2).extrude(5)\
      .val().Center()     # ( 2.50, 10.00, 20.00) -> extruded along +X
  ```
  Full sweep for the six letter planes — circle r=2 at local (10, 20), `extrude(5)`:

  | plane | axis | centroid range |
  |---|---|---|
  | `XY` | Z | `[0.00, 5.00]` |
  | `XZ` | **Y** | **`[-5.00, 0.00]`** |
  | `YZ` | **X** | **`[0.00, 5.00]`** |
  | `ZX` | Y | `[0.00, 5.00]` |
  | `ZY` | X | `[-5.00, 0.00]` |
  | `YX` | Z | `[-5.00, 0.00]` |

  Cross-check the direction from OCC itself before trusting the table — `Plane.named(wp).zDir`
  is the extrusion normal, so an `xDir × yDir` product of `(0, -1, 0)` means −Y:
  ```python
  cq.Plane.named("XZ").zDir   # (0.0, -1.0, 0.0)
  cq.Plane.named("YZ").zDir   # (1.0,  0.0, 0.0)
  ```
  A cylinder, pin, or boss drawn on `XZ` (or `ZY` / `YX`) lands mirrored on the wrong side
  of the part, which later surfaces as a bogus interference clash on an `intersect()` or
  bounding-box check. This cost a real rework cycle on a 12-part assembly — three false
  clashes between a front panel and its latch pins / lock rotor. **When the sign matters,
  skip the plane** and build the solid with an explicit axis:
  ```python
  cq.Workplane("XY").newObject([
      cq.Solid.makeCylinder(r, length, cq.Vector(cx, cy, cz), cq.Vector(0, 1, 0))
  ])
  ```
  The explicit form gives `ymin=4.00, ymax=12.00` for an 8-long cylinder at y=4 — assert
  that span before assembling. Alternatively extrude a negative length, but **only on the
  planes that go the wrong way** (`XZ`, `ZY`, `YX`) — `YZ` already goes +X, and mirroring it
  there puts the part on the wrong side. Say so in a comment either way, because the next
  reader will assume the sign.
- **A boolean `intersect()` that raises is not a pass.** Record it in an explicit
  "unverified" bucket and report the count; returning `-1.0` for a volume makes an
  exception read as a computed negative volume. Bounding-box pre-screening is fine, but
  state how many pairs were actually intersected versus pre-screened out, and enumerate
  the pairs that failed rather than folding them into the clean total.
- **Build a numeric contract on an off-the-basis profile before handing its points to OCP.**
  A section made of analytic segments (involute, tangent fillet, arcs) can be written
  wrong in ways OCP accepts silently — or reports as a confusing builder error far from
  the cause. Before `MakePolygon`, assert on the point list itself: first and last point
  coincide (gap < 1e-6), no two adjacent points coincide, every point's radius lies in
  the intended band, and no two non-adjacent segments intersect. The last one is worth
  a vectorized pairwise test even at 10³ points, because a self-intersecting wire either
  fails the face build or produces a solid whose volume and centroid are nonsense.
- **Prefer a generic "centre + both endpoints, take the short arc" sampler over per-segment angle bookkeeping.**
  Constructing a closed profile segment by segment with accumulating angles is where
  the errors come from; a single `arc(cx, cy, ax, ay, bx, by, n)` helper that resolves
  the short direction from the two endpoints removes the whole class. Verify the
  analytic preconditions with asserts too (e.g. a tangent fillet's touch radius
  `sqrt(R² - r²)` must stay below the base circle it must not overlap) instead of
  discovering it as a bad volume later.
- **When a check on computed geometry fails, verify the check before the geometry.**
  A wrong expected value, a mis-centred cell reference, or a unit slip reads exactly
  like a geometry bug. Three such checks misfired on one gear run — "root fillet minimum
  should be rf - r" (it is rf, the fillet is externally tangent to the root circle),
  "tip thickness 0.376 vs 4.139" (the sampler's arc step was being reported as thickness),
  "weight 114 kg" (grams). Each prompted a pointless change to geometry that was already
  correct. Recompute the expected value by hand and print both sides before touching
  the profile.
- The stated entry point may not be the runnable one. A module can `sys.exit(1)` on a
  missing heavy dependency (FreeCAD) while a sibling script implements the same
  feature with only OCP. Run the one whose imports resolve.
- A file with a valid STEP header and no entities passes a header read and then fails
  the shape transfer, which surfaces as a parser error far from the real cause. Smoke
  against a known-good sample before blaming the chain.
- Errors surfacing at the *engine* call site can originate in the payload shape, not
  the engine: a list sent where the endpoint expects a dict of keys yields HTTP 500
  with a `'list' object has no attribute 'items'` in the service log. Read the log's
  traceback and the endpoint's docstring before assuming the service is down.

## Related
- `livekernel-offline-engine-bridge` — calling the deterministic engine safely
  (env, absolute paths, trusting `volume_source` over a green exit).
- `external-skill-pack-install` — installing a skill pack that contains geometry code.
- `livekernel-mail-intake` — the mail gates that feed geometry into the pipeline.
