# cad-dfm-process
CAD/图纸解析 + DFM 可制造性检查 + 材料与工艺知识
## 内容
- 16 个 skill / 51 个文件 / 0.2M
- `hermes/openclaw-imports/` — 2 个 skill（原 ~/.hermes/skills/openclaw-imports/）
- `livekernel/` — 10 个 skill（原 ~/timo_livekernel/skills/）
- `openclaw/` — 3 个 skill（原 ~/.openclaw/skills/）
- `openclaw/agents/main/agent/workshop-skills/` — 1 个 skill（原 workshop-skills/）

## 跨仓依赖

依赖 quote-core 的材料价格表

## 部署

```bash
# 与本仓同系列的其他仓库一起部署到同一框架目录
# skill 名即目录名，直接按 framework 拷回原路径
```
